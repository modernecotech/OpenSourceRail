OpenSourceRail gauge-corrected final-load elastic method proof

Run `python verify.py` after extracting this archive into a fresh directory.
The verifier uses only the Python standard library and performs no simulation.
It authenticates member bytes, sealed inputs/results/meshes, exact source snapshots,
CAD volume, case identities, equilibrium, rotating support axes and refinement.

Full numerical replay requires an OpenSourceRail checkout with the numerical
source snapshot and the pinned installed tools. The numerical source epoch is
source-before.json. Actual commands and resource limits are retained verbatim;
commands contain the original private absolute paths, so a relocated replay
should use engineering.pilot_civil.final_trial with a NEW --output directory.
Use this package's axle-input.json and source/upstream as --upstream-root.
Install the exact declared toolchain/Gmsh/Python environment first. Never run
the original commands against the retained private output directories.

The original finite-patch model is retained separately; its recovered support
wrenches in prior-support-audit.json identify unintended bending couples.
The final experiment uses explicit transverse bearing lines, which release
longitudinal bending rotation. Actual finite bearing contact/compliance, joint
strength, cracking, prestressing, fatigue and physical acceptance remain open.
This proof package supplies a converged elastic comparison for one exact
normal-base load case. It is not approval for manufacturing or operation.

Only replaceable rolling checkpoints, alternative scratch result formats, and
duplicate STEP/mesh/deck representations are omitted here. omissions.json
records their exact original hashes; full-private-manifest.json covers the
separately retained full private run.
