# 17 depot/storage design studies and Iraqi slab manufacture

[Located track and slot register](depot-layouts.json) identifies **540 storage positions**, 185 tracks, 65,340 usable track metres, 130,680 rail metres and 217,812 reference fixation-seat kits. 55,316.8 m³ concrete is a geometric reference for yard slabs, excluding foundations, reinforcement, grout/stray-current systems and point panels. Existing track/package costs are not supplemented by these quantities a second time.

| Line | Slots | Storage tracks | Workshop bays | Layout |
| --- | --- | --- | --- | --- |
| line-1 | 54 | 18 | 14 | [SVG](depot-line-1.svg) |
| line-10 | 10 | 4 | 3 | [SVG](depot-line-10.svg) |
| line-11 | 11 | 4 | 3 | [SVG](depot-line-11.svg) |
| line-12 | 12 | 4 | 4 | [SVG](depot-line-12.svg) |
| line-13 | 11 | 4 | 4 | [SVG](depot-line-13.svg) |
| line-14 | 11 | 4 | 3 | [SVG](depot-line-14.svg) |
| line-15 | 9 | 3 | 3 | [SVG](depot-line-15.svg) |
| line-16 | 9 | 3 | 3 | [SVG](depot-line-16.svg) |
| line-17 | 12 | 4 | 4 | [SVG](depot-line-17.svg) |
| line-2 | 60 | 20 | 15 | [SVG](depot-line-2.svg) |
| line-3 | 58 | 20 | 14 | [SVG](depot-line-3.svg) |
| line-4 | 47 | 16 | 11 | [SVG](depot-line-4.svg) |
| line-5 | 58 | 20 | 14 | [SVG](depot-line-5.svg) |
| line-6 | 61 | 21 | 14 | [SVG](depot-line-6.svg) |
| line-7 | 47 | 16 | 11 | [SVG](depot-line-7.svg) |
| line-8 | 65 | 22 | 14 | [SVG](depot-line-8.svg) |
| line-9 | 5 | 2 | 7 | [SVG](depot-line-9.svg) |

Drawings use local planning coordinates and distinguish storage slots from workshop bays. Rectangular packing can include unused end positions; it creates no acquired parcel or released alignment. Throat radii, bypass/escape tracks, drainage/outfalls, road/fire/evacuation access, utilities, lifting/inspection/rescue/quarantine areas and grid connection need actual surveys and supplier footprints. Line 6 requires about 33,333m² PV module area; no 4,000m² canopy is credited as adequate.

The yard-only slab production study requires **11 parallel mould cells** at a one-working-day cycle/75% utilisation, ready month 18 and delivering two months before each opening. Its [prefix-capacity programme](depot-layouts.json) includes cut/end panels and never casts beyond usable lengths. Moulds, curing/QA, batching, reinforcement, transport, lifting and installation require quantities/quotes and measured cycles. Factory CAPEX is null, not free. Main-line slab manufacture is a different existing production requirement; these cells cannot be represented as its total capacity. Iraqi casting/assembly remains a proposed procurement route, not a qualified plant.

![Line 6 storage and workshop packing study](depot-line-6.svg)

[Startup alternatives](startup-policy-alternatives.json) compare the existing revenue fleet with the frozen original dispatch-point set, including 5 missing line-9 directions. Holding that set fixed requires 5 extra revenue trains and 1 extra spares: USD 10.08m vehicle reference, before consequential costs. Adding trains must not silently expand dispatch-point selection. Reserving fewer start points or buying trains requires a separate selected-start, cycle, turnback, depot/charging and funding replay; neither changes the baseline nor closes the existing failed gate.
