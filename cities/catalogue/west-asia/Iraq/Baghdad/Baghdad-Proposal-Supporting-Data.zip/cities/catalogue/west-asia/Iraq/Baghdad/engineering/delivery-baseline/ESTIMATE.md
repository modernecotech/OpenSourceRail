# Baghdad delivery estimate and scope reconciliation

The published **USD 9.117293bn equivalent** is a base planning estimate, not a complete delivery budget. City subtotal is USD 8.748272bn and the one Baghdad factory including its EPC is USD 369.022m. [Scope register](scope-register.csv) retains quantity, implied rate, currency/source quality, inclusions, exclusions, estimator role and uncertainty. Every actual price date, quotation and named estimator remains unknown. Category implied rates reconcile the baseline; they are not surveyed rates.

| Baseline WBS | Quantity | USD m equivalent | Evidence |
| --- | --- | --- | --- |
| civil | 539.505 | 4,260.749 | category-planning-estimate |
| stations | 251.000 | 1,392.600 | category-planning-estimate |
| depots | 1.000 | 8.000 | category-planning-estimate |
| rolling_stock | 958.000 | 1,609.440 | category-planning-estimate |
| solar_plant | 1,050,459.948 | 840.368 | category-planning-estimate |
| signalling | 539.505 | 26.975 | category-planning-estimate |
| charging_microgrid | 1.000 | 92.800 | category-planning-estimate |
| epc_overhead | 1.000 | 517.340 | category-planning-estimate |
| factory-direct | 1.000 | 344.880 | factory-sizing-allowance |
| factory-epc | 1.000 | 24.142 | factory-sizing-allowance |

12 additional scope records retain **null costs**, not zero: land/title, utility diversions, duties/tax, owner costs, pre-opening people, six-car qualification, installed control/HIL, initial spares, working capital, civil/station investigations, task-derived maintenance and cyber deployment. Each requires a signed inclusion/quotation decision before financing is recalculated. Surveyed grade separation, foundations, standard spans, temporary works/erection, passenger access/evacuation, road interfaces and station functions must be investigated by corridor; civil and station standards alone do not resolve them.

EPC has [identified delivery obligations](epc-obligations.json), with individual priced contracts still null. Their sum cannot be asserted from the existing percentage. Factory contingency **USD 53.979m**, factory design/training/qualification **USD 20.0m**, routine train QA/labour/logistics and factory EPC are already embedded and must not be added twice. Initial stock, battery renewal cash dates, labour/maintenance contracts and working-capital reserves need account-level reconciliation.

| Depot alternative | Gross priced reference USD m | Provisional replacement total USD bn |
| --- | --- | --- |
| retained_declared_bays | 206.435 | 9.315729 |
| workload_bays | 203.444 | 9.312738 |

Replacement illustrations subtract the old depot allowance once, then add the gross quantity-based reference. They remain incomplete: charging/PV/EPC overlaps and unpriced work are unresolved. No alternative is adopted into the published funding programme; government/import shares, loans and opening dates remain conditional on the original scope. Retained property additions remain their existing separate scenarios, not automatically added to this base.

The seeded [correlated cost-and-delay sensitivity](cost-schedule-risk.json) combines a shared risk quantile with idiosyncratic cost events and delay escalation. Illustrative known-scope P50 is USD 11.319bn and P80 USD 12.163bn. **These are uncalibrated distributions, not an approved probabilistic budget.** Unpriced scope is excluded rather than priced at zero; existing contingencies remain embedded; stress outputs are alternatives and cannot be added to the base. Calibrate from investigations, contract evidence, event-level dependencies and actual invoice dates. [GAO estimating guidance](https://www.gao.gov/products/gao-20-195g) supports technical baseline, WBS, data, alternatives, risk analysis and updates; it does not validate OSR's rates. Reference checked 4 October 2026.
