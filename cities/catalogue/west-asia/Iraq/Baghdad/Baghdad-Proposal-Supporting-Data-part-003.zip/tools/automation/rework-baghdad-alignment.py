#!/usr/bin/env python3
"""Rebuild controlled core corridors from an immutable pre-rework route seed.

Straight tangents and circular corner fillets replace street-following raster
zigzags. The grid is a planning representation; analytical tangent/arc controls
are preserved for subsequent survey and railway transition-curve design.
"""
from __future__ import annotations
import argparse
import gzip
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import tomllib

ROOT=Path(__file__).resolve().parents[2]
CITY=ROOT/'cities/catalogue/west-asia/Iraq/Baghdad'
CONFIG=ROOT/'lib/templates/baghdad-alignment.toml'
OUT=CITY/'engineering/alignment'
SEED=OUT/'pre-rework-corridors.json.gz'
GRID=OUT/'planning-grid.json'

def distance(a,b):return math.hypot(b[0]-a[0],b[1]-a[1])

def remove_short_ring_spikes(cells, cell_m, protected_cells=()):
    """Remove only one-cell A-B-A excursions on a closed ring.

    This preserves every existing forward edge, creates no shortcut across
    land/water, and leaves longer excursions and supplied protected cells for explicit design.
    """
    if len(cells)<4 or cells[0]!=cells[-1]:return cells,[]
    protected={tuple(p) for p in protected_cells};result=[];removed=[]
    for point in cells:
        if result and point==result[-1]:continue
        if len(result)>=2 and point==result[-2] and tuple(result[-1]) not in protected and distance(result[-2],result[-1])*cell_m<=cell_m*1.5:
            spur=result.pop();removed.append(dict(return_cell=point,spur_cell=spur,removed_route_m=round(2*distance(point,spur)*cell_m,6)))
            continue
        result.append(point)
    if len(result)<4 or result[0]!=result[-1]:raise ValueError('ring cleanup removed the closed circuit')
    return result,removed
def simplify(points,tolerance):
    if len(points)<3:return points
    a,b=points[0],points[-1];dx,dy=b[0]-a[0],b[1]-a[1];den=dx*dx+dy*dy
    def error(p):
        t=max(0,min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/den)) if den else 0
        return distance(p,(a[0]+t*dx,a[1]+t*dy))
    idx=max(range(1,len(points)-1),key=lambda i:error(points[i]))
    if error(points[idx])<=tolerance:return [a,b]
    return simplify(points[:idx+1],tolerance)[:-1]+simplify(points[idx:],tolerance)

def fillet(points,radius,spacing):
    controls=[];samples=[points[0]]
    def tangent(end):
        start=samples[-1];n=max(1,math.ceil(distance(start,end)/spacing))
        samples.extend((start[0]+(end[0]-start[0])*i/n,start[1]+(end[1]-start[1])*i/n) for i in range(1,n+1))
        controls.append(dict(kind='tangent',start=start,end=end,length_m=distance(start,end)))
    for a,b,c in zip(points,points[1:],points[2:]):
        ab,bc=distance(a,b),distance(b,c)
        if min(ab,bc)<1:continue
        u=((b[0]-a[0])/ab,(b[1]-a[1])/ab);v=((c[0]-b[0])/bc,(c[1]-b[1])/bc)
        angle=math.acos(max(-1,min(1,u[0]*v[0]+u[1]*v[1])))
        if angle<1e-5:continue
        if angle>=math.pi-.01:raise ValueError('Core alignment reverses direction; requires a new corridor')
        offset=min(radius*math.tan(angle/2),ab*.4,bc*.4)
        actual=offset/math.tan(angle/2)
        start=(b[0]-u[0]*offset,b[1]-u[1]*offset);end=(b[0]+v[0]*offset,b[1]+v[1]*offset)
        turn=1 if u[0]*v[1]-u[1]*v[0]>0 else -1
        center=(start[0]-turn*u[1]*actual,start[1]+turn*u[0]*actual)
        tangent(start);theta=math.atan2(start[1]-center[1],start[0]-center[0]);n=max(1,math.ceil(actual*angle/spacing))
        samples.extend((center[0]+actual*math.cos(theta+turn*angle*i/n),center[1]+actual*math.sin(theta+turn*angle*i/n)) for i in range(1,n+1))
        controls.append(dict(kind='arc',start=start,end=end,center=center,radius_m=actual,turn=turn,angle_rad=angle,length_m=actual*angle))
    tangent(points[-1]);return samples,controls

def rework(seed,grid,config,water_mask=None,buildable=None):
    cell=seed['grid_cell_m'];core=config['core'];rows=[];result=json.loads(json.dumps(seed))
    def inside(rc):
        lat=grid['bbox_north']-(rc[0]+.5)*cell/grid['m_per_deg_lat'];lon=grid['bbox_west']+(rc[1]+.5)*cell/grid['m_per_deg_lon']
        return core['south']<=lat<=core['north'] and core['west']<=lon<=core['east']
    for line in result['lines']:
        original=line['cells'];segments=[];new=[];i=0
        while i<len(original):
            if not inside(original[i]):new.append(original[i]);i+=1;continue
            end=i+1
            while end<len(original) and inside(original[end]):end+=1
            points=[(r*cell,c*cell) for r,c in original[i:end]]
            if len(points)<3:new.extend(original[i:end]);i=end;continue
            waypoints=([points[0],points[-1]] if line['shape']=='Radial' and config['geometry']['straight_core_radials'] else simplify(points,config['geometry']['simplification_tolerance_m']))
            samples,controls=fillet(waypoints,config['geometry']['preferred_fillet_radius_m'],config['geometry']['sample_spacing_m'])
            basis='analytical-tangents-and-circular-fillets'
            if any(c.get('radius_m',math.inf)<300 for c in controls):
                # A boundary fragment can be too short for a normal curve.
                # Retain it as unreleased raster geometry rather than claim
                # a subminimum circular fillet is a compliant design.
                samples=points;controls=[];basis='retained-raster-requires-geometry-review'
            cells=[[round(r/cell),round(c/cell)] for r,c in samples]
            for rc in cells:
                if not 0<=rc[0]<seed['grid_height'] or not 0<=rc[1]<seed['grid_width']:raise ValueError('Reworked corridor outside grid')
                if not new or rc!=new[-1]:new.append(rc)
            segments.append(dict(seed_from_index=i,seed_to_index=end-1,control_points=waypoints,controls=controls,
                geometry_basis=basis,original_length_m=sum(distance(a,b) for a,b in zip(points,points[1:])),
                analytical_length_m=sum(c['length_m'] for c in controls) if controls else sum(distance(a,b) for a,b in zip(points,points[1:]))))
            i=end
        water_changes=[]
        if water_mask is not None:
            spec=importlib.util.spec_from_file_location('baghdad_water_routes',ROOT/'tools/automation/water-route-constraints.py')
            water=importlib.util.module_from_spec(spec);spec.loader.exec_module(water)
            new,water_changes=water.repair(new,water_mask,cell,1000,buildable,600)
            new=[list(c) for c in water.sampled_cells(new)]
            if water_changes:
                for segment in segments:
                    segment['superseded_analytical_controls']=segment['controls'];segment['controls']=[]
                    segment['geometry_basis']='superseded-by-water-constrained-route-requires-geometry-review'
        removed_spikes=[]
        if line['shape']=='Ring':new,removed_spikes=remove_short_ring_spikes(new,cell)
        line['cells']=new
        rows.append(dict(line=line['name'],original_cells=len(original),reworked_cells=len(new),
            original_route_m=sum(distance(a,b)*cell for a,b in zip(original,original[1:])),
            reworked_route_m=sum(distance(a,b)*cell for a,b in zip(new,new[1:])),core_runs=segments,water_constraints=water_changes,
            final_core_route_m=sum(distance(a,b)*cell for a,b in zip(new,new[1:]) if inside(a) and inside(b)),
            removed_quantization_spikes=removed_spikes))
    return result,dict(schema_version=2,status=config['release']['status'],core=core,lines=rows,
        core_original_length_m=sum(s['original_length_m'] for l in rows for s in l['core_runs']),
        core_analytical_length_m=sum(s['analytical_length_m'] for l in rows for s in l['core_runs']),
        core_final_route_length_m=sum(line['final_core_route_m'] for line in rows),
        analytical_length_basis='Pre-water-constraint concept; quantities use the final water-constrained corridor.',
        limitations=['Elevated rail does not grant air/property rights or remove buildings. Survey, clearance, heritage/security restrictions, pier access and utilities remain open.',
            'Circular planning fillets need cant, transition curves, vertical alignment and independent review; a rounded raster is not a construction centerline.',
            'Water stays separately engineered bridge scope; station/interchange placement, fleet, civil quantities and cost must be regenerated.'])

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--check',action='store_true');args=parser.parse_args()
    if (ROOT/'design/network-planning/baghdad-compact-expansion.json').exists():
        from baghdad_compact_network import run as compact_run
        compact_run(args.check);return
    seed=json.loads(gzip.decompress(SEED.read_bytes()));grid=json.loads(GRID.read_text());config=tomllib.loads(CONFIG.read_text())
    import numpy as np
    mask_path=OUT/'planning-water-mask.bin.gz';receipt_path=OUT/'water-source-receipt.json'
    raw=gzip.decompress(mask_path.read_bytes())
    if hashlib.sha256(raw).hexdigest()!=json.loads(receipt_path.read_text())['mask_sha256']:raise ValueError('Changed water evidence')
    mask=np.frombuffer(raw,dtype=np.uint8).reshape(grid['height'],grid['width'])
    buildability_path=OUT/'planning-buildability-mask.bin.gz'
    if not buildability_path.is_file():
        if args.check:raise ValueError('Missing retained buildability constraints')
        packed=bytearray(gzip.compress((ROOT/'.cache/osr-pipeline/rasters/baghdad.buildability.npy').read_bytes(),mtime=0));packed[9]=255;buildability_path.write_bytes(packed)
    buildable=np.frombuffer(gzip.decompress(buildability_path.read_bytes()),dtype=np.uint8).reshape(mask.shape).astype(bool)
    corridors,report=rework(seed,grid,config,mask,buildable)
    from residential_route_expansion import expand
    corridors,expansion,expansion_inputs=expand(CITY/'design.toml',corridors,grid,mask,buildable,args.check)
    report['residential_line_expansion']=expansion
    row_by_name={row['line']:row for row in report['lines']}
    changed_names={row['line'] for row in expansion['base_line_junction_changes']}
    original_names={r['line'] for r in report['lines']}
    for line in corridors['lines']:
        total=math.fsum(distance(a,b)*grid['cell_m'] for a,b in zip(line['cells'],line['cells'][1:]))
        def in_core(cell):
            lat=grid['bbox_north']-(cell[0]+.5)*grid['cell_m']/grid['m_per_deg_lat']
            lon=grid['bbox_west']+(cell[1]+.5)*grid['cell_m']/grid['m_per_deg_lon']
            return config['core']['south']<=lat<=config['core']['north'] and config['core']['west']<=lon<=config['core']['east']
        core_m=math.fsum(distance(a,b)*grid['cell_m'] for a,b in zip(line['cells'],line['cells'][1:]) if in_core(a) and in_core(b))
        if line['name'] in original_names:
            row=row_by_name[line['name']];row.update(reworked_cells=len(line['cells']),reworked_route_m=total,final_core_route_m=core_m)
            if line['name'] in changed_names:
                for run in row['core_runs']:
                    run['superseded_analytical_controls']=run.get('controls',[]);run['controls']=[]
                    run['geometry_basis']='superseded-by-continuous-junction-route-requires-profile-and-structural-review'
            continue
        report['lines'].append(dict(line=line['name'],original_cells=0,reworked_cells=len(line['cells']),
            original_route_m=0,reworked_route_m=total,core_runs=[],water_constraints=[],final_core_route_m=core_m,
            geometry_basis='population-led additional corridor; curve/profile and structural review open'))
    report['core_final_route_length_m']=math.fsum(line['final_core_route_m'] for line in report['lines'])
    report['sources_sha256']={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),CONFIG,SEED,GRID,mask_path,receipt_path,buildability_path,ROOT/'tools/automation/water-route-constraints.py',*expansion_inputs]}
    # Sub-micrometre libm differences across supported Python versions must
    # not change planning-report bytes. Grid cells remain exact integers.
    def planning_precision(value):
        if isinstance(value,float):return round(value,6)
        if isinstance(value,list):return [planning_precision(item) for item in value]
        if isinstance(value,tuple):return [planning_precision(item) for item in value]
        if isinstance(value,dict):return {key:planning_precision(item) for key,item in value.items()}
        return value
    report=planning_precision(report)
    files={CITY/'corridors.json':json.dumps(corridors,indent=2)+'\n',OUT/'core-realignment.json':json.dumps(report,indent=2,sort_keys=True)+'\n',CITY/'alignment-policy.toml':CONFIG.read_text()}
    for p,text in files.items():
        if args.check:
            if p.read_text()!=text:raise ValueError('Stale core alignment: '+str(p))
        else:p.write_text(text)
    print(f"Core water-constrained corridor: {report['core_original_length_m']/1000:.3f} → {report['core_final_route_length_m']/1000:.3f} km; city-centre civil policy: elevated except water")
if __name__=='__main__':main()
