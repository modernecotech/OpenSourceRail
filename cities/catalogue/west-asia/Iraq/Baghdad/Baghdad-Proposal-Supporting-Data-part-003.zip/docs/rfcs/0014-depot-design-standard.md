# RFC 0014 — Depot Design Standard

**Status:** Draft — planning only, no site drawings ship with this RFC
**Date:** 2026-04-22
**Depends on:** [RFC 0008 Rolling-Stock Reference Design](0008-rolling-stock-reference-design.md), [RFC 0010 Station Design Standard](0010-station-design-standard.md), [RFC 0011 Civil Infrastructure Design Standard](0011-civil-infrastructure-design-standard.md), [RFC 0013 Operations Rulebook](0013-operations-rulebook.md)

## 1. Summary

The current city catalogue adopts **one full-fleet planning depot per line**,
sized to that line's complete stock and actual train length. Storage tracks and
workload-sized maintenance bays are separate quantities. Depot PV/storage is
priced once; property, access alignment, yard topology, installed quotations and
morning launch capacity remain releases. The controlled generic quantities are
in [`city-operating-scope.toml`](../../lib/templates/city-operating-scope.toml)
and each city's `engineering/line-depots/summary.json`. Baghdad retains its
dedicated revised scope and financing ledger.

The distributed-stabling pattern below is retained as the earlier reference
and simulation comparison. Its passenger-platform parking assumptions do not
reduce the current full-fleet depot capital requirement.

### 1.1 Retained distributed-stabling reference

OpenSourceRail commits to **three depot archetypes** covering the
full range of deployment sizes. Every deployment has exactly one
**main depot** plus optional secondaries and layups. The main
depot co-locates with a `depot-terminal` station
([RFC 0010 §1](0010-station-design-standard.md#1-summary)).

The default operating pattern is **distributed overnight stabling**:
clean, telemetry-healthy trainsets may finish service at powered
passenger stations or layups near their first morning trip instead of
all running empty to a terminal depot. This reduces depot stall
requirements, avoids wasteful dead mileage, and lets first departures
begin across the line at the same time. The main-heavy remains the
maintenance authority. Defective trains are held and recovered to a service
point on their own line; maintenance planning must not assume an interline
rail connection. Two revenue trains per selected station form the
morning launch stock; remaining revenue trains and reserves stable at a
powered service point on their own line. Storage tracks are sized separately
from workshop bays, using reusable depot/layup blocks.

| Archetype | Catalogue max stalls | Heavy maintenance | Overhaul throughput | Notes |
|---|---|---|---|---|
| `main-heavy` | 20 | Yes — overhaul bay, wheelset lathe | ≤ 40 trainsets | Larger workshops require a controlled site-specific extension |
| `secondary-medium` | 12 | Light only — brake disc, door actuator, HVAC modules | — | Second depot on a long line |
| `layup-minimal` | 6 | None — overnight stabling only | — | Remote-terminal layup |

The **catalogue max** is the reference layout envelope. The per-deployment
workshop requirement comes from §4 (`max(4, ceil(fleet × 0.15))`). It is not
an overnight parking allowance. Requirements beyond that envelope need an
explicit site design; a template ceiling must not silently truncate them.

Plus one optional type for edge cases:

| Archetype | Purpose |
|---|---|
| `training-wing` | Co-located operations-training facility — OCC dispatcher-console simulators, maintenance-technician workshop mock-ups, and recovery-mode-crew briefing rooms. OSR is GoA 4 driverless ([RFC 0015](0015-driverless-operation.md)), so there are **no revenue-service drivers to train** — the wing exists for dispatchers, maintainers, station staff, and the recovery-mode crew who operate the manual-fallback joystick ([RFC 0015 §8.2](0015-driverless-operation.md#82-recovery-mode-cabinet)). Opt-in on `main-heavy`; not a standalone depot. |

**All depots are at-grade.** Per [RFC 0011 §1](0011-civil-infrastructure-design-standard.md#1-summary)
depots are never elevated — the footprint is too large to
economically put on viaduct. A deployment that can't site its
depot at-grade has an alignment problem, not a depot problem.

## 2. Non-goals

- **Not a workshop management system.** How the depot schedules
  its work — CMMS, parts management, labour planning — is owned
  by the operator and overlays with the `osr-cbm-backend` output.
- **Not an off-line overhaul facility.** Major overhauls (wheel
  reprofiling at 150 000 km, bogie overhaul at 600 000 km, body
  overhaul at 10 years) happen in the `main-heavy` depot's
  overhaul bay. Deployments without a main-heavy either
  contract overhaul out or depot-trip their fleet to a sister
  network.
- **Not a yard-design manual.** Track yard geometry within the
  depot boundary uses RFC 0009's `standard-urban` or (for large
  shunting yards) a depot-specific geometry variant. Detailed
  yard layout per facility.
- **Not an HR / workforce document.** Shift patterns and
  headcount from the ops rulebook (RFC 0013) and the workforce
  template.
- **Not a brownfield-rehabilitation scope.** Where a deployment
  inherits an existing rail workshop (Samawah, Khartoum-Atbara,
  Karachi Cantt, Maputo Machava, etc.), [RFC 0027](0027-brownfield-pilot-asset-recovery.md)
  governs the conversion of the existing site into an OSR depot.
  This RFC's archetypes are the **greenfield** envelope; the
  brownfield path swaps greenfield depot CAPEX (use the current
  [cost template](../../lib/templates/capex-costs.toml) and reconcile energy inclusions) for
  workshop rehabilitation (~$0.5–2 M building + $1–3 M new
  OSR-specific tooling) — an order-of-magnitude saving that the
  per-deployment plan should commit to whenever assets are real.

## 3. Why three archetypes

Depots are where the simplicity bet pays off most. The three-
archetype set covers:

- **`main-heavy`** — the one non-negotiable facility per
  deployment, where heavy maintenance happens.
- **`secondary-medium`** — for deployments whose geography makes
  defect and light-maintenance access to the main depot impractical.
- **`layup-minimal`** — storage at a line’s powered service location for
  stock beyond the two-train station provision; no separate heavy workshop
  or interline connection is implied.

The catalogue provides reference envelopes. A workshop exceeding the reference
bay count needs a controlled extension at the deployment main depot, including
access, equipment and staffing capacity.

## 4. Fleet-sizing formula

**Historical distributed-stabling comparison.** The workshop and overnight
allocation formulas below belong to the earlier reference. Current full-fleet
line depots use the workload, storage and price controls linked in §1; the
current Samawah quantities are generated in [RFC 0003](0003-samawah-reference-deployment.md).

Workshop bays are sized for concurrent maintenance and inspection. Two revenue
sets stable at each selected powered passenger station where fleet permits;
remaining revenue trains and reserves use separate depot stabling tracks:

```text
  main_depot_workshop_bays = max(4, ceil(total_fleet × 0.15))
  secondary_depot_bays = site-specific exception
  service_rotation = 0  # depot service is prohibited in peak windows
  total_fleet = peak_revenue_trainsets + service_rotation + spare + cold_reserve
  station_overnight_positions = 2 × unique_selected_station_count
  depot_overnight_trainsets = total_fleet - station_overnight_trainsets
```

The two-train station provision is an overnight allocation constraint. Allocate
remaining revenue trains and all reserves to same-line storage, preserving total
fleet inventory. Depot storage positions and usable track lengths are sized
separately from workshop bays. The earlier Samawah comparison allocated 40 trains to stations and 68
to storage on their own lines: 37 on Line 1, 16 on Line 2 and 15 on Line 3.
These comprise 57 revenue, eight spare and three cold reserve trains. The
storage requirement totals 4,046 m of usable slots at 59.5 m per train,
separately from the existing 17 main-depot workshop bays. Lines 2 and 3 reuse
their powered service terminals. Local storage layouts need detailed design;
interline depot connections are not part of the operating requirement.

- `peak_revenue_trainsets` = what the schedule requires at peak.
  Sized from the physical round-trip cycle vs. the peak headway:

  ```text
    traversal_energy_kwh = line_length_km × cars × 2.4 × 1.25 × 1.25
    charging_dwell_s = ceil_30s(3600 × traversal_energy_kwh / sum(charger_kw))
    charging_dwell_s = clamp(charging_dwell_s, 120, 600)
    added_dwell_min  = charging_stops × max(charging_dwell_s / 60 - 1, 0)
    stop_count       = station_count - 2  # radial; station_count for a ring
    one_way_min      = (line_length_km / cruise_speed_kmh) × 60
                       + stop_count × stop_penalty_min
    radial_cycle_min = 2 × one_way_min + 2 × 3 + 2 × added_dwell_min
    ring_cycle_min   = one_way_min + added_dwell_min
    peak_revenue_trainsets = max(2, ceil(cycle_min × recovery_factor / headway_min))
  ```

  Current [native emitter](../../crates/osr-design/src/emit.rs) parameters:

  | Family | Cruise km/h | Stop penalty min | Recovery factor | 500 kW cabinets per powered station |
  |---|---:|---:|---:|---:|
  | tram-2car | 48 | 1.45 | 1.10 | 1 |
  | light-metro-3car | 62 | 1.35 | 1.62 | 1 |
  | metro-4car | 72 | 1.30 | 1.30 | 3 |
  | metro-6car | 72 | 1.30 | 1.45 | 4 |

  Radials use a three-minute peak headway and a three-minute turnback at
  each end; rings use a six-minute peak headway. The stop penalty includes
  the one-minute reference dwell, and only charging dwell above that reference
  is added. The energy balance uses a 25% climate uplift and a separate 25%
  charging margin. The larger recovery factors include the emitter's retained
  onboard-energy resilience allowance; they are planning assumptions requiring
  city-specific service and energy evidence, not a uniform 10% timetable margin.

  These parameters replace the former written 35 km/h proxy and uniform
  1.10 recovery factor. Existing city fleet inventories remain declared inputs;
  reconcile regeneration changes with timetable, energy, cost and physical
  stabling evidence before adopting a different count. This formula does not
  enforce two trainsets per station. Station capacity must be checked separately.

- `spare` = max(1, floor(peak_revenue_trainsets / 10)), for planned
  maintenance rotation.
- `cold_reserve` = 1 per line, for unplanned incidents per
  [RFC 0013 §7](0013-operations-rulebook.md#7-incident-categorisation).
- `service_rotation` = zero dedicated sets. Depot service is prohibited in
  the 3-minute peak windows and uses surplus peak-fleet capacity when the
  timetable relaxes to 6 or 12 minutes.

The 12-minute service happens at one designated service depot per line only
in lower-frequency windows. During 07:00–09:00 and 15:00–17:00, trains make
the normal quick terminal turnback, can use the platform connector, and may
deplete the battery further while the 20% section-entry reserve remains
mandatory.
Interior cleaning, exterior/running-gear walk-around, door, coupler and
emergency-equipment release checks, fault-log download, and a 150 kW low-C
recharge run concurrently. A red defect removes the set from rotation and
uses a planned spare; a clear inspection releases it straight back to
revenue service. The opposite terminal may still top up or stable a train,
but does not repeat the full inspection on the same round trip.

The 15% workshop concurrency allowance covers overhaul, defect repair,
incoming inspection, and planned maintenance. Growth beyond the 20-bay
catalogue envelope requires a controlled workshop extension; it does not restore
fleet-wide depot parking.

Distributed overnight stabling does **not** increase the service-rotation
fleet. End-of-service dispatch assigns healthy trainsets to powered
stations with CCTV monitoring, remote isolation, and at least
low-C charging access capped by installed equipment. The 150 kW rate is a top-up target, not a minimum station rating. Morning dispatch releases those sets from
their stabled stations so outer stops do not wait for trains to run out
from the terminal depot. The main-heavy stall formula remains sized for
maintenance, inspection, overhaul, spares, and growth rather than for
parking every healthy set every night.

Historical Samawah comparison (September 2026, 3-min peak headway):

- The earlier figures are retained in the
  [historical Samawah reference](../reference/history/samawah-pre-core-planning.md).
  The [current city summary](../../cities/catalogue/west-asia/Iraq/Samawah/README.md)
  adopts the full-fleet line-depot requirement.
- The September 2026 design has fleets of 53, 28 and 27 trainsets: 108 total.
  The [depot reconciliation](../../cities/catalogue/west-asia/Iraq/Samawah/engineering/depot-scope/README.md)
  derives initial placements and slot-length requirements from the stored
  scenario. Physical overnight allocation remains unverified.
- `design.toml` emits the depot archetype, terminal assignment, and
`fleet_stalls` as workshop/inspection bays from the same run. Older 1.25×
fleet-parking examples and hand-calculated 6/4/8
  trainset examples were removed from the docs and must not be copied
  into current deployment documents.

The emitter (RFC 0014 v2) computes this from the design.toml's
`fleet_sizing` block.

## 5. `main-heavy` envelope

### 5.1 Functions

- Workshop holding for inspection, scheduled work and defective trainsets
  (bay count per §4); overnight fleet allocation requires a separate plan.
- Daily inspection of every incoming trainset.
- Weekly inspection (7-day service).
- 30-day inspection (A-class service per EN 50126).
- Light repair (door actuator, HVAC module, brake-disc
  replacement, battery module swap).
- Heavy overhaul: bogie swap, wheel reprofiling on depot lathe,
  body-work repaint.
- Wash: automated two-pass wash track.
- Battery-module inspection, coolant service, and sealed-module exchange.

### 5.2 Physical layout

| Area | Target footprint (per consist bay) |
|---|---|
| Stabling track | 1× consist length + 5 m clearance at each end |
| Daily-inspection bay | Roofed, pit-equipped, overhead power, compressed air, data sync drop (TCN-E monitoring) |
| Weekly bay | Pit + roof walkway for upper-body access |
| Overhaul bay | Pit + overhead crane (40 t) + wheel-lathe trench |
| Wash track | Two-pass automatic with water recycling |
| PV canopy | 4 000 m² reference allowance; full operating PV inventory needs additional located area (§5.3) |
| Classroom + office | ≥ 200 m² for operators + trainers |
| Stores | ≥ 600 m² with rack storage for spare modules |

Total `main-heavy` footprint: ~5 000 m² gross for a 10-stall
facility, ~8 000 m² for a 20-stall. These historical workshop envelopes do
not include the complete operating PV/storage inventory and cannot be used as
total deployment land requirements.

### 5.3 Energy

- [`depots.toml`](../../lib/templates/depots.toml) selects the canonical
  [`energy-sites.toml`](../../lib/templates/energy-sites.toml) tier. `main-heavy`
  uses `depot-main`: **5,000 kWp PV and 40,000 kWh storage**, comprising
  **80 × 500 kWh stationary modules**. Scenario, BOM and layout requirements
  resolve the same inventory; explicit site overrides must remain traceable.
  These are retained operating assumptions, not validated depot sizing.
  Reassess energy duties with distributed overnight station charging before
  freezing procurement or depot land requirements.
- The old **4,000 m² / 600 kWp / 2,000 kWh** scope is a reference allowance.
  At the catalogue density of 0.15 kWp/m², 5,000 kWp requires **33,333 m² of
  modules**, before access, setbacks and packing. Additional land/canopy and
  the battery compound are not yet located by the reference CAD.
- Annual PV generation must come from the city energy study with declared
  weather and loss assumptions. A nameplate rating alone is not annual yield.
- Stationary storage feeds the RFC 0021 DC charging system. Supplier dimensions,
  conversion/protection equipment, fire separation and installed cost require
  explicit reconciliation with the fixed depot allowance.
- Grid import/export must satisfy the declared connection limits and utility
  study. Per [RFC 0002](0002-energy-sizing.md), every depot is one physical
  `osr-energy-site`, including when co-located with a passenger station.

### 5.4 Signalling

- A single W-SBC plus an interlocking zone boundary at the depot
  entry.
- Inside the depot, speed limit 15 km/h, manual operation under
  mode M3 ([RFC 0013 §5](0013-operations-rulebook.md#5-degraded-mode-operations--the-important-part)).
- Shunting signals at each stall entry — mechanical dwarf signals
  driven by `osr-wayside-points` extensions.
- No ATP envelope inside the depot; `osr-atp` disables below
  15 km/h in depot-tagged geofence, per a safety-bounded
  configuration. The operational safety envelope inside the
  depot is line-of-sight + hand-signal coordination.

### 5.5 Access

- Personnel access: turnstile-gated with ID-card entry, separate
  from the fleet access.
- Fleet access: one track connection to the line, TPS-style
  merge per [RFC 0012 §4.3](0012-switches-and-crossings.md#43-facing-vs-trailing)
  (trains go in — it's a trailing move).
- Road access: for parts delivery, emergency services, depot
  staff parking. Minimum one 4 m-wide road connection.
- Rail access for deliveries of new trainsets is via the same
  line connection (new rolling stock rolls in on its own wheels).

## 6. `secondary-medium` envelope

- Functions: overnight stabling for ≤ 16 trainsets, daily
  inspection, weekly inspection, light module swap.
- **No overhaul bay. No wheel lathe. No bogie-lift.** Anything
  heavier is trips back to the main-heavy.
- Footprint: ~2 500 m² for 8 stalls.
- Reference PV canopy: 1,500 m² / 225 kWp, with 500 kWh baseline storage.
- Operating `depot-secondary` tier: 1,500 kWp PV and 5,000 kWh storage
  (10 × 500 kWh modules); additional placement and installed cost remain open.
- Signalling: same as main-heavy but smaller zone.
- Classroom: none. Reuse the nearest `major` station's
  community room if needed.

## 7. `layup-minimal` envelope

- Functions: overnight stabling, low-C top-up, cleaning, and a ground-level
  safety-release walk-around. Trainsets drive in at end of service, can pass
  through the same 12-minute turnaround service if the site is designated
  for its line, sit overnight, and drive out at morning service start. There
  is no pit inspection, repair work, or heavy maintenance.
- Footprint: ~1 000 m² for 4 stalls.
- PV canopy: 600 m² → 90 kWp.
- Operating `depot-layup` tier: one 150 kWh stationary package for
  opportunity charging during dwell; the main-heavy is primary.
- Train top-up: 150 kW low-C per occupied stabling road, used while a set is
  held between duties and overnight; passenger-platform fast charging remains
  a separate terminal function.
- Signalling: single W-SBC at the layup entry; rest is manual
  line-of-sight.
- No personnel on-site overnight; the OCC monitors via CCTV.

## 8. Integration with the auto-gen pipeline

Today's emitter picks one `depot-terminal` archetype ([`crates/osr-design/src/emit.rs`](../../crates/osr-design/src/emit.rs),
`compute_archetypes`, priority rule). That choice is where the
main-heavy sits. v2 of the emitter extends this:

1. **Main depot:** co-located with the longest radial line's far
   terminal. The station archetype is `depot-terminal`; the
   depot archetype is `main-heavy`.
2. **Powered station stabling:** every other terminal and selected intermediate
   powered stations receive healthy sets overnight; they do not emit depots.
3. **Secondary/layup exception:** emit only after a site-specific security,
   utility, access, or defect-recovery study shows station stabling is not viable.

Every depot writes a record into `design.toml`:

```toml
[[depots]]
station          = "line-a-east"
archetype        = "main-heavy"
fleet_stalls     = 4  # illustrative workshop bays; calculate per §4
energy_site_tier = "depot-main"  # optional: selected by the archetype
```

The scenario generator resolves depot energy tiers into `[[sites]]` and
operating service settings into the simulator input. The simulator
([`osr-sim`](../../crates/osr-sim/)) models service countdowns and energy flows.
A future physical distributed-stabling model must satisfy these requirements:

- Charges each trainset at depot pad power while held and overnight.
- Treat powered passenger stations and layups as valid overnight stabling
  points when the distributed-stabling policy is enabled in
  [`lib/templates/depots.toml`](../../lib/templates/depots.toml).
- Holds a returning train for the configured clean/inspect/recharge slot at
  one designated depot per line and emits service-start/service-complete
  evidence.
- Preserves the zero dedicated service-rotation policy and distinguishes
  planned spares and cold reserve from revenue fleet requirements.
- Feeds the depot battery bank into the network-wide energy
  balance.

### 8.1 Executable station-stabling candidate

The simulator supports `station_stabling = true` in scenario `[[fleets]]`,
with selected powered-station `dispatch_points`. Stations may use solar/storage
without grid import. Waiting trains use up to 150 kW, capped by installed
station and shared cabinet/source limits, for low-C top-up to 95% SoC; after closing, returning trains hold at selected
stations and resume under schedule, energy and movement-authority gates.
This does not require returning healthy trains to the main depot.
Before departure, a distributed train must retain the 20% reserve over the
route to the next selected charging station, including unpowered stops and
terminal reversals. A failed pad or unavailable energy source excludes a
destination. A grid outage alone does not disable a battery-backed charger.
The gate checks current source availability; it does not reserve future energy
against other arrivals. Actual charging debits shared storage, and each next
departure rechecks the onboard reserve. Continuous replay verifies the duty.
Optional `spare_count` and `cold_reserve_count` are included in each fleet's
total inventory and default to zero. Candidates use the city's declared
counts; these trains remain parked and can charge without routine dispatch.

The [distributed-stabling workflow](../operations/distributed-stabling.md)
generates separate candidates for all catalogue cities and records the Samawah
overnight comparison, checking each planned line/station/direction at opening.
Plans compare allocated train lengths with the reference platform envelope.
The planning/replay acceptance gate also limits overnight allocation to two
trainsets per selected station, including reserves. Shared station IDs count
once; a four-berth reference platform does not override this provision. The
simulator exposes over-capacity queues for diagnosis, and the combined replay
fails even when holding, charging and morning departures otherwise pass.
Verified physical slots, security, inspection release, reserve activation,
defective-train routing, full-day energy duty and deployment acceptance remain open.

## 9. Pitfalls and decisions

- **At-grade only, per RFC 0011.** Depots are large; elevating
  the footprint is prohibitively expensive. The auto-gen
  emitter rejects depot siting on an elevated section.
- **One reference `main-heavy` everywhere.** Operators with
  unique geography (coastal, mountainside) will push for
  bespoke depots. The upstream catalogue stays at one shape;
  the deployment's civil team handles the site-specific
  adaptation.
- **Wheel lathe at the main-heavy only.** Decentralising lathes
  is tempting (saves depot-trip time) but the operator depth for
  wheel-reprofiling is thin in target regions; centralising at
  one site lets that thin team do all the work.
- **No pit at `layup-minimal`.** A pit adds cost, safety
  maintenance, and lighting — just for overnight parking. Skip.
- **Depot simulation in `osr-sim`.** The sim models depot top-up while held
  plus an explicit service countdown at the designated depot. Cleaning,
  release inspection, diagnostics, and recharge are concurrent; deeper
  maintenance remains a separate availability/CMMS model.
- **Distributed stabling is not distributed maintenance.** Overnight
  passenger-station stabling is allowed only for healthy sets with remote
  isolation and CCTV. Any trainset needing inspection beyond the daily
  release walk-around, fault rectification, wheel work, or battery-module
  exchange goes to the main-heavy.

## 10. Rollout

| Phase | Deliverable | Dependencies |
|---|---|---|
| **v0** | This RFC ratified | — |
| **v1** | Shared energy tier, BOM quantities and layout requirements reconciled (2026-09-09); full equipment placement and installed cost remain open | v0 |
| **v2** | Retained Rust seed and distributed-stabling studies; catalogue post-processing now prices one full-fleet depot per line | v0, RFC 0010 v2 |
| **v3** ✅ | `osr-sim` turnaround-service state (clean / inspect / diagnostics / recharge), service countdown and event evidence (done 2026-08-12) | v2 |
| **v4** | Accepted site/access/topology plans for all current Samawah line depots, with separately verified launch and maintenance capacity | Current full-fleet scope, v3 |
| **v5** | Reference depot CAD under CERN-OHL-S v2 | v4 |

## 11. Relationship to existing work

- [`lib/templates/depots.toml`](../../lib/templates/depots.toml)
  — schema this RFC ratifies.
- [`crates/osr-design/src/emit.rs`](../../crates/osr-design/src/emit.rs)
  — auto-gen emitter. `depot-terminal` detection today; the
  `[[depots]]` block emission is v2.
- [`crates/osr-energy-site`](../../crates/osr-energy-site/) —
  every depot is one `osr-energy-site` instance; existing
  integration holds.
- [`crates/osr-sim`](../../crates/osr-sim/) — modest extension
  for v3; charging semantics already work.
- [RFC 0010](0010-station-design-standard.md) `depot-terminal`
  archetype pairs 1:1 with this RFC's `main-heavy` or a mix of
  main-heavy + layup.

## 12. Open questions

1. **Co-located vs detached training wing.** Some operators
   prefer the training simulator in a quiet city building
   (closer to drivers' homes). The catalogue default is co-
   located with the main depot; per-deployment override.
2. **Decentralised battery swapping.** A future opt-in where
   trainsets exchange their battery pack at depot instead of
   recharging — halves the charging-pad occupancy. Out of
   scope upstream until battery-swap mechanical designs mature.
3. **Night-shift head count.** Ops rulebook §4.5 (RFC 0013)
   fixes the shift structure; what's the minimum overnight
   staff headcount at a `layup-minimal`? Currently zero
   (CCTV-monitored); confirm when the first `layup-minimal`
   deploys.
4. **Depot expansion path.** A `secondary-medium` that outgrows
   its 8 stalls — does it upgrade to `main-heavy` in place, or
   is a second-depot-nearby preferred? Likely the latter given
   construction-on-live-facility complexity.

## 13. Done criteria

- [x] Three archetypes committed (§1)
- [x] Fleet-sizing formula (§4)
- [x] Main-heavy envelope (§5) + secondary-medium (§6) + layup-minimal (§7)
- [x] Auto-gen pipeline integration (§8)
- [x] Pitfalls (§9)
- [x] Rollout ordered (§10)
- [x] Relationship to existing software + templates (§11)

Next: locate the full PV/storage inventory, reconcile installed cost, and
provide track-by-track overnight allocation and conflict-aware run-in/run-out
evidence. The quantity contract alone does not satisfy those release gates.
