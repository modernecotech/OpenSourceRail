# T-OBS — Train Obstacle Detection

**Role:** Nose-mounted obstacle-detection ECU for cabless GoA 4
operation. Each module fuses ultrasonic transducers, solid-state
LIDAR, mmWave radar, and a stereo camera pair, then sends a
fail-restrictive brake-demand/verdict interface to T-ECU/S.

Canonical `light-metro-3car` fit: **2 modules per trainset**, one
behind the A-end nose cowl and one behind the B-end nose cowl. The
matching mechanical envelope is `trainset-tobs-sensor-pack.png` and
`design/component-catalogue/src/osr_mech/rolling_stock/systems.py`.

## Architecture

The pilot T-OBS mirrors the T-ECU/S evidence rig: two RP2350 evaluator channels
cross-check each other, while a CM5 performs non-safety sensor
pre-processing and logging. The RP2350 pair owns the final
obstacle-detection verdict. This is not a SIL qualification claim; production
channels follow the shared [safety-controller selection gate](../safety-controller-selection.md).

See:

- [`schematics/v2-spec/`](schematics/v2-spec/) for the board-level v2
  schematic specification.
- [`diy-assembly/`](diy-assembly/) for the off-the-shelf first-article
  build.
- [`../rolling-stock-integration.md`](../rolling-stock-integration.md)
  for trainset quantities and BOM alignment.

## Target BOM

The historical custom-board planning allowance is carried by rolling-stock
BOM line E18. The former ~$2.4k DIY subtotal is withdrawn as an assembled-host
price: power, watchdogs, output feedback, harness and environmental integration
were incomplete. Freeze and quote the complete assembly before reconciling the
planning allowance. See [reference integration](../reference-integration.json).

## Status

- Pilot / DIY track: [`diy-assembly/`](diy-assembly/) uses commodity
  SBC, Pi Pico 2, and sensor-evaluation modules. Integration evidence
  is still pending.
- Custom-board track: `schematics/v2-spec/` is the board-level v2
  specification. `gerbers/` and `bom/` will be created when a KiCad
  layout and v2 board BOM are released.
