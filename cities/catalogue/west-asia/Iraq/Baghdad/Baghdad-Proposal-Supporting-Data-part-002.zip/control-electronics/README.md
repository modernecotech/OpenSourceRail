# OpenSourceRail Control Electronics

The [reference integration source](reference-integration.json) and revised
[host bench requirements](diy-assembly/README.md) include the corrected
power, watchdog, bus and pin interfaces. The [Baghdad detail register](../cities/catalogue/west-asia/Iraq/Baghdad/engineering/detail/README.md)
adds six-car fleet quantities and required supplier/qualification evidence.
No complete onboard target image or qualified host BOM is released.

This directory owns the physical electronic hosts for the software stack:
processors, safety I/O, sensors, power interfaces, wiring, connectors and
enclosures. It does not contain embedded software, rolling-stock mechanical
parts, track products or civil works. Embedded implementations remain under
[`../crates/`](../crates/README.md); mechanical and civil component geometry
remains under the [`../design/component-catalogue/`](../design/component-catalogue/README.md).

Reference electronic designs are
scoped in [RFC 0007](../docs/rfcs/0007-control-electronics-reference-designs.md);
schematics and board-release artifacts land under each subdirectory as
the RFC 0007 rollout matures.

Control electronics have two valid release tracks:

1. **Pilot / DIY integration track.** RFC 0019 assembles commodity
   SBCs, Pi Pico 2 boards, sensor modules, HATs, relays, power
   supplies, terminal blocks, DIN-rail enclosures, and prepared
   SD-card images. No KiCad or gerbers are required when the build
   uses only COTS modules. The release evidence is the controlled
   integration pack: exact SKUs, wiring/harness maps, connector maps,
   enclosure drawings, power and thermal margins, firmware images,
   self-test output, and bench records.
2. **Custom-board fabrication track.** RFC 0007 board-level specs can
   be captured into KiCad when a deployment needs OSR-specific carrier
   boards, power conditioning, safety I/O, or sensor-interface boards.
   That track needs KiCad, gerbers, board BOMs, DFM/DFT review,
   assembly drawings, and board bring-up evidence.

**Commodity application hosts; separately qualified safety channels.**
Raspberry Pi and Radxa remain the simple pilot, application and diagnostic
palette. Safety-output hardware follows the assessor-controlled
[`safety-controller-selection.md`](safety-controller-selection.md) gate and may
use an industrial safety-MCU family. A commodity processor never bypasses the
external fail-safe output path.

| Class | Role | SoC baseline | RFC 0007 §  |
|---|---|---|---|
| [`t-ecu-s/`](t-ecu-s/) | SIL-4-target train safety kernel | Qualified safety-channel pair to be frozen; 2 × RP2350 pilot rig + CM5 app processor | §4 |
| [`t-ecu-a/`](t-ecu-a/) | Train application (SIL-2/-0) | Raspberry Pi CM5 (Radxa CM5 drop-in) | §5 |
| [`t-obs/`](t-obs/) | SIL-4-target obstacle verdict interface | Qualified evaluator channels to be frozen; 2 × RP2350 pilot rig + CM5 pre-processor | RFC 0015 §5 |
| [`w-sbc/`](w-sbc/) | Wayside application host | Radxa CM5; safety outputs through a separately qualified controller | §6 |
| [`s-sbc/`](s-sbc/) | Station / depot (SIL-0) | Raspberry Pi CM5 + commodity carrier | §7 |

`O-SRV` (ops server) is a commodity computer and has no reference
design in tree.

## Layout

Each class subdirectory has the same shape:

```
<class>/
├── README.md         class overview, SoC rationale, peripherals list
├── diy-assembly/     COTS/SBC pilot assembly notes per RFC 0019
└── schematics/       board-level specs; KiCad projects once custom boards are drawn
```

`bom/` and `gerbers/` are created only when they contain real release
artifacts; empty placeholder directories are not retained.

Current status:

| Class | Pilot / COTS integration | Custom-board package |
|---|---|---|
| `t-ecu-s` | `diy-assembly/` present; build evidence pending | Complete `schematics/v2-spec/` package; KiCad / gerbers / board BOM pending |
| `t-ecu-a` | `diy-assembly/` present; build evidence pending | `schematics/v2-spec/` overview and block diagram; KiCad / gerbers / board BOM pending |
| `t-obs` | `diy-assembly/` present; build evidence pending | Complete `schematics/v2-spec/` package; KiCad / gerbers / board BOM pending |
| `w-sbc` | `diy-assembly/` present; build evidence pending | `schematics/v2-spec/` overview and block diagram; KiCad / gerbers / board BOM pending |
| `s-sbc` | `diy-assembly/` present; build evidence pending | `schematics/v2-spec/` overview; custom board usually unnecessary |

Bring-up procedures are colocated with their host:
[`T-ECU/S`](t-ecu-s/bring-up.md), [`T-ECU/A`](t-ecu-a/bring-up.md),
[`T-OBS`](t-obs/diy-assembly/README.md), [`W-SBC`](w-sbc/bring-up.md) and
[`S-SBC`](s-sbc/bring-up.md).

The release gates for both tracks are tracked in
[`release-checklist.md`](release-checklist.md). Until a host class
meets the pilot track it is a design concept, not integration-qualified
pilot hardware. Until it meets the custom-board track it is not released
fabrication hardware.

For trainset quantities and the boundary between control-electronics records,
mechanical CAD envelopes, and the rolling-stock procurement BOM, see
[`rolling-stock-integration.md`](rolling-stock-integration.md).

## Licensing

Electronic designs (schematics, layouts, gerbers, board BOMs, and
integration drawings) are licensed under **CERN-OHL-S v2**. Firmware
stays under **Apache-2.0**
(inherited from the Rust crates). Documentation under
**CC-BY-SA 4.0**. See [ARCHITECTURE.md §9](../docs/ARCHITECTURE.md#9-roadmap)
for the project-wide licensing rationale.

## Contributing

High-leverage contributions are DIY/COTS build feedback against
[`diy-assembly/`](diy-assembly/), integration BOM completion, wiring
and enclosure review, KiCad capture where custom boards are justified,
and board DFM review for the custom-board track.
