<!-- osr-maglev-primary:start -->
> **Primary v0.5 ferrite-maglev planning:** [Open the current city planning package](engineering/maglev/README.md). Formation, duty, fleet, charging, depot quantities and partial cost allowances are recomputed; physical acceptance remains open.
>
> The material below this notice is the retained v0.4 wheel/rail comparator. Its costs, fleet, geometry and acceptance do not transfer to maglev.
<!-- osr-maglev-primary:end -->

# Diwaniyah — provisional network

**Engineering revalidation pending.** Current geometry and planning quantities are published below. The package remains incomplete; no engineering, manufacturing or physical release is claimed.

[Current design coverage and open gates](engineering/design-system/index.html) · [Exact package status](package-manifest.json).

| Current planning measure | Value |
| --- | --- |
| Lines | 5 |
| Route length | 62.3 km |
| Proposed platform records | 27 |
| Planned fleet | 198 trainsets |

![Current proposed network](diwaniyah-network-map.png)

[Source-bound corridor correction](engineering/alignment/network-correction.json) · [Independent geometry and transfer audit](engineering/alignment/network-topology.json).

| Line | Route km | Proposed platforms |
| --- | --- | --- |
| line-1 | 23.1 | 8 |
| line-2 | 12.0 | 6 |
| line-3 | 16.6 | 6 |
| line-4 | 4.7 | 3 |
| line-5 | 6.0 | 4 |

The geometry audit checks the retained water mask, line continuity, grouped platforms and self-intersections. Walking access, levels, detailed structures and site acceptance remain open.

## Evidence awaiting revalidation

Retained operating, energy, clearance and delivery reports apply to their recorded source revisions. This page gives them no current-layout pass. The package manifest lists stale and missing evidence.

[Retained operating evidence](engineering/simulation/validation-summary.json) · [Retained energy evidence](engineering/energy/summary.json) · [Clearance evidence](engineering/clearance/README.md) · [Planning finance and its assumptions](engineering/finance/summary.json).

Planning finance uses controlled assumptions and does not establish bids, funding commitments or operating performance.
