# Building the fleet and staffing the railway

The 30 km core railway requires 306 cars and 6,000 standard beams. Baghdad’s first programme requires 1,452 cars and 29,640 beams. Its independent citywide proposal requires 5,604 cars and 121,156 beams. A bidder can use the two dimensioned layouts below to price buildings, equipment, shifts and material handling, then replace each planning assumption with a quoted rate or timed demonstration.

| Delivery measure | Core 30 km | Baghdad first | Baghdad citywide |
|---|---:|---:|---:|
| Six-car trains, active + reserve | 44 + 7 | 210 + 32 | 812 + 122 |
| Vehicle production window proposed here | Months 12–36 | 2028–2030 | 2028–2034 |
| Car lines × maximum completions per line in window | 5 × 76 | 12 × 122 | 20 × 292 |
| Planned car deliveries / available places on those lines | 306 / 380 | 1,452 / 1,464 | 5,604 / 5,840 |
| Beam yards / erection fronts | 2 / 2 | 6 / 6 | 10 / 10 |
| Day-shift positions at full build rate, listed activities only | 202 | 624 | 1,040 |
| Depots / control centres used for staffing | 1 / 1 assumed | 4 / 2 | 12 / 4 |
| GoA4 establishment for listed operating duties, full-time equivalents | 312 | 1,526 | 6,339 |
| Trial handover target in parent programme | Month 43 | 2031 | 2035 |

The core quantities come from the selected v0.7 powered-wheel, overhead-supply digital configuration. The v0.6 passive-wheel development baseline retains its own equipment and service case. Baghdad has a separately costed six-car, 700-place vehicle with protected conductor collection, against the v0.7 car's 276-place train and overhead collector. All three programmes assume 18 hours of daily passenger service. The core 120-second and Baghdad 150-second peak headways give 8,280 and 16,800 offered places per hour per direction respectively. The Baghdad station dwell assumption is 35 seconds. Each source’s stopping, power, recovery and clearance conditions still apply. Factory throughput does not establish a working timetable. [Core production handoff](https://github.com/modernecotech/OpenSourceRail/blob/main/docs/reference-v07/digital/production/README.md) · [Baghdad train and service basis](https://github.com/modernecotech/OpenSourceRail/blob/main/cities/Baghdad/VEHICLE.md) · [Independent Baghdad network scopes](https://github.com/modernecotech/OpenSourceRail/blob/main/cities/Baghdad/COST-AND-DELIVERY.md)

## Vehicle works and repair access

![Dimensioned vehicle works showing the six 24 by 12 metre assembly positions, repair road, pit and 125 metre formation road](vehicle-works.svg)

Use one 160 × 80 m module per balanced line for land screening. The resulting works footprints before external approaches and stabling are 6.40, 15.36 and 25.60 ha respectively. Several lines can share receiving, specialist repair, QA or static test facilities once their combined queues and access are checked. A bidder should show trainset formation, a through connection to a segregated dynamic test track, road trailer turning, segregated coating and wash-water treatment, fire access and independent routes for people. A 125 m static road can hold one Baghdad 104.5 m train with 20.5 m of total remaining length. Coupling, shunting approach, stop margins, refuge and energized section lengths need a surveyed track layout. In service bid the overnight stabling paths, spare-train access and rescue siding against each depot’s assigned fleet.

Each build stage has a five-effective-day takt. The first car comes out after six stages, on effective day 30. Allow 85% line availability and an eight-hour shift with 80% of the technician’s time available for direct work while the line runs. A core window of 24 months at 20 workdays/month gives 408 effective days, or 76 completions per line. Baghdad uses 250 scheduled days/year. With only 12 spare car completions across **all twelve first-programme lines**, a delay of one takt affecting every line consumes the full margin. Price phased delivery, overtime and spare line options. Run a witnessed pilot before releasing parallel tooling.

| Stage | Core direct hours / staff on shift per line | Baghdad budget hours / staff on shift per line |
|---|---:|---:|
| Carbody joining and datum inspection | 260 / 9 | 260 / 9 |
| Bogie, axle and drive assembly | 120 / 4 | 120 / 4 |
| Doors and interior | 80 / 3 | 260 / 9 |
| HVAC and auxiliaries | 80 / 3 | 80 / 3 |
| Wiring, cooling, current collection and protection | 100 / 4 | 200 / 7 |
| Marriage, weighing and static test | 80 / 3 | 80 / 3 |
| **Per car / line** | **720 h / 26** | **1,000 h / 35** |

Core hours follow the production route. For Baghdad, the tender assumption allocates 30 hours per additional opening for six additional openings/car and 100 extra hours/car for its collection, wiring, cooling and protection scope. Matching allowances elsewhere need independent time studies on the Baghdad prototype. These budgets cover direct final assembly. Component manufacture, incoming logistics, rework, supplier shortages, infrastructure construction and dynamic qualification require their own hours. Each line has four additional day-shift positions for coordination, quality inspection, stores and materials handling. Independent release authorisation must be available even when work backs up. [Core manufacturing route](https://github.com/modernecotech/OpenSourceRail/blob/main/docs/reference-v07/manufacturing/README.md) · [Baghdad equipment interfaces](https://github.com/modernecotech/OpenSourceRail/blob/main/cities/Baghdad/VEHICLE.md)

### What local final assembly could cost

| Direct final-assembly labour, 2026 US$ | Low | Central | High |
|---|---:|---:|---:|
| One repeat car, 1,000 direct hours | 10,020 | 10,975 | 12,883 |
| One six-car train, 6,000 direct hours | 60,122 | 65,848 | 77,299 |
| 242-train first order | 14.55m | 15.94m | 18.71m |
| 934-train citywide order | 56.15m | 61.50m | 72.20m |

These figures identify labour **inside the train purchase price**. They assume Iraqi direct hires throughout final assembly. For the six stages in production order, the assumed daily gross wages before the rail premium are IQD 65,000 / 75,000 / 55,000 / 75,000 / 75,000 / 76,250. For the body assume three skilled welders or fitters to one semi-skilled assistant. For doors and interiors assume equal skilled and semi-skilled time. Bogie assembly, HVAC and wiring use skilled trades. Final marriage and testing assume three skilled technicians to one engineer. The model applies the low, central or high pay premium and employer contribution described below. At 250 scheduled days, 85% line availability and 80% direct time per eight-hour shift, each 260-day paid year supplies 1,360 direct assembly hours. Multiply the grade-specific cost of a productive hour by the route hours at each stage. Round only after pricing the full train or order.

A supplier can replace these estimates with timed station work and its own pay schedule. The amounts scale repeat work and exclude tooling, bought-in components, factory support, excess staffing during line fill and run-down, materials, rework, contingency, margin and qualification. Factory staffing and utilisation in the awarded delivery schedule determine how much of the planned local work becomes paid employment. [Baghdad wage and exchange-rate evidence](#baghdad-operating-pay-in-2026-prices)

**Repair demonstration.** Receive the failed train on the isolated road and record car, bogie and symptom. Make the consist secure and verify traction, service battery, brake energy and coolant isolation. Position supports, drop the wheelset or brake module, inspect attachments, record replacement serials and measured torque, then test isolation, braking, collection and door interlocks before the independent release. Size each crane, jack, pit, hook, floor and external transfer using a weighed complete assembly, actual lift points, centre of gravity and the complete removal path. Installed lifting loads, trainset strip-down hours, building price and site rights await supplier and site evidence.

## Precast yard, stock and erection

![Dimensioned precast yard with receiving, batch plant, sixteen mould positions, 180 single-tier beam slots and haul road](precast-yard.svg)

A 240 × 140 m yard occupies 3.36 ha. The planning plots total 6.72, 20.16 and 33.60 ha respectively before satellite storage, access roads and temporary erection fronts. Use two banks of eight mould positions to price eight 10 m beams per productive day. A nominal 12 m bed position still needs a supplier’s stressing arrangement and anchorage length. If safe stripping takes more than two productive days, add beds or revise output. Transfer each marked beam to a single-tier 12 × 3 m slot on engineered bearers. Keep the release record, transport saddle, trailer, crane booking, pier readiness and road closure on one dispatch ticket. The core beam’s 29.964382 t bare digital mass and 37.4554775 t provisional hook load apply to the core lift study. Each city lift requires the actual released beam, rigging, lift radius and ground bearing checks. [Core lifted component](https://github.com/modernecotech/OpenSourceRail/blob/main/docs/reference-v07/manufacturing/README.md) · [Baghdad civil windows](https://github.com/modernecotech/OpenSourceRail/blob/main/cities/Baghdad/COST-AND-DELIVERY.md)

| Buffer or capacity check | Core | Baghdad first | Baghdad citywide |
|---|---:|---:|---:|
| Eight daily releases per productive yard, combined nominal output | 16 | 48 | 80 |
| Peak **month-end** stock in Baghdad schedule, across network | See early-start buffer below | 983 | 1,638 |
| Balanced places per yard required at that point | ≥440 | 164 | 164 |
| Standard single-tier places per yard | 180 | 180 | 180 |

The core schedule starts casting at month 8, starts erection at month 15 and finishes casting at month 31. Even running each yard at eight beams/day for all 16 remaining months at 20 workdays/month produces only 2,560 of its 3,000 beams. At least **440 beams per yard** must exist by erection start, including at least **260 extra places per yard** beyond the illustrated plot. That adds at least 9,360 m² of net storage slots per yard before transport aisles and lifting access. Faster early casting increases that requirement. Quote satellite land, temporary haul, double handling and yard cranes, or return a feasible revised casting and erection sequence.

Baghdad’s monthly model uses an 80% first-year ramp, 90% subsequent availability and a one-month release lag. The balanced 180-place yard has a margin of 16 slots above the largest calculated month-end allocation. Daily arrivals, closures, inter-yard imbalance, rejected batches and hold stock can exceed it. Request a daily transport/stock simulation and an overflow quotation before securing land. The 18 yard positions per operating shift assume four steel and strand, four mould and stressing, three batching and placement, three crane and yard transport, two QA/lab, one foreperson and one stores coordinator. Each field front adds eight positions for supervision, crane operator, two riggers, two alignment/installation staff and two traffic/access staff. Specialist lifting design, night watch, haul drivers, relief and subcontract crews need further cover.

## Employment and rosters

The peak production positions above sum vehicle direct posts (130 / 420 / 700), vehicle support (20 / 48 / 80), beam-yard shifts (36 / 108 / 180) and erection fronts (16 / 48 / 80). Those simultaneous jobs last through the relevant build packages. Vehicle direct content alone is 220,320 / 1,452,000 / 5,604,000 hours, equivalent to 128.1 / 844.2 / 3,258.1 job-years at 1,720 delivered hours per job-year. Establish what fraction will be performed locally from supplier and employee records. Operating staff and subcontracted build crews have different payrolls and employment dates.

| Operating role | Shift coverage assumed | Core FTE | First FTE | Citywide FTE |
|---|---|---:|---:|---:|
| Routine onboard post, unattended operation | GoA4 service has no scheduled onboard duty | 0 | 0 | 0 |
| Station duty and passenger assistance | One lead and two passenger/accessibility staff per station for 18 h/day | 138 | 734 | 3,209 |
| Station security and cleaning | One post of each kind per station for 18 h/day | 92 | 489 | 2,140 |
| Operations control centre (OCC) | Four continuously staffed desks per centre, all centres active | 21 | 41 | 82 |
| Depot technicians | Eight on each of two 8 h shifts and four on the night shift per depot | 34 | 136 | 408 |
| Civil, track and traction-power response | Four people on each 8 h shift per started 30 route-km | 21 | 102 | 428 |
| Planning, payroll, stores and trainers | Six day staff per depot | 6 | 24 | 72 |
| **Unattended GoA4, all listed duties** | | **312** | **1,526** | **6,339** |
| Supervised commissioning, full-year equivalent | Same station and shore-side cover plus one onboard commissioning supervisor per train-duty hour | 400 | 1,938 | 7,827 |
| Onboard passenger assistance | Same shore-side cover plus passenger attendants for a proposed 25% of train-duty hours | 334 | 1,629 | 6,711 |

Each FTE supplies 1,720 rosterable hours/year in this study, from 2,080 paid hours less 360 hours for leave, sickness, training and other absence. Three staggered station teams can cover the 18 hours; the bidder must roster breaks, opening, closing and handover. Control centres and field response run three eight-hour shifts. The OCC coordinates traffic and incidents. Station teams assist passengers and manage platform access. Mobile infrastructure teams attend track and electrical faults. Dedicated rescue staffing, mobilisation time, specialist overhaul, peak crowd coverage and emergency-service agreements remain open. A passenger attendant provides assistance without driving the train. A commissioning supervisor observes the train during trials under a separately approved competence and intervention plan. The commissioning comparison assumes a full year at the same service level for pricing. Price actual trial dates and avoid carrying temporary commissioning payroll into every operating year.

The core roster prices 385 passenger train-hours and 28.8 minimum turnback hours per day from 576 timed trips. The earlier peak-fleet method allowed 428 hours. The resulting 6.3072 million annual train-km match the core annual operating budget of $30.495m. The separate flat-peak control of 11.826 million annual train-km has a different daily service offer. [Core cost basis](https://github.com/modernecotech/OpenSourceRail/blob/main/docs/reference-v07/cost/README.md#operation-and-30-year-whole-life-cost) · [Core train workings](https://github.com/modernecotech/OpenSourceRail/blob/main/docs/reference-v07/integration/TIMETABLE.md) Baghdad's first network uses 1,938.4 train-hours/day directly from its connected train diagrams, including minimum terminal turns. The citywide study uses 3,975.4 hours on diagrammed groups plus 3,036 hours estimated from the held groups' combined peak set requirement and the hourly departure profile. Groups M01, M02, M04 and M09 await usable through paths. Both onboard scenarios still need crew diagrams covering sign-on, relief, long layovers, depot movements and time between assignments. Allocate actual attended runs before assuming the 25% option can cover the proposed shifts. The earlier peak-fleet proxy of 403 / 1,950 / 7,976 FTE remains available in the `roster` field for comparison. [Connected service diagrams](https://github.com/modernecotech/OpenSourceRail/blob/main/cities/Baghdad/service-diagrams.json)

### Citywide service with five access sections deferred

The alternative serves fourteen main routes and keeps all 280 station allowances, twelve depots, four control centres, 934 trainsets and built track upkeep. Its 91.968 million annual train-km and 6,951.1 daily train-hours come from the stop-by-stop diagrams. At the same energy per train-km and tariff, the operating allowance is **$777.932m per year**. This includes **$239.118m** in non-energy train operations, **$234.588m** in electricity for 1,954.897 GWh, **$280m** in stations and **$24.226m** in power maintenance.

The same roster rules give **6,339 FTE** for unattended service, **7,815** for annualised supervised operation and **6,708** for 25% onboard assistance. Select the deferred-access option to price payroll and transfer it to citywide finance. Construction, fleet purchase and renewals still use the full **$31.018bn** citywide capital programme and its associated schedules. Uniform energy per kilometre is a planning assumption. Shorter access coverage and the ring timetable require stop-specific demand and traction studies. [Citywide train diagrams](https://github.com/modernecotech/OpenSourceRail/blob/main/cities/Baghdad/SERVICE-DIAGRAMS.md#a-citywide-timetable-with-five-access-sections-deferred)

### Try the operating roster

The Baghdad planner opens with central local pay estimates. Select a different pay case, adjust headcount through rosterable hours, or enter an operator’s rates and itemised contract labour credits. The planner rounds each role up to a whole FTE. The core railway opens with operator-entered pay because its location is unspecified. [Offline workforce planner](https://github.com/modernecotech/OpenSourceRail/blob/main/docs/operator-review/delivery/index.html)

[![GoA4 roster, role pay and annual operating cost for Baghdad’s first network](workforce.png)](https://github.com/modernecotech/OpenSourceRail/blob/main/docs/operator-review/delivery/index.html)

### Baghdad operating pay in 2026 prices

Iraq’s Statistics and GIS Authority reported October 2026 Baghdad day rates of IQD 20,000 for guards, 25,000 for unskilled labour and administrators, 35,000 for semi-skilled workers, 75,000 for skilled trades and 80,000 for engineers. These are observed construction-sector rates. The planner uses them as a recruitment benchmark for permanent rail jobs. Use a collective agreement, tendered rates or a rail employer’s payroll survey when available. [Official October bulletin, Baghdad row in the wage table (Arabic)](https://www.cosit.gov.iq/documents/buildings/Employees%20wages/2026/%D8%A7%D8%B3%D8%B9%D8%A7%D8%B1%20%D8%A7%D9%84%D9%85%D9%88%D8%A7%D8%AF%20%D8%A7%D9%84%D8%A7%D9%86%D8%B4%D8%A7%D8%A6%D9%8A%D8%A9%20%D9%84%D8%B4%D9%87%D8%B1%20%D8%AA%D8%B4%D8%B1%D9%8A%D9%86%20%20%D8%A7%D9%84%D8%A7%D9%88%D9%84.pdf)

| Railway role | Assumed grade mix | Wage proxy, IQD per paid day |
|---|---|---:|
| Station and onboard passenger assistance | Semi-skilled | 35,000 |
| Security and cleaning | Equal guard and unskilled shares | 22,500 |
| Control room and onboard commissioning supervisors | Engineer | 80,000 |
| Depot technicians | Equal skilled and semi-skilled shares | 55,000 |
| Civil, track and power response | Three skilled workers to one semi-skilled | 65,000 |
| Planning, payroll, stores and trainers | Equal administrator and engineer shares | 52,500 |

Allow 260 paid eight-hour days a year including paid absence. A **5% / 15% / 35%** allowance on earnings tests rail recruitment and shift premiums. The employer pays a further **12%** on this gross pay under the assumed private-sector Iraqi employment arrangement. The employee’s 5% contribution comes out of gross salary. Different employment arrangements, international secondees, extra benefits and overtime require their own prices. Translate loaded annual IQD pay at the Central Bank’s 7 October 2026 bank-sale rate of **IQD 1,510 per US dollar**. For example, a station assistant in the central case earns IQD 10.465m per year before deductions and costs the employer IQD 11.721m (US$7,762). [ILO guide to business registration, social security chapter (Arabic)](https://www.ilo.org/sites/default/files/2025-10/%D8%AF%D9%84%D9%8A%D9%84%20%D8%AA%D8%B3%D8%AC%D9%8A%D9%84%20%D8%A7%D9%84%D9%85%D8%B4%D8%A7%D8%B1%D9%8A%D8%B9.pdf) · [Central Bank exchange-rate decision (Arabic)](https://cbi.iq/news/view/3355)

| Annual GoA4 outcome, US$m | First network | Citywide | Citywide with five access sections deferred |
|---|---:|---:|---:|
| Published operating allowance | 196.98 | 780.50 | 777.93 |
| Assumed payroll inside that allowance | 10.67 | 42.63 | 42.63 |
| Replacement payroll, low / central / high | 11.21 / 12.27 / 14.41 | 44.76 / 49.03 / 57.55 | 44.76 / 49.03 / 57.55 |
| Revised operating cost, low / central / high | 197.51 / 198.58 / 200.71 | 782.63 / 786.89 / 795.42 | 780.06 / 784.33 / 792.85 |

The first network’s **1,526 FTE** need **122,080 supervised learner-hours** for initial training. Its original US$196.978m annual budget includes US$64.133m for non-energy train operations, US$64m for stations, US$5.928m for power maintenance and US$62.918m for energy. To avoid paying twice for the same posts, estimate the embedded payroll by pricing the common GoA4 roster at the wage proxies plus employer contributions. Allocate station staff to stations, one third of civil/track/power response payroll to power maintenance and the balance of operational roles to train operations. This credits **US$7.076m, US$0.426m and US$3.170m** respectively. Leave other parts of those allowances in place. The assumed credit stays fixed when testing new pay, rosterable hours or attended duties.

Embedded payroll is a separate uncertainty. A 20% error either way in the labour already allowed changes central annual OPEX by **US$2.13m** for the first network or **US$8.53m** citywide. Use each contractor’s labour/non-labour breakdown to revise the three credits. The planner passes a fully priced passenger-service scenario to finance. It shows supervised commissioning as a full-year equivalent until the trial dates are known.

### Paid time for initial operator training

| One GoA4 intake, 2026 US$m | First network | Citywide |
|---|---:|---:|
| Learners and paid learner-hours | 1,526 people / 244,160 h | 6,339 people / 1,014,240 h |
| Classroom instructor-hours / field mentor-hours | 10,240 / 30,560 | 42,320 / 126,800 |
| Central learner pay / instructors / field mentors | 0.944 / 0.087 / 0.261 | 3.771 / 0.361 / 1.082 |
| Total labour, low / central / high | 1.180 / 1.292 / 1.517 | 4.760 / 5.214 / 6.121 |

Include these paid hours **within pre-opening commissioning**, with one initial intake of the proposed operating establishment. Price 80 classroom hours at up to twelve learners per instructor and 80 mentored hours at an assumed four learners per mentor, rounding up the number of groups. Each learner’s hours use their role’s loaded annual pay divided by 2,080 paid hours. Price instructors and mentors at the senior technical grade. The two citywide service offers use the same GoA4 establishment. A duty-specific supervision plan may require one-to-one assessment, especially for electrical isolation or vehicle recovery. Obtain a separate quote for facilities, simulators, bilingual course preparation, certification, specialist trainers and travel.

Match trainee and instructor hours to dates, employing contracts and cost centres. Credit the same hours already paid by the operating contract, supplier’s training package or phased mobilisation before valuing a new training offer. Recurrent training remains in operating rosters. This initial training estimate measures one portion of the existing commissioning scope.

### Hiring, training and release

| When | Appoint and train | Demonstration for release |
|---|---|---|
| Definition and financing, core M0–6 or Baghdad programme mobilisation | Operator leads for passenger access, operations, engineering, finance, HR, training and QA. Select vocational college and Iraqi supplier training partners. Agree language, wages, apprenticeships and assessors. | Approved establishment by location, bilingual role profiles, named training owner and a costed recruitment/accommodation plan. |
| Before tooling release, core M6–12 or before Baghdad's 2028 pilot | Recruit first instructors and a pilot crew in each trade. Budget 40 h of common induction plus 80 h supervised trade work as starter allocations. | Each learner demonstrates isolation and safe handback on a training asset. Welders complete witnessed process coupons; prestress crews identify each tendon/anchor and complete a mock pour, lift and rejection. Independent assessor records results. |
| Pilot and series production | Recruit line, stores, inspection and yard crews against module start dates. Pair apprentices with approved mentors. Train leads on repeat defects and repair. | Signed serial and material trace, calibration record, first-article inspections, timed door change, supported wheel drop and safe transport rehearsal. Release each role and equipment type individually. |
| Before passenger trials, core M29–40 or Baghdad's final construction year | Recruit station teams, train crews, controllers and depot/electrical staff early enough for shadow rosters. Budget 80 h classroom/simulator plus 80 h mentored duties as a starting block. | Station staff practise wheelchair boarding, lift failure and evacuation. Operators demonstrate route knowledge, stopping and disabled train recovery. Controllers manage a failed section and passenger communications. Electricians demonstrate isolation, proving dead and controlled restoration. |
| Trial and opening, core M40–43 or Baghdad 2031 / 2035 scenarios | Run a full relief roster, night maintenance, degraded service and two-shift handovers. Retain local instructors through first-year operation. | Assessor signs scope, restrictions and expiry; HR releases only covered duties. Log retraining after equipment change, a lapse, an incident or failed assessment. Operator determines recurrent intervals and rescue drill frequency. |

The 160-hour initial operating block implies 49,920 / 244,160 / 1,014,240 learner-hours if applied once to every listed GoA4 FTE. For classroom groups of 12, the classroom component alone needs at least 26 / 128 / 529 cohorts at 80 instructor-hours each. Mentoring, assessors, facilities, simulator slots and backfill are additional. New-hire training before opening needs mobilisation funding. During service the annual 360-hour absence allowance already includes recurrent training. Record actual delay and competence gaps before confirming the opening roster.

### Paying for delivery and tracking local employment

The core capital budget contains US$42m for vehicle/depot works, US$12m for tooling and US$8m for ordinary land and utilities. The core annual O&M allowance of US$30.495m includes US$4m for control/operations staff, US$10m for fleet maintenance and US$6m for civil/station/overhead maintenance. Agree which staffing duties each envelope buys. Baghdad carries US$260m / US$740m for depots and control, US$99.28m / US$282.261m for tooling and recovery, and US$196.978m / US$780.495m total annual O&M. Its annual non-energy train and station allowances jointly provide US$128.133m / US$520.412m for several services including labour. Site acquisition, production line replication, extra yards, shifts, satellite stock, training and local wage rates still need itemised quotations. [Core cost ledger](https://github.com/modernecotech/OpenSourceRail/blob/main/docs/reference-v07/cost/README.md) · [Baghdad scope and rate ledger](https://github.com/modernecotech/OpenSourceRail/blob/main/cities/Baghdad/system-results.json)

For each role price annual paid headcount × loaded local pay, plus separately priced overtime, relocation, mentoring, backfill and facilities. Allocate instructors and labour once to the vehicle price, civil supply/erection, commissioning allowance, or annual operating contract as applicable. Reconcile included allowances and replace them with equivalent priced scope. Keep grants and supplier-financed training visible against their funding contracts. In procurement, compare a vendor’s delivery, training, local repair rights, tooling ownership and sign-off authority against the open design on the same route and service. Report verified Iraqi wages and hours, apprentices entered/completed, instructors qualified, repair tasks transferred, spend paid to Iraqi suppliers and imported content embedded in that spend. Contract value, headcount and local value added measure different things.

**ERPNext and Frappe HR handover.** The project already maps shift patterns to draft Shift Type and Staffing Plan documents. Import only after the employing operator resolves employing company, sites, role permissions, cost centres, shift times and relief vacancies. Connect candidate revision, Item/BOM and Routing to Work Order, Job Cards and inspection/serial records. HR owns offer, employee, location, shift assignment and access-controlled training evidence. The technical assessor owns authorisation by asset type, task, restrictions and expiry. The duty planner checks the roster against those authorisations at allocation and again at handover. Link records using scoped IDs and publish only aggregated hiring/training metrics. A failed assessment blocks independent duty until supervised retraining and reassessment. The calculator generates a proposed establishment; it creates no employee, payroll transaction or operating authorisation. [Existing Frappe/ERPNext draft mapping](https://github.com/modernecotech/OpenSourceRail/blob/main/services/integration/osr_integration/city_outline.py) · [Operations roster checker](https://github.com/modernecotech/OpenSourceRail/blob/main/services/integration/osr_integration/operations/roster.py)

## Reproduce the quantities

Run `python3 docs/operator-review/delivery/calculate.py --check` from the repository root. [The calculated quantities](https://github.com/modernecotech/OpenSourceRail/blob/main/docs/operator-review/delivery/quantities.json) identify each source candidate and evaluation, exact source and calculator SHA-256, all intermediate staffing quantities and the study evaluation digest. To revise the allowances, edit the [calculator](https://github.com/modernecotech/OpenSourceRail/blob/main/docs/operator-review/delivery/calculate.py), regenerate with the same command without `--check`, then reconcile the tables and drawings with the resulting output. The two SVGs are editable, scaled planning drawings. Geotechnical surveys, measured loads and production trials, a contracted operating timetable and independently approved safety requirements remain prerequisites for release.


After changing quantities, run `node docs/operator-review/delivery/capture-workforce.mjs --refresh` to update the local workforce-data.js snapshot from quantities.json and capture the screenshot. Run without `--refresh` to verify the data and repeat the browser checks. Use the repository’s Playwright dependency and its Chromium, or set `OSR_BROWSER_EXECUTABLE` to an installed Chromium executable. The default capture opens local files offline. Add `--workbench-origin=http://127.0.0.1:8090` with the Workbench running to exercise its page and same-origin asset policy. Both paths check the complete local data wrapper against the source JSON, select all nine railway and staffing combinations, exercise role pay and hours, reject unknown or out-of-scope credits, and check the finance handover, annual pay and training subtotals.
