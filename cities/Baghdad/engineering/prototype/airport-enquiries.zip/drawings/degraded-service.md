# Airport service after a source and conductor-path outage

The proposed six-site paired circuit has 736 scheduled acceleration and yard pulses. A simultaneous site and positive/return path loss leaves one full longitudinal path. At the longest restored distance, the combined adverse case gives a 10.174 MW collector load limit and 7.536 kA at the 1.350 kV floor.

| Combined adverse duty | Collector MW | Collector kV | Voltage screen |
|---|---:|---:|---|
| two accelerating | 12.872 | 1.3088 | below floor |
| one accelerating | 9.001 | 1.3671 | above or at floor |
| no acceleration with cruise | 5.130 | 1.4203 | above or at floor |
| stopped auxiliaries only | 0.945 | 1.4735 | above or at floor |

All three active sets retain their auxiliary demand. The moving cases also include uphill cruise for each set outside acceleration. The stopped case assumes all traction has ceased. Station and emergency facility supplies require separate evidence.

| Isolated site (0–5) | Adjacent source | Source area km | Pulses within voltage limit | Pulses requiring overlap review | Pulses outside area |
|---:|---:|---|---:|---:|---:|
| 0 | 1 | 0.0–3.6 | 225 | 0 | 511 |
| 1 | 0 | 0.0–2.4 | 225 | 0 | 511 |
| 1 | 2 | 2.4–6.0 | 8 | 284 | 444 |
| 2 | 1 | 1.2–4.8 | 8 | 284 | 444 |
| 2 | 3 | 4.8–8.4 | 292 | 0 | 444 |
| 3 | 2 | 3.6–7.2 | 292 | 0 | 444 |
| 3 | 4 | 7.2–10.8 | 292 | 0 | 444 |
| 4 | 3 | 6.0–9.6 | 292 | 0 | 444 |
| 4 | 5 | 9.6–12.0 | 219 | 0 | 517 |
| 5 | 4 | 8.4–12.0 | 219 | 0 | 517 |

Each row is a separate outage hypothesis. Both tracks contribute to the same source bound. A footprint touching a feed boundary counts against either possible source. Rounded chainages use the same precision on both sides of that comparison. Every pulse that overlaps excess demand is flagged for review. The count identifies affected movements and does not assign dispatch priority or calculate a revised timetable. Delay and restart can introduce new coincidences.

Before restoration the failed site’s normally fed zone is unavailable. The JSON identifies its adjacent midpoints, the lost path span and the hypothesis for the adjacent source. A loss on either track needs its own equipment-tagged isolation plan. Retain the operating hold pending verified topology, utility voltage, live-source and surviving-path current ratings, protective discrimination, thermal duty, train positions and an approved revised timetable.

For a stranded train identify its occupied section, independent auxiliary duration and accessible detrainment route. Prove dead locally, including adjacent feeds, regeneration and shoe bridging, and obtain the responsible operator’s evacuation authority and accessible egress arrangements. A calculated auxiliary voltage cannot establish emergency power continuity or authorise evacuation.
