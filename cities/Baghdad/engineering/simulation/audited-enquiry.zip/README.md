# Airport budgetary enquiry

Please quote the 17.461 km working alignment, 6-car
steel formation and paired6 supply layout identified in manifest.json.
The operating screen for this configuration is **passed**. Consult
decision.json for failures by duty and the evidence needed before selecting equipment or releasing drawings.

| Enquiry | Quantity basis | Return requested |
| --- | --- | --- |
| Representative car | 36 cars in 6 sets. Vehicle file contains installed allocations, drawing basis, cut stock and loaded cases. | Fitted BOM, mass and centre of gravity, joining details, access envelopes, door deflection and aged battery performance. |
| Powered bogie | 72 bogies. Vehicle file gives static axle reactions, traction and degraded stopping demand. | Suspension stroke, mounting loads, removal clearance, brake response, thermal rating and failed-module performance. |
| Viaduct | 1746 standard beams, 874 standard support positions and 6984 bearings. See [the civil takeoff](engineering/civil.json) for span, section and end closures. | Price stock, prestress, foundations, bearing replacement, haulage and erection at working radius. Identify closure design, ground data and temporary works separately. |
| Station | 6 sites. See the [route](engineering/route.geojson), [service](engineering/service.json) and [station calculations](engineering/station.json) for locations, passenger exchanges and summer duty. | Site layout, accessible boarding, clearances, evacuation and platform equipment. Identify allowances for unconfirmed sites. |
| Power and controls | 6 supply sites. The [feeder study](engineering/feeder.json) lists chainages, failed cases, peak and RMS envelopes, including the separately identified one-driven-axle-out replay. | Rate continuous and transient loads, protection, return paths and safe isolation for feeder f481f643d1b8097b5d34fcdb78c27d9feebeb025ca54516e6f82fcfbe56b03b9. Use the rail-side rate sensitivity to compare scope. Quote utility terms, installation, validation and scheduled renewals separately. |
| Local production | The [production study](pricing/production.json) gives the planned quantities, equipment counts by resource and disruption schedules. The [routing basis](factory/routing-basis.json) identifies inherited process and fixture assumptions. | Return machine/crew hours, tool and fixture quantities, workcell capacity, yield, inspection holds, training, logistics and origin evidence. |

## Return an offer

1. Open pricing/production.json. In `pricings`, choose a lot and copy its `scope_id`, quantity, unit and year into your quotation. Identify exclusions, price basis, delivery, quote validity and renewal assumptions. Each price covers the complete lot in constant 2026 USD.
2. The buyer records each independent supplier in a copy of returns/buyer-offers.json under `offers`. Supply `offer_id`, `supplier`, `scope_id`, `price_usd`, `buyer_review_reference`, the quotation document's `offer_sha256` and `claimed_domestic_value_usd` (null when unknown). Retain the original documents and ERPNext Supplier Quotation references. Use `awards` for explicit awards with `offer_id`, `scope_id` and `buyer_award_reference`.
3. Run the original audit with its original service and engineering inputs plus `--offers buyer-offers.json --json`. Review the competing prices, revised cash flows and open items. Vehicle or feeder evidence uses the respective template and adjacent source documents with `--vehicle-return` or `--supply-return`.

The factory basis and released steel cut list describe the parent prototype. Confirm compatibility with this issue before pricing any change of material, girder, formation or tooling. Prices with unknown quantities, unpriced closures and unverified capabilities remain visible in the ledger. Use the source repository's prototype training workshop for supervised practice. Fabrication requires reviewed drawings, confirmed interfaces and inspection instructions.

The equipment rating and rail-side site-capacity price sensitivity include ordinary, high-mass outage and one-driven-axle-out current envelopes. Annual operating cash and service parity use the booked and achieved ordinary service comparison; the fault replay has no approved degraded timetable or annual frequency.
