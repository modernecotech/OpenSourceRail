"""Bounded, read-only-source component campaign; canonical native inputs logged."""
from pathlib import Path
from copy import deepcopy
import gzip,json,os,resource,subprocess,time
from engineering.design_search import propulsion_families as proposals,wheel_motor as motor,wheel_families as families
from engineering.station_rail import braking,operations,FLAGS
from engineering.station_rail.common import encoded,identity,digest,source_map
ROOT=Path('/home/hayder/Documents/OpenSourceRail');OUT=Path(__file__).resolve().parent
LIMIT=3*1024**3;resource.setrlimit(resource.RLIMIT_AS,(LIMIT,LIMIT));started=time.monotonic()
physical_flags=dict(**FLAGS,configuration_adopted=False)
comparison_path=ROOT/'docs/design-engine/v06-optimisation/comparison.json.gz'
summary_path=ROOT/'docs/design-engine/v06-optimisation/summary.json'
summary=json.loads(summary_path.read_bytes());comparison=json.loads(gzip.decompress(comparison_path.read_bytes()))
cid='168c9dc7fefa0af985e54e05427c4292d1176180596d408eb6b31fa378711331'
if summary['next_experiment']['selected_candidate_id']!=cid:raise ValueError('Pinned published research selection differs')
candidate=next(c for c in comparison['candidates'] if c['candidate_id']==cid)
# Record all physics/materialization dependencies, keeping publication and CLI
# changes outside this read-only numerical source guard.
frozen=json.loads((ROOT/'docs/design-engine/v06-optimisation/definition.json').read_bytes())['source_sha256']
names=[n for n in frozen if n.startswith(('engineering/station_rail/','engineering/ferrite_maglev/','engineering/maglev_research/')) or n in ('engineering/design_search/wheel_body.py','engineering/design_search/wheel_brakes.py','engineering/design_search/wheel_families.py','engineering/design_search/wheel_motor.py','engineering/design_search/contracts.py') or n.endswith(('comfort-design/design.json.gz','comfort-design/manifest.json'))]
sources=source_map(ROOT,[*names,proposals.PRODUCER]);tools=dict(getdp_sha256=digest(motor.GETDP),gmsh_version=__import__('gmsh').__version__,threads=1,address_space_limit_bytes=LIMIT)
car=families.materialize(candidate);rotor=braking.rotating_stock(car)
context=dict(accounted_mass_kg_per_car=car['mass']['accounted_cap_loaded_kg_per_car'],rotating_equivalent_mass_kg_per_car=rotor['equivalent_inertial_mass_kg_per_car'])
plan=proposals.expanded_plan(candidate,{'failure_reasons':['linear_steel_field_limit','insufficient_conditional_2D_force','unknown_whole_life_cost']},context=context)
selected=[r for r in plan['proposals'] if r['proposal']['label'] in ('deeper-return-and-teeth','longer-pole-pitch')]
if len(selected)!=2:raise ValueError('Exactly two named proposals required')
(OUT/'plan.json').write_bytes(encoded(plan));(OUT/'parent-candidate.json').write_bytes(encoded(candidate))
profile=operations.profile(2000,context['accounted_mass_kg_per_car'],rotating_equivalent_mass_kg_per_car=context['rotating_equivalent_mass_kg_per_car'])
required=profile['peak_launch_force_N_per_car']
inputs=dict(schema='osr-expanded-motor-native-input/1',parent_candidate_id=cid,requirement_revision=candidate['requirement_revision'],
    published_campaign_id=summary['campaign_id'],published_comparison_sha256=digest(comparison_path),published_summary_sha256=digest(summary_path),
    git_revision_at_start=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),plan_id=plan['plan_id'],
    accounted_vehicle_mass=car['mass'],rotor=rotor,required_launch_profile=profile,mass_context=context,
    source_sha256=sources,tool=tools,budget=dict(native_cases=4,total_runtime_s=480,RAM_bytes=LIMIT,threads=1),
    complete_vehicle_revision_materialized=False,component_scope='New wayside geometry only; onboard fin and accounted car mass unchanged',**physical_flags)
inputs['input_id']=identity(inputs);(OUT/'input.json').write_bytes(encoded(inputs))
rows=[]
for item in selected:
    option=item['proposal'];label=option['label'];parameters=proposals.wheel_motor_parameters(option)
    old=candidate['architecture']['wheel_parameters']['motor']
    for n in ('active_height_m','secondary_length_m','secondary_thickness_m','secondary_bottom_TOR_m','gap_each_side_m'):
        if parameters['physical'][n]!=old[n]:raise ValueError('Onboard fin/interface changed in supposed wayside-only comparison')
    if time.monotonic()-started>440:raise TimeoutError('Aggregate eight-minute execution budget exhausted before next proposal')
    assert abs(item['screen']['required_launch_force_N_lower_bound']-required)<1e-7
    folder=OUT/label
    print('START',label,'Ipeak',parameters['evaluation']['current_peak_A'],'required_N',required,flush=True)
    try:
        result=motor.evaluate(parameters,required,folder,root=ROOT)
        verification=motor.verify(folder,root=ROOT)
        (OUT/('verification-'+label+'.json')).write_bytes(encoded(verification))
        row=dict(label=label,proposal_id=option['proposal_id'],proposed_physical_design_id=option['physical_design_id'],
            parent_candidate_id=cid,requirement_revision=option['requirement_revision'],proposal=option,parameters=parameters,
            actual_vehicle_mass_context=context,component_native_evaluation_id=result['evaluation_id'],component_motor_id=result['motor_component_id'],
            native_cache_key=result['cache_key'],native_manifest_id=json.loads((folder/'manifest.json').read_bytes())['manifest_id'],
            native_raw_package_path=str(folder),verification=verification,execution=result['execution'],engineering_screen=result['engineering_screen'],
            failure_reasons=result['failure_reasons'],cases=[dict(case=r['case'],execution=r['execution'],numerical_validity=r['numerical_validity'],model_domain=r['model_domain'],metrics=r.get('metrics'),failure_reason=r.get('failure_reason')) for r in result['cases']],**physical_flags)
    except (ValueError,OSError) as error:
        row=dict(label=label,proposal=option,parent_candidate_id=cid,requirement_revision=option['requirement_revision'],
            execution='refused',refusal_type=type(error).__name__,reason=str(error),native_raw_package_path=str(folder),**physical_flags)
    rows.append(row);(OUT/'progress.json').write_bytes(encoded(dict(completed_proposals=rows,elapsed_s=time.monotonic()-started)))
    print('END',label,row['execution'],row.get('failure_reasons',row.get('reason')),flush=True)
if sources!=source_map(ROOT,[*names,proposals.PRODUCER]) or tools['getdp_sha256']!=digest(motor.GETDP):raise ValueError('Read-only physical method or tool changed during campaign')
result=dict(schema='osr-expanded-motor-native-followup/1',parent_candidate_id=cid,requirement_revision=candidate['requirement_revision'],
    input_id=inputs['input_id'],plan_id=plan['plan_id'],source_sha256=sources,tool=tools,required_force_N_per_car=required,
    mass_context=context,proposal_results=rows,native_case_count=sum(len(r.get('cases',[])) for r in rows),
    elapsed_s=time.monotonic()-started,execution='completed' if all(r['execution']=='completed' for r in rows) else 'incomplete',
    evidence_scope='Four unrefined centred finite-geometry2D samples. No current/force scaling, no nonlinear/3D thermal or installed-operation acceptance.',
    complete_installed_force_map=False,available_installed_force_N=None,**physical_flags)
result['aggregate_evaluation_id']=identity(result);(OUT/'result.json').write_bytes(encoded(result))
manifest=dict(schema='osr-expanded-motor-native-manifest/1',parent_candidate_id=cid,requirement_revision=candidate['requirement_revision'],source_sha256=sources,
    aggregate_evaluation_id=result['aggregate_evaluation_id'],files_sha256={p.relative_to(OUT).as_posix():digest(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name not in ('manifest.json','runner-stdout.log','runner-stderr.log')},
    nested_native_manifest_sha256={p.relative_to(OUT).as_posix():digest(p) for p in sorted(OUT.glob('*/manifest.json'))},**physical_flags)
manifest['manifest_id']=identity(manifest);(OUT/'manifest.json').write_bytes(encoded(manifest))
print(json.dumps(dict(aggregate_evaluation_id=result['aggregate_evaluation_id'],manifest_id=manifest['manifest_id'],native_cases=result['native_case_count'],elapsed_s=result['elapsed_s'])),flush=True)
