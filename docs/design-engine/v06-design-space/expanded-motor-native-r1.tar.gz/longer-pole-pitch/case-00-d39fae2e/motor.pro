// A-u formulation follows the official GetDP magnetodynamics template.
mu0=4.e-7*Pi;Freq=10.0;sigma=20000000.0;
Group { Air=Region[1];Plate=Region[2];Steel=Region[3];Coils=Region[{100,101,102,103,104,105}];PhaseA=Region[{100,103}];PhaseB=Region[{102,105}];PhaseC=Region[{101,104}];Domain=Region[{Air,Plate,Steel,Coils}];Outer=Region[901]; }
Function {nu[Region[{Air,Plate,Coils}]]=1/mu0;nu[Steel]=1/(mu0*1000.0);v[]=Vector[0.0,0,0];js[Region[100]]=Vector[0,0,Complex[2320642.32064232,-0]];
js[Region[101]]=Vector[0,0,Complex[1160321.16032116,-2009735.202773522]];
js[Region[102]]=Vector[0,0,Complex[-1160321.16032116,-2009735.202773522]];
js[Region[103]]=Vector[0,0,Complex[-2320642.32064232,-2.841967189940503e-10]];
js[Region[104]]=Vector[0,0,Complex[-1160321.160321161,2009735.202773522]];
js[Region[105]]=Vector[0,0,Complex[1160321.16032116,2009735.202773522]];}
Constraint {{Name Boundary;Case {{Region Outer;Value 0.;}}}}
Jacobian {{Name Vol;Case {{Region All;Jacobian Vol;}}}}
Integration {{Name Gauss;Case {{Type Gauss;Case {{GeoElement Triangle;NumberOfPoints 7;}}}}}}
FunctionSpace {
 {Name As;Type Form1P;BasisFunction {{Name sn;NameOfCoef an;Function BF_PerpendicularEdge;Support Domain;Entity NodesOf[All];}}Constraint {{NameOfCoef an;EntityType NodesOf;NameOfConstraint Boundary;}}}
 {Name Us;Type Form1P;BasisFunction {{Name sr;NameOfCoef ur;Function BF_RegionZ;Support Plate;Entity Region[Plate];}}}
}
Formulation {{Name Motor;Type FemEquation;Quantity {{Name a;Type Local;NameOfSpace As;}{Name u;Type Local;NameOfSpace Us;}}
 Equation {
 Integral {[nu[]*Dof{d a},{d a}];In Domain;Jacobian Vol;Integration Gauss;}
 Integral {DtDof [sigma*Dof{a},{a}];In Plate;Jacobian Vol;Integration Gauss;}
 Integral {[sigma*Dof{u},{a}];In Plate;Jacobian Vol;Integration Gauss;}
 Integral {[-sigma*(v[] /\ Dof{d a}),{a}];In Plate;Jacobian Vol;Integration Gauss;}
 Integral {[-js[],{a}];In Coils;Jacobian Vol;Integration Gauss;}
 Integral {DtDof [sigma*Dof{a},{u}];In Plate;Jacobian Vol;Integration Gauss;}
 Integral {[sigma*Dof{u},{u}];In Plate;Jacobian Vol;Integration Gauss;}
 Integral {[-sigma*(v[] /\ Dof{d a}),{u}];In Plate;Jacobian Vol;Integration Gauss;}
 }}}
Resolution {{Name Solve;System {{Name S;NameOfFormulation Motor;Type ComplexValue;Frequency Freq;}}Operation {Generate[S];Solve[S];SaveSolution[S];}}}
PostProcessing {{Name Result;NameOfFormulation Motor;Quantity {
 {Name Joule;Value {Integral {[.5*sigma*Re[CompZ[Dt[{a}]+{u}-(v[] /\ {d a})]*Conj[CompZ[Dt[{a}]+{u}-(v[] /\ {d a})]]]];In Plate;Jacobian Vol;Integration Gauss;}}}
 {Name ForceX;Value {Integral {[.5*sigma*Re[CompZ[Dt[{a}]+{u}-(v[] /\ {d a})]*Conj[CompY[{d a}]]]];In Plate;Jacobian Vol;Integration Gauss;}}}
 {Name ForceY;Value {Integral {[-.5*sigma*Re[CompZ[Dt[{a}]+{u}-(v[] /\ {d a})]*Conj[CompX[{d a}]]]];In Plate;Jacobian Vol;Integration Gauss;}}}
 {Name SourcePower;Value {Integral {[.5*CompZ[js[]]*Conj[CompZ[Dt[{a}]]]];In Coils;Jacobian Vol;Integration Gauss;}}}
{Name PhaseAPower;Value {Integral {[.5*CompZ[js[]]*Conj[CompZ[Dt[{a}]]]];In PhaseA;Jacobian Vol;Integration Gauss;}}}
{Name PhaseBPower;Value {Integral {[.5*CompZ[js[]]*Conj[CompZ[Dt[{a}]]]];In PhaseB;Jacobian Vol;Integration Gauss;}}}
{Name PhaseCPower;Value {Integral {[.5*CompZ[js[]]*Conj[CompZ[Dt[{a}]]]];In PhaseC;Jacobian Vol;Integration Gauss;}}}
 {Name NetJ;Value {Integral {[-sigma*CompZ[Dt[{a}]+{u}-(v[] /\ {d a})]];In Plate;Jacobian Vol;Integration Gauss;}}}
 {Name Bamp;Value {Term {[Sqrt[Re[CompX[{d a}]*Conj[CompX[{d a}]]+CompY[{d a}]*Conj[CompY[{d a}]]]]];In Steel;Jacobian Vol;}}}
 }}}
PostOperation {{Name Result;NameOfPostProcessing Result;Operation {
 Print[Joule[Plate],OnGlobal,File "joule.txt",Format Table];
 Print[ForceX[Plate],OnGlobal,File "force.txt",Format Table];
 Print[ForceY[Plate],OnGlobal,File "normal.txt",Format Table];
 Print[SourcePower[Coils],OnGlobal,File "power.txt",Format Table];
 Print[PhaseAPower[PhaseA],OnGlobal,File "phaseA.txt",Format Table];
 Print[PhaseBPower[PhaseB],OnGlobal,File "phaseB.txt",Format Table];
 Print[PhaseCPower[PhaseC],OnGlobal,File "phaseC.txt",Format Table];
 Print[NetJ[Plate],OnGlobal,File "netcurrent.txt",Format Table];
 Print[Bamp,OnElementsOf Steel,File "steelB.pos",Depth 0];
 }}}
