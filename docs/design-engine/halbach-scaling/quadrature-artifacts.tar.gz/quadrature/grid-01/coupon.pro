// Explicit continuation formulation; unchanged physical coupon; no material validation.
mu0=4.e-7*Pi;
Group{Air=Region[300];Steel=Region[200];PM=Region[{100,101,102,103,104,105,106,107}];Domain=Region[{Air,Steel,PM}];Outer=Region[400];}
Function{
 j[] = InterpolationLinear[Min[Norm[$1],100000.]]{0,0,20,0.050000000000000003,30,0.089999999999999997,40,0.17000000000000001,50,0.29999999999999999,60,0.45000000000000001,80,0.69999999999999996,100,0.88,150,1.1499999999999999,200,1.28,300,1.3899999999999999,500,1.47,1000,1.54,2500,1.6200000000000001,5000,1.71,10000,1.8200000000000001,15000,1.8999999999999999,30000,1.98,100000,2.04};
 dj[] = Norm[$1]>100000. ? 0. : dInterpolationLinear[Norm[$1]]{0,0,20,0.050000000000000003,30,0.089999999999999997,40,0.17000000000000001,50,0.29999999999999999,60,0.45000000000000001,80,0.69999999999999996,100,0.88,150,1.1499999999999999,200,1.28,300,1.3899999999999999,500,1.47,1000,1.54,2500,1.6200000000000001,5000,1.71,10000,1.8200000000000001,15000,1.8999999999999999,30000,1.98,100000,2.04};
 mu[Air]=mu0;mu[PM]=1.05*mu0;
 mu[Steel]=Norm[$1]<1.e-6 ? mu0+0.0025 : mu0+j[$1]/Norm[$1];
 dbdh[Steel]=Norm[$1]<1.e-6 ? (mu0+0.0025)*TensorDiag[1,1,1] : mu[$1]*TensorDiag[1,1,1]+(dj[$1]-j[$1]/Norm[$1])/SquNorm[$1]*SquDyadicProduct[$1];
 br[Air]=Vector[0,0,0];br[Steel]=Vector[0,0,0];
 br[Region[100]]=$load*Vector[0,0.41550236352472003,-1.0031114412194548];
 dir[Region[100]]=Vector[0,0.38268343236508989,-0.92387953251128674];
br[Region[101]]=$load*Vector[0,1.0031114412194548,-0.41550236352471981];
 dir[Region[101]]=Vector[0,0.92387953251128674,-0.38268343236508973];
br[Region[102]]=$load*Vector[0,1.0031114412194548,0.41550236352471998];
 dir[Region[102]]=Vector[0,0.92387953251128674,0.38268343236508984];
br[Region[103]]=$load*Vector[0,0.41550236352471986,1.0031114412194548];
 dir[Region[103]]=Vector[0,0.38268343236508978,0.92387953251128674];
br[Region[104]]=$load*Vector[0,-0.41550236352471986,1.0031114412194548];
 dir[Region[104]]=Vector[0,-0.38268343236508978,0.92387953251128674];
br[Region[105]]=$load*Vector[0,-1.0031114412194546,0.41550236352472036];
 dir[Region[105]]=Vector[0,-0.92387953251128663,0.38268343236509023];
br[Region[106]]=$load*Vector[0,-1.0031114412194546,-0.4155023635247202];
 dir[Region[106]]=Vector[0,-0.92387953251128663,-0.38268343236509011];
br[Region[107]]=$load*Vector[0,-0.41550236352472042,-1.0031114412194546];
 dir[Region[107]]=Vector[0,-0.38268343236509028,-0.92387953251128663];
}
Constraint{{Name Zero;Case{{Region Outer;Value 0.;}}}}
Jacobian{{Name V;Case{{Region All;Jacobian Vol;}}}}
Integration{{Name I;Case{{Type Gauss;Case{{GeoElement Tetrahedron;NumberOfPoints 4;}}}}}}
FunctionSpace{{Name Potential;Type Form0;BasisFunction{{Name sn;NameOfCoef pn;Function BF_Node;Support Domain;Entity NodesOf[All];}}Constraint{{NameOfCoef pn;EntityType NodesOf;NameOfConstraint Zero;}}}}
Formulation{{Name Magnet3D;Type FemEquation;Quantity{{Name p;Type Local;NameOfSpace Potential;}}
Equation{
 Integral{[-mu[]*Dof{d p},{d p}];In Region[{Air,PM}];Jacobian V;Integration I;}
 Integral{[br[],{d p}];In PM;Jacobian V;Integration I;}
 Integral{[-mu[-{d p}]*{d p},{d p}];In Steel;Jacobian V;Integration I;}
 Integral{[-dbdh[-{d p}]*Dof{d p},{d p}];In Steel;Jacobian V;Integration I;}
 Integral{[dbdh[-{d p}]*{d p},{d p}];In Steel;Jacobian V;Integration I;}
}}}
Resolution{{Name Solve;System{{Name S;NameOfFormulation Magnet3D;}}Operation{
 InitSolution[S];Evaluate[$load=0.,$stage=0,$ok=1];
 While[$stage<10 && $ok]{
 Evaluate[$stage=$stage+1,$load=$stage/10.];
 Generate[S];GetResidual[S,$initial];Evaluate[$res=$initial,$iter=0];
 Print[{$load,$initial},Format "LOAD %.3f INITIAL %.15e"];
 While[$res>1.0000000000000001e-09 && $res/Max[$initial,1.e-30]>9.9999999999999995e-08 && $iter<30]{
 Solve[S];Generate[S];GetResidual[S,$res];Evaluate[$iter=$iter+1];
 Print[{$load,$iter,$res,$res/Max[$initial,1.e-30]},Format "CONTINUATION %.3f %g %.15e %.15e"];
 }
 Print[{$load,$iter,$res,$res/Max[$initial,1.e-30]},Format "STAGE-END %.3f %g %.15e %.15e"];
 Evaluate[$ok=($res<=1.0000000000000001e-09 || $res/Max[$initial,1.e-30]<=9.9999999999999995e-08)];
 }
 SaveSolution[S];
}}}
PostProcessing{{Name Results;NameOfFormulation Magnet3D;Quantity{
 {Name B;Value{Term{[-mu[-{d p}]*{d p}+br[]];In Domain;Jacobian V;}}}
 {Name Hparallel;Value{Term{[-{d p}*dir[]];In PM;Jacobian V;}}}
 {Name SteelB;Value{Term{[Norm[mu[-{d p}]*{d p}]];In Steel;Jacobian V;}}}
}}}
PostOperation{{Name Results;NameOfPostProcessing Results;Operation{
 Print[B,OnPlane{{-0.52779999999999994,-0.18780000000000002,-0.04095} {-0.52779999999999994,0.18780000000000002,-0.04095} {-0.52779999999999994,-0.18780000000000002,-0.0078000000000000005}}{48,24},File "face-0-0-0.txt",Format SimpleTable]; Print[B,OnPlane{{0.52779999999999994,-0.18780000000000002,-0.04095} {0.52779999999999994,0.18780000000000002,-0.04095} {0.52779999999999994,-0.18780000000000002,-0.0078000000000000005}}{48,24},File "face-0-0-1.txt",Format SimpleTable]; Print[B,OnPlane{{-0.52779999999999994,-0.18780000000000002,-0.04095} {0.52779999999999994,-0.18780000000000002,-0.04095} {-0.52779999999999994,-0.18780000000000002,-0.0078000000000000005}}{128,24},File "face-0-1-0.txt",Format SimpleTable]; Print[B,OnPlane{{-0.52779999999999994,0.18780000000000002,-0.04095} {0.52779999999999994,0.18780000000000002,-0.04095} {-0.52779999999999994,0.18780000000000002,-0.0078000000000000005}}{128,24},File "face-0-1-1.txt",Format SimpleTable]; Print[B,OnPlane{{-0.52779999999999994,-0.18780000000000002,-0.04095} {0.52779999999999994,-0.18780000000000002,-0.04095} {-0.52779999999999994,0.18780000000000002,-0.04095}}{128,48},File "face-0-2-0.txt",Format SimpleTable]; Print[B,OnPlane{{-0.52779999999999994,-0.18780000000000002,-0.0078000000000000005} {0.52779999999999994,-0.18780000000000002,-0.0078000000000000005} {-0.52779999999999994,0.18780000000000002,-0.0078000000000000005}}{128,48},File "face-0-2-1.txt",Format SimpleTable]; Print[B,OnPlane{{-0.5302,-0.19020000000000001,-0.04335} {-0.5302,0.19020000000000001,-0.04335} {-0.5302,-0.19020000000000001,-0.0054000000000000003}}{48,24},File "face-1-0-0.txt",Format SimpleTable]; Print[B,OnPlane{{0.5302,-0.19020000000000001,-0.04335} {0.5302,0.19020000000000001,-0.04335} {0.5302,-0.19020000000000001,-0.0054000000000000003}}{48,24},File "face-1-0-1.txt",Format SimpleTable]; Print[B,OnPlane{{-0.5302,-0.19020000000000001,-0.04335} {0.5302,-0.19020000000000001,-0.04335} {-0.5302,-0.19020000000000001,-0.0054000000000000003}}{128,24},File "face-1-1-0.txt",Format SimpleTable]; Print[B,OnPlane{{-0.5302,0.19020000000000001,-0.04335} {0.5302,0.19020000000000001,-0.04335} {-0.5302,0.19020000000000001,-0.0054000000000000003}}{128,24},File "face-1-1-1.txt",Format SimpleTable]; Print[B,OnPlane{{-0.5302,-0.19020000000000001,-0.04335} {0.5302,-0.19020000000000001,-0.04335} {-0.5302,0.19020000000000001,-0.04335}}{128,48},File "face-1-2-0.txt",Format SimpleTable]; Print[B,OnPlane{{-0.5302,-0.19020000000000001,-0.0054000000000000003} {0.5302,-0.19020000000000001,-0.0054000000000000003} {-0.5302,0.19020000000000001,-0.0054000000000000003}}{128,48},File "face-1-2-1.txt",Format SimpleTable];
 Print[Hparallel,OnElementsOf PM,Depth 0,File "PM-H.txt",Format SimpleTable];
 Print[SteelB,OnElementsOf Steel,Depth 0,File "steel-B.txt",Format SimpleTable];
}}}
