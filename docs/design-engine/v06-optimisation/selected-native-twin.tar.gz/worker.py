
import FreeCAD as A,Part,Import,json,pathlib
out=pathlib.Path(__file__).parent;data=json.loads((out/'native-input.json').read_text());doc=A.newDocument('OSR_wheel_research');objects=[];rows=[]
for i,p in enumerate(data['parts']):
    at=A.Vector(*[x*1000 for x in p['at_m']])
    if p['kind'] in ('box','box-with-rectangular-cutouts'):
        shape=Part.makeBox(*[x*1000 for x in p['size_m']],at)
        for hole in p.get('holes',[]):
            index='xyz'.index(hole.get('axis','z'));start=list(p['at_m']);direction=[0.,0.,0.];direction[index]=1.
            for j,key in enumerate(('x_m','y_m','z_m')):
                if j!=index:start[j]+=hole.get(key,0.)
            shape=shape.cut(Part.makeCylinder(hole['diameter_m']*500,hole.get('length_m',p['size_m'][index])*1000,A.Vector(*[x*1000 for x in start]),A.Vector(*direction)))
        for cut in p.get('rectangular_cutouts',[]):
            shape=shape.cut(Part.makeBox(*[x*1000 for x in cut['size_m']],A.Vector(*[x*1000 for x in cut['at_m']])))
    elif p['kind'] in ('cylinder','annular-cylinder'):
        axis=A.Vector(*p['axis']);shape=Part.makeCylinder(p['radius_m']*1000,p['length_m']*1000,at,axis)
        if p.get('inner_radius_m',0):shape=shape.cut(Part.makeCylinder(p['inner_radius_m']*1000,p['length_m']*1000,at,axis))
    else:raise ValueError('Unsupported stock primitive')
    volume=shape.Volume/1e9
    if not shape.isValid() or abs(volume-p['volume_m3'])>max(1e-10,1e-6*p['volume_m3']):raise ValueError('Native stock volume differs: '+p['id'])
    obj=doc.addObject('PartDesign::Feature','Occurrence_'+str(i));obj.Label=p['id'];obj.Shape=shape
    for key,value in [('CandidateID',data['candidate_id']),('OccurrenceID',p['id']),('Frame',p['twin_frame'])]:
        obj.addProperty('App::PropertyString',key);setattr(obj,key,value)
    objects.append(obj);vertices,triangles=shape.tessellate(.15)
    rows.append(dict(id=p['id'],vertices_m=[[v.x/1000,v.y/1000,v.z/1000] for v in vertices],triangles=[list(t) for t in triangles],native_volume_m3=volume))
doc.recompute();doc.saveAs(str(out/'wheel-stock.FCStd'));Import.export(objects,str(out/'wheel-stock.step'));A.closeDocument(doc.Name)
doc=A.openDocument(str(out/'wheel-stock.FCStd'));reopened=sum(o.Shape.Volume for o in doc.Objects if hasattr(o,'Shape'))/1e9
if len([o for o in doc.Objects if hasattr(o,'Shape')])!=len(rows):raise ValueError('Reopened occurrence count differs')
A.closeDocument(doc.Name);step=Part.Shape();step.read(str(out/'wheel-stock.step'));total=sum(r['native_volume_m3'] for r in rows)
if max(abs(reopened-total),abs(step.Volume/1e9-total))>max(1e-8,1e-7*total):raise ValueError('Reopened CAD/STEP volume differs')
(out/'native-result.json').write_text(json.dumps(dict(candidate_id=data['candidate_id'],part_count=len(rows),rows=rows,native_volume_m3=total,reopened_volume_m3=reopened,step_volume_m3=step.Volume/1e9,FreeCAD_version=list(A.Version())),sort_keys=True)+'\n')
