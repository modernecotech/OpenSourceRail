
mu0=4.e-7*Pi;
Group{Core=Region[1];Gap=Region[2];Domain=Region[{1,2}];Left=Region[101];Right=Region[102];}
Function{mu[Gap]=mu0;jac[Gap]=TensorDiag[1,1,1]*mu0;co[Gap]=.5*mu0*SquNorm[$1];mu[Core]=mu0*1000; jac[Core]=TensorDiag[1,1,1]*mu0*1000; co[Core]=.5*mu0*1000*SquNorm[$1];}
Constraint{{Name Fix;Case{{Region Left;Value 100.0;}{Region Right;Value 0.;}}}}
Jacobian{{Name Vol;Case{{Region All;Jacobian Vol;}}}}
Integration{{Name Gauss;Case{{Type Gauss;Case{{GeoElement Triangle;NumberOfPoints 7;}}}}}}
FunctionSpace{{Name Phi;Type Form0;BasisFunction{{Name sn;NameOfCoef pn;Function BF_Node;Support Domain;Entity NodesOf[All];}}Constraint{{NameOfCoef pn;EntityType NodesOf;NameOfConstraint Fix;}}}}
Formulation{{Name Mag;Type FemEquation;Quantity{{Name p;Type Local;NameOfSpace Phi;}}
 Equation{
 Integral{[-mu[-{d p}]*{d p},{d p}];In Domain;Jacobian Vol;Integration Gauss;}
 Integral{[-jac[-{d p}]*Dof{d p},{d p}];In Domain;Jacobian Vol;Integration Gauss;}
 Integral{[jac[-{d p}]*{d p},{d p}];In Domain;Jacobian Vol;Integration Gauss;}
 }}}
Resolution{{Name Solve;System{{Name S;NameOfFormulation Mag;}}Operation{
 Evaluate[$initial=1];InitSolution[S];Generate[S];Solve[S];PostOperation[Guard];Print[{#10},Format "HGuard %.16g"];Test[#10>764030.0]{Error["Material table domain exceeded before nonlinear evaluation"];}
 Evaluate[$initial=0];Generate[S];GetResidual[S,$r0];Evaluate[$r=$r0,$i=0];
 While[$r>1.e-10 && $r/Max[$r0,1.e-30]>1.e-8 && $i<40]{Solve[S];PostOperation[Guard];Print[{#10},Format "HGuard %.16g"];Test[#10>764030.0]{Error["Material table domain exceeded before nonlinear evaluation"];}Generate[S];GetResidual[S,$r];Evaluate[$i=$i+1];Print[{$i,$r,$r/Max[$r0,1.e-30]},Format "NL %g %.16g %.16g"];}
 Test[$r>1.e-8 && $r/Max[$r0,1.e-30]>1.e-7]{Error["Nonlinear residual did not converge"];}
 SaveSolution[S];
 }}}
PostProcessing{{Name Results;NameOfFormulation Mag;Quantity{
 {Name H;Value{Term{[Norm[{d p}]];In Core;Jacobian Vol;}}}
 {Name Flux;Value{Integral{[Norm[-mu[-{d p}]*{d p}]];In Gap;Jacobian Vol;Integration Gauss;}}}
 {Name Coenergy;Value{Integral{[co[-{d p}]];In Domain;Jacobian Vol;Integration Gauss;}}}
 {Name HB;Value{Integral{[mu[-{d p}]*SquNorm[{d p}]];In Domain;Jacobian Vol;Integration Gauss;}}}
 }}}
PostOperation{
 {Name Guard;NameOfPostProcessing Results;Operation{Print[H,OnElementsOf Core,StoreMaxInRegister 10,File "Hguard.pos"];}}
 {Name Result;NameOfPostProcessing Results;Operation{
 Print[Flux[Gap],OnGlobal,File "flux.txt",Format Table];Print[Coenergy[Domain],OnGlobal,File "coenergy.txt",Format Table];Print[HB[Domain],OnGlobal,File "HB.txt",Format Table];Print[H,OnElementsOf Core,File "H.pos"];
 }}
}
