from pathlib import Path
import json
from engineering.design_search import nonlinear_motor as n,lim_materials as m
from engineering.station_rail.common import encoded,identity,digest
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;rows=[]
for name,c in [('gap-minus',n.benchmark_case(gap_m=.00099)),('gap-plus',n.benchmark_case(gap_m=.00101)),('linear-limit',n.benchmark_case(NI_Aturn=100.,linear=True))]:
 print('START',name,flush=True);r=n.run_benchmark(c,OUT/name,root=ROOT);print('END',name,r['execution'],r['numerical_validity'],flush=True);rows.append(dict(name=name,result=r,verification=n.verify(OUT/name,root=ROOT)))
for position in ('entry','centred','exit'):
 print('START',position,flush=True);r=n.run_overlap(n.overlap_case(position),OUT/position,root=ROOT);print('END',position,r['execution'],r['numerical_validity'],flush=True);rows.append(dict(name=position,result=r,verification=n.verify(OUT/position,root=ROOT)))
for name,mode in [('refused-table-domain','material'),('refused-moving-nonlinear','moving')]:
 r=n.run_benchmark(n.benchmark_case(NI_Aturn=1e9),OUT/name,root=ROOT) if mode=='material' else n.run_overlap(n.overlap_case(),OUT/name,root=ROOT,nonlinear=True)
 print(name,r['execution'],r.get('reason'),flush=True);rows.append(dict(name=name,result=r,verification=n.verify(OUT/name,root=ROOT)))
center_path=OUT.parent/'nonlinear-pilot/v2';centre=json.loads((center_path/'result.json').read_bytes())
center_verification=n.verify(center_path,root=ROOT,source_revision='df31f306b2')
gradient=n.energy_gradient(rows[0]['result'],centre,rows[1]['result'])
summary=dict(schema='osr-nonlinear-material-and-overlap-benchmarks/1',cases=rows,prior_center=dict(path=str(center_path),source_revision='df31f306b2',result=centre,verification=center_verification),
 native_attempt_count_this_package=6,prior_native_attempt_count=2,total_native_attempt_count=8,
 energy_gradient=gradient,source_equivalence_note='Central nonlinear fixture is pinned to df31. New versions add guard logging and metadata/verifiers; nonlinear weak equations and table/interpolation are unchanged. Distinct source identities are retained.',
 gates=dict(generic_nonlinear_method='benchmarked',selected_supplier_steel='held',nonlinear_moving_LIM='held',full3D_coreloss_thermal='held'),supplier_readiness=m.supplier_readiness(),
 physical_accepted=False,engineering_accepted=False,configuration_adopted=False)
summary['evaluation_id']=identity(summary);(OUT/'summary.json').write_bytes(encoded(summary))
manifest=dict(files_sha256={p.relative_to(OUT).as_posix():digest(p) for p in OUT.rglob('*') if p.is_file()},physical_accepted=False);manifest['manifest_id']=identity(manifest);(OUT/'manifest.json').write_bytes(encoded(manifest))
print('SUMMARY',summary['evaluation_id'],gradient,flush=True)
