import sys
sys.path[:0]=['/home/hayder/Documents/OpenSourceRail/build/comfort-design-round/worktrees/vehicle', '/home/hayder/Documents/OpenSourceRail']
from engineering.comfort_design.native_vehicle import _worker
_worker('/home/hayder/Documents/OpenSourceRail/build/comfort-design-round/vehicle-native-v3')
