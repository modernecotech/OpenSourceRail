"""Exact counted actuator alternative linked to corridor cost, duty and finance.

The frozen GFRP/50turn planning case remains separate. A local numerical pass
never supplies its mass or price to a different product configuration.
"""
from copy import deepcopy
from functools import lru_cache
from hashlib import sha256
from pathlib import Path
import argparse
import gzip
import io
import json
import math
import tomllib

from . import body_stiffness, corridor, drive_design, launch_optimisation as launch, model, pilot_actuators as actuators, pilot_corridor as pilot, pilot_product as product, pilot_limits

ROOT=model.ROOT
INPUT=Path(__file__).with_name('pilot-variants.toml')
TEST=ROOT/'engineering/analysis/tests/test_ferrite_maglev_pilot_variants.py'
OUTPUT=ROOT/'docs/design-engine/ferrite-maglev/pilot-variants'
SCHEMA='osr-pilot-variant-finance/1'
FLAGS={**model.FLAGS,'automatic_adoption':False,'engineering_accepted':False,'financial_close':False}
FILES={'study.json.gz','part-volume-audit.json.gz','overview.svg','README.md'}
MAX_RAW=32*1024*1024

def encoded(v):return product.encoded(v)
def digest(p):return sha256(Path(p).read_bytes()).hexdigest()
def source_paths():
    return sorted({Path(__file__),INPUT,TEST,Path(pilot_limits.__file__),*pilot.source_paths(),*actuators.source_paths(),
        *(p/name for p in (pilot.OUTPUT,actuators.OUTPUT) for name in ('manifest.json','study.json.gz'))})
def sources():return {p.relative_to(ROOT).as_posix():digest(p) for p in source_paths()}
def load():
    a=tomllib.loads(INPUT.read_text())
    selected=actuators.load()
    if a['schema']!='osr-pilot-variant-input/1' or a['body_variant']!=selected['preferred_body_variant'] or a['winding_variant']!=selected['preferred_winding_variant']:raise ValueError('exact declared counted candidate required')
    if a['automatic_adoption'] is not False or a['source_hotel_allowance_removal_credit_kw']!=0 or a['removed_gfrp_cost_credit_usd']!=0:raise ValueError('no unidentified allocation/removal credit allowed')
    if any(type(a[k]) not in (int,float) or not math.isfinite(a[k]) or a[k]<=0 for k in ('fabricated_steel_usd_per_kg','fabricated_spacer_usd_per_kg','fabricated_mount_usd_per_kg','cooling_auxiliary_w_per_module')):raise ValueError('finite positive component planning rates required')
    return a

def component_changes(cfg,drive,a=None):
    """Independent material/mass changes, with no invented aggregate credit."""
    a=load() if a is None else a;base=product.configuration_profile();rows=body_stiffness.derivation()['variants'];stock=next(r['stock'] for r in rows if r['name']==a['body_variant']);control=next(r['stock'] for r in rows if r['name']=='gfrp-control')
    coil=drive_design.support(drive);old=drive_design.support();m=cfg['magnetic'];rate=product.load()['support_copper_usd_per_kg'];items=[]
    def add(uid,mass,priced_quantity,unit_rate,scope):items.append(dict(id=uid,mass_change_kg_per_car=mass,priced_quantity_per_car=priced_quantity,unit='kg',unit_rate_usd=unit_rate,additional_cost_usd_per_car=priced_quantity*unit_rate,scope=scope,quote=False))
    add('replacement-steel-tubes',stock['tube_mass_kg']-control['tube_mass_kg'],stock['tube_mass_kg'],a['fabricated_steel_usd_per_kg'],'Exact drilled replacement stock; base body allowance remains, removed GFRP price is unidentified and receives no cost credit')
    add('changed-crush-spacers',stock['spacer_mass_kg']-control['spacer_mass_kg'],max(0.,stock['spacer_mass_kg']-control['spacer_mass_kg']),a['fabricated_spacer_usd_per_kg'],'Actual spacer lengths/material differences; no negative cost credit')
    add('additional-winding-copper',coil['copper_kg_per_car']-old['copper_kg_per_car'],max(0.,coil['copper_kg_per_car']-old['copper_kg_per_car']),rate,'All72physical support/guidance coils per car; copper increment replaces original winding mass once')
    add('additional-mount-stock',m['additional_mount_allowance_kg'],m['additional_mount_allowance_kg'],a['fabricated_mount_usd_per_kg'],'Counted module-mount allocation; detailed joints unqualified')
    hardware=cfg['bay_service_variant']['changed_hardware'];splice_mass=hardware['additional_stock_mass_kg_per_car']
    add('detachable-collector-splices',splice_mass,splice_mass,a['fabricated_mount_usd_per_kg'],'Exact added collector splice plates/bolts for24bays; no removed-stock mass or cost credit')
    items[-1]['hardware_counts_per_car']={k:24*hardware[k] for k in ('new_splice_plates','new_m8_bolts','reused_main_interface_m12_bolts')}
    cooling=m['additional_unquoted_copper_and_cooling_usd']-max(0.,m['incremental_winding_copper_kg'])*rate
    if cooling<0:raise ValueError('negative cooling allocation')
    items.append(dict(id='additional-cooling',mass_change_kg_per_car=m['additional_cooling_allowance_kg'],priced_quantity_per_car=24,unit='module',unit_rate_usd=cooling/24,additional_cost_usd_per_car=cooling,scope='Counted cooling/module allocation includes auxiliaries; no second pump cost added',quote=False))
    delta=sum(r['mass_change_kg_per_car'] for r in items)
    if not math.isclose(delta,cfg['controlled_aw3_kg']-base['controlled_aw3_kg'],abs_tol=1e-8):raise ValueError('candidate component mass changes do not reconcile')
    support_kw=72*cfg['magnetic']['support_winding']['continuous_current_a']**2*coil['coil']['resistance_hot_ohm']/1000
    auxiliary_kw=24*a['cooling_auxiliary_w_per_module']/1000
    return dict(rows=items,incremental_mass_kg_per_car=delta,additional_component_cost_usd_per_car=sum(r['additional_cost_usd_per_car'] for r in items),
        energy=dict(support_continuous_copper_ceiling_kw_per_car=support_kw,cooling_auxiliary_kw_per_car=auxiliary_kw,additional_services_kw_per_car=support_kw+auxiliary_kw,
            source_hotel_kw_per_car=pilot.load()['services_kw_per_car'],source_hotel_removed_kw=0.,all_physical_coils=72,base_hotel_support_split_known=False,
            scope='Conservative full60A continuous I²R ceiling across72coils plus counted cooling auxiliaries, added to retained60kW hotel allowance. Potential overlap with opaque hotel allowance is not credited. This is not measured consumption or the mixed support/wayside Rust heat; no LSM heat is added twice.'),
        removed_gfrp_cost_credit_usd=0.,mass_and_cost_are_distinct_ledgers=True,additional_non_vehicle_tooling_usd=hardware['tooling']['fixture_allowance_usd'],tooling=hardware['tooling'])

def selected_launch(profile,cfg,drive):
    # Cost the actual controller's group geometry and conductor/voltage choice.
    # A lower-cost separate launch search cannot supply this candidate's price.
    parameters=cfg['wayside_drive'];row=launch.loss_model(profile,**parameters,configuration_id=cfg['id'],_context=(launch.load(),drive,cfg));passing=row['feasible'] and row['controlled_mass_matches']
    return dict(candidate_count=1,feasible_count=int(passing),declared_executed_choice=parameters,selected=row if passing else None,
        rejection_screens=[] if passing else [dict(candidate=row['candidate'],limits=row['limits'])],independent_optimum_substituted=False,automatic_adoption=False)

def candidate_line(cfg,drive):
    line=deepcopy(pilot.city_line());profile=actuators.motion_profile(cfg);choice=selected_launch(profile,cfg,drive)
    if choice['selected'] is None:return None,choice
    loss=choice['selected'];old_mass=line['formation']['aw3_mass_kg']/6
    for event in line['duty']['arrival_events_per_circuit']:
        if event['terminal_loop_allowance']:
            event['station_traction_input_kwh']*=cfg['controlled_aw3_kg']/old_mass;event['energy_basis']='Mass-scaled retained short-loop allowance; exact curved-loop/short-zone electrical model held'
        else:
            if not math.isclose(event['distance_m'],profile['inputs']['distance_m'],abs_tol=.001):raise ValueError('candidate coupled profile differs from actual pilot mainline leg')
            event.update(moving_seconds=profile['inputs']['runtime_s'],station_traction_input_kwh=loss['dc_import_kwh'],launch_profile_sha256=loss['profile_sha256'])
    line['duty']['conservative_cycle_seconds']=sum(e['moving_seconds']+60. for e in line['duty']['arrival_events_per_circuit'])
    line.update(pilot_configuration=cfg,launch_profile=profile,launch_loss=loss);line['formation'].update(aw3_mass_kg=6*cfg['controlled_aw3_kg'],gross_storage_kwh=6*cfg['battery_kwh_per_car'])
    return line,choice

def apply_component_costs(economics,changes,fleet,a):
    value=deepcopy(economics);_,_,rates=model.load();integration=1+rates['rates']['vehicle_integration_reserve_fraction'];unreserved=changes['additional_component_cost_usd_per_car']*6*fleet*integration;tooling=changes.get('additional_non_vehicle_tooling_usd',0.);delta=(unreserved+tooling)*(1+a['design_risk_reserve_fraction'])
    value['vehicle_fleet_allowance_usd']+=unreserved;value['capital_with_reserve_usd']+=delta
    monthly=[dict(month=r['month'],capex_usd=r['capex_usd']) for r in value['finance']['monthly_construction_cash']]
    for fraction,day in ((.1,0),(.4,120),(.4,270),(.1,len(monthly)*30)):
        month=min(len(monthly)-1,max(0,math.ceil(day/30)-1));monthly[month]['capex_usd']+=unreserved*(1+a['design_risk_reserve_fraction'])*fraction
    monthly[0]['capex_usd']+=tooling*(1+a['design_risk_reserve_fraction'])
    value['annual_opex_usd']+=delta*a['maintenance_fraction_capital']
    value['finance']=pilot.finance(value['capital_with_reserve_usd'],value['annual_opex_usd'],value['synthetic_daily_paid_trips'],monthly,a=a)
    value['platform_budget']['compact_capital_sensitivity_usd']+=delta
    value['factory_startup_funding']['pooled_budget_usd']+=delta;value['factory_startup_funding']['standalone_budget_usd']+=delta
    value['variant_component_addition']=dict(unreserved_fleet_component_usd=unreserved,non_vehicle_fixture_usd=tooling,reserved_capital_delta_usd=delta,integration_reserve_multiplier=integration,design_risk_reserve_fraction=a['design_risk_reserve_fraction'],rows=changes['rows'])
    return value

def current_actuator_candidate(cfg):
    status=actuators.verify();_,packet=product.verify_packet(actuators.OUTPUT,actuators.SCHEMA,actuators.sources());matches=[r for r in packet['repair_candidates'] if r['configuration_sha256']==cfg['configuration_sha256']]
    if len(matches)!=1:raise ValueError('exact counted candidate missing from current executed actuator packet')
    run=matches[0];actuators.validate_run(run)
    return dict(configuration_sha256=run['configuration_sha256'],profile=run['profile'],profile_sha256=run['profile_sha256'],study_pass=run['study_pass'],failure=run['failure'],screens=run['screens'],
        completed_moving_steps=run['completed_moving_steps'],planned_moving_steps=run['planned_moving_steps'],full_duration=run['requested_duration_s']==run['profile']['inputs']['runtime_s'],packet_manifest_sha256=digest(actuators.OUTPUT/'manifest.json'),
        actual_module_force=pilot_limits.actual_module_force(run),all_negative_controls_held=status['all_negative_controls_held'],qualified_configuration_sha256=status['qualified_configuration_sha256'],control_configuration_sha256=status['control_configuration_sha256'],scope=run['scope'],physical_qualified=False)

def confirmed_profile(execution,profile):
    return bool(execution['study_pass'] and execution['full_duration'] and execution['completed_moving_steps']==execution['planned_moving_steps']
        and execution['profile']==profile and execution['profile_sha256']==sha256(encoded(profile)).hexdigest() and execution['actual_module_force']['passed'] is True)

def exact_controls_held(execution,cfg):
    return execution.get('all_negative_controls_held') is True and execution.get('qualified_configuration_sha256')==execution.get('control_configuration_sha256')==cfg['configuration_sha256']

def part_volume_audit(definition):
    """Independent gross bounds; these cannot recover cut/drilled net solids."""
    rows=[];excluded=0
    for collection in ('retained_parts','fixed_parts','equipment'):
        for part in definition.get(collection,[]):
            if part.get('kind')!='box':excluded+=1;continue
            size=part.get('size_m');known=isinstance(size,(list,tuple)) and len(size)==3 and all(type(x) in (int,float) and math.isfinite(x) and x>0 for x in size)
            gross=math.prod(size) if known else None;reported=part.get('volume_m3');reported_known=type(reported) in (int,float) and math.isfinite(reported) and reported>=0
            tolerance=max(1e-10,gross*1e-8) if known else None;exceeded=known and reported_known and reported>gross+tolerance
            rows.append(dict(id=part['id'],collection=collection,placed_size_m=size,placed_origin_m=part.get('at_m'),gross_bound_volume_m3=gross,
                inherited_reported_net_volume_m3=reported if reported_known else None,comparison_tolerance_m3=tolerance,
                inherited_net_exceeds_placed_gross=bool(exceeded),net_manufactured_volume_m3=None,net_solid_reconciled=False))
    exceeded=[r['id'] for r in rows if r['inherited_net_exceeds_placed_gross']]
    return dict(schema='osr-placed-box-volume-audit/1',definition_sha256=sha256(encoded(definition)).hexdigest(),rows=rows,boxes_checked=len(rows),nonbox_parts_not_checked=excluded,
        inherited_volume_exceeds_bound_ids=exceeded,inherited_volume_exceeds_bound_count=len(exceeded),missing_reported_volume_count=sum(r['inherited_reported_net_volume_m3'] is None for r in rows),
        gross_bound_consistency='failed' if exceeded else 'hold' if any(r['gross_bound_volume_m3'] is None for r in rows) else 'passed',
        state='hold',net_manufacturing_quantities_reconciled=False,mass_or_cost_removal_credit_applied=False,
        scope='Placed box dimensions provide gross upper bounds only. Inherited net-volume metadata can be stale after segmentation; even a value below the bound does not verify holes/cuts/net material. Net-solid/manufacturing quantity reconciliation is held. Existing conservative full-base-stock plus additional-hardware mass/cost is preserved.')

def volume_audit_summary(audit):
    return {key:audit[key] for key in ('schema','definition_sha256','boxes_checked','nonbox_parts_not_checked','inherited_volume_exceeds_bound_ids','inherited_volume_exceeds_bound_count','missing_reported_volume_count','gross_bound_consistency','state','net_manufacturing_quantities_reconciled','mass_or_cost_removal_credit_applied','scope')}

def service_screens(run):
    separations=[b-a for row in run['mainline_segment_departures'] for a,b in zip(row['times_s'],row['times_s'][1:])]
    return dict(actual_berth_replay=run['berth_verification']['verified'],energy_balance=abs(run['event_energy_balance_kwh'])<1e-8,
        battery_window=all(r['battery_after_kwh']>=r['normal_minimum_kwh']-1e-9 for r in run['events']),
        protected_separation=all(v>=run['source_policy_headway_s']-1e-9 for v in separations),finite_dispatch=all(r['start_s']<run['horizon_s'] for r in run['events']))

@lru_cache(maxsize=2)
def _study(source):
    pilot.verify();base=pilot.study();a=load();cfg=actuators.selected_configuration();drive=drive_design.load();drive['support']=deepcopy(cfg['magnetic']['support_winding']);changes=component_changes(cfg,drive,a);execution=current_actuator_candidate(cfg);line,choice=candidate_line(cfg,drive);audit=part_volume_audit(actuators.candidate_packaging(a['winding_variant'])['definition'])
    result=dict(schema=SCHEMA,source_sha256=json.loads(source),assumptions=a,base_configuration_sha256=base['configuration_sha256'],configuration_sha256=cfg['configuration_sha256'],configuration=cfg,
        base_reference=dict(capital_usd=base['economics']['capital_with_reserve_usd'],annual_opex_usd=base['economics']['annual_opex_usd'],hotel_kw_per_car=base['assumptions']['services_kw_per_car'],nominal_maximum_observed_gap_s=base['service_scenarios'][0]['maximum_observed_headway_s'],source_packet_manifest_sha256=digest(pilot.OUTPUT/'manifest.json'),role='Retained separate GFRP/50turn financial planning case; no actuator pass inherited'),
        component_changes=changes,actuator_execution=execution,launch_search=choice,part_volume_audit=audit,selected_for_city_defaults=False,system_qualified=False,**FLAGS)
    if line is None:
        result.update(economics=None,service_scenarios=[],service_screens=[],full_coupled_profile_confirmed=False,system_feasible=False,system_gates=[dict(id='exact-candidate-corridor-launch',state='failed',reason='No current/voltage/thermal feasible launch candidate at counted mass')])
    else:
        assumptions=pilot.load();assumptions['services_kw_per_car']+=changes['energy']['additional_services_kw_per_car'];runs=[pilot.service(k,line=line,a=assumptions) for k in ('nominal','variable-dwell','withdrawal','receiver-failure','charger-failure','combined-recovery')]
        economics=apply_component_costs(pilot.economics(line,base['access'],base['synthetic_demand'],runs[0],assumptions),changes,runs[0]['fleet_total'],assumptions)
        profile_match=execution['profile']==line['launch_profile'] and execution['profile_sha256']==sha256(encoded(line['launch_profile'])).hexdigest();model_pass=confirmed_profile(execution,line['launch_profile'])
        screens=[dict(scenario=r['scenario'],checks=service_screens(r)) for r in runs];safe=all(all(r['checks'].values()) for r in screens);controls=exact_controls_held(execution,cfg)
        result.update(candidate_operating_assumptions=assumptions,service_scenarios=runs,service_screens=screens,economics=economics,full_coupled_profile_confirmed=bool(model_pass),system_feasible=bool(model_pass and controls and safe and not runs[0]['withdrawals']),
            system_gates=[dict(id='exact-candidate-corridor-actuator-model',state='passed' if model_pass else 'failed' if not execution['study_pass'] or execution['actual_module_force']['state']=='failed' else 'hold',profile_matches=profile_match,full_duration=execution['full_duration'],study_pass=execution['study_pass']),
                dict(id='actual-support-module-force',**execution['actual_module_force']),
                dict(id='exact-candidate-control-negative-cases',state='passed' if controls else 'failed'),dict(id='candidate-launch-electrical-screen',state='passed'),dict(id='nominal-source-berth-and-battery-replay',state='passed' if not runs[0]['withdrawals'] else 'failed'),
                dict(id='terminal-loop-and-guidance-coupled-model',state='hold'),dict(id='steel-joined-body-material-fatigue-load-paths',state='hold'),dict(id='guideway-reactions-joints-foundations-at-candidate-load',state='hold'),dict(id='cooling-converter-hardware-and-service-duty',state='hold'),
                dict(id='observed-demand-site-land-and-financial-close',state='hold')],
            partial_model_chain_feasible=bool(model_pass and controls and not runs[0]['withdrawals']))
    if result['source_sha256']!=sources():raise ValueError('variant sources changed during calculation')
    result['system_gates'].append(dict(id='placed-box-net-solid-manufacturing-reconciliation',state='hold',inherited_volume_exceeds_bound_count=audit['inherited_volume_exceeds_bound_count'],scope=audit['scope']))
    return encoded(result)
def study():return json.loads(_study(json.dumps(sources(),sort_keys=True)))

def overview(v):
    e=v['economics'];cost='No feasible candidate launch' if e is None else f'Counted candidate: ${e["capital_with_reserve_usd"]/1e6:.3f}m capital; ${e["annual_opex_usd"]/1e6:.3f}m annual operation'
    state='Full coupled profile confirmed' if v['full_coupled_profile_confirmed'] else 'Full coupled profile NOT confirmed; planning costs do not establish an operable train'
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="350"><rect width="1200" height="350" fill="#f4f7fa"/><g font-family="sans-serif" fill="#16314b"><text x="30" y="45" font-size="24">Separate exact steel / higher-copper pilot sensitivity</text><text x="30" y="105" font-size="19">{cost}</text><text x="30" y="160" font-size="18">AW3 {v["configuration"]["controlled_aw3_kg"]:,.3f} kg/car; exact declared equipment priced.</text><text x="30" y="220" font-size="17">{state}</text><text x="30" y="285" font-size="16">Unquoted costs; continuous heat ceiling; material, cooling, guidance, terminal, site and financial gates open.</text></g></svg>\n'
def readme(v):
    e=v['economics'];details='No launch candidate passes the implemented current/voltage/thermal screens.' if e is None else f'Candidate unquoted capital ${e["capital_with_reserve_usd"]:,.0f}; annual operating allowance ${e["annual_opex_usd"]:,.0f}. Exact component cost rows and procurement-linked capital cash, six service/fault replays and fresh debt/DSCR/funding gaps are retained.'
    execution=v['actuator_execution'];confirmation=f'**Full coupled profile confirmed: {v["full_coupled_profile_confirmed"]}.** Executed {execution["completed_moving_steps"]:,}/{execution["planned_moving_steps"]:,} moving steps; retained failure: {execution["failure"]}. A completed planning DES does not override a failed coupled model.'
    return '# Separate counted actuator candidate: pilot cost and finance\n\n[Computed candidate and raw replays](study.json.gz) · [Placed-part volume audit](part-volume-audit.json.gz) · [Overview](overview.svg) · [Exact source receipt](manifest.json)\n\n'+confirmation+'\n\n'+details+'\n\nThe original GFRP/50turn financial study is preserved. The candidate has independently counted steel tubes/spacers, additional winding copper, mounts and cooling. Costs carry no unidentified GFRP removal credit. Vehicle integration and design reserves apply to the component additions; no overall capital multiplier substitutes for a BOM.\n\nMainline winding/section/voltage choices are recomputed at the candidate mass and exact retained coupled trajectory. Full-duration actuator evidence must have the same configuration and profile; a short or different-profile pass cannot close that gate. Terminal-loop/guidance motion and physical hardware remain held.\n\n'+f'The independent placed-box audit finds {v["part_volume_audit"]["inherited_volume_exceeds_bound_count"]} inherited net-volume records above the actual placed gross dimensional bound. Segmented collector metadata requires reconciliation. Gross bounds are not net manufactured material; all net-solid/manufacturing quantities remain held. The conservative full-base stock plus added hardware mass/cost remains unchanged.\n\n'+'The opaque60kW/car hotel allowance remains. A separately calculated60A continuous winding I²R ceiling and counted cooling auxiliaries are added conservatively; overlap with that unitemised allowance receives no removal credit. Mixed support/wayside Rust heat is not added to the independently computed LSM DC import. This power ceiling is not measured duty or a cooling qualification.\n\nAll prices are planning inputs. Neither candidate nor base is adopted or released for manufacture, passengers, physical operation or financial close.\n'
def publish(output=OUTPUT):
    v=study();p=Path(output);p.mkdir(parents=True,exist_ok=True)
    if p.is_symlink() or any(x.is_symlink() or x.name not in FILES|{'manifest.json'} for x in p.iterdir()):raise ValueError('owned variant packet required')
    raw=encoded(v)
    if len(raw)>MAX_RAW:raise ValueError('bounded variant payload required')
    payload={'study.json.gz':gzip.compress(raw,mtime=0),'part-volume-audit.json.gz':gzip.compress(encoded(v['part_volume_audit']),mtime=0),'overview.svg':overview(v).encode(),'README.md':readme(v).encode()}
    for name,data in payload.items():(p/name).write_bytes(data)
    (p/'manifest.json').write_bytes(encoded(dict(schema=SCHEMA,source_sha256=v['source_sha256'],files_sha256={n:digest(p/n) for n in FILES},**FLAGS)));return verify(p)
def verify(output=OUTPUT):
    p=Path(output)
    if p.is_symlink() or not p.is_dir() or {x.name for x in p.iterdir()}!=FILES|{'manifest.json'} or any(x.is_symlink() for x in p.iterdir()):raise ValueError('exact variant packet required')
    m=json.loads((p/'manifest.json').read_bytes())
    if m.get('source_sha256')!=sources() or any(m.get(k) is not False for k in FLAGS):raise ValueError('variant source/release flags differ')
    for name in FILES:
        if (p/name).stat().st_size>MAX_RAW or digest(p/name)!=m['files_sha256'][name]:raise ValueError('variant checksum/size differs')
    with gzip.GzipFile(fileobj=io.BytesIO((p/'study.json.gz').read_bytes())) as stream:raw=stream.read(MAX_RAW+1)
    value=study()
    if raw!=encoded(value) or (p/'part-volume-audit.json.gz').read_bytes()!=gzip.compress(encoded(value['part_volume_audit']),mtime=0) or (p/'README.md').read_text()!=readme(value) or (p/'overview.svg').read_text()!=overview(value):raise ValueError('variant recalculation/presentation differs')
    return m
def read_summary(output=OUTPUT):
    verify(output);v=study();e=v['economics'];financial=None
    if e:
        f=e['finance'];financial=dict(capital_usd=e['capital_with_reserve_usd'],standalone_capital_usd=e['factory_startup_funding']['standalone_budget_usd'],annual_opex_usd=e['annual_opex_usd'],annual_energy_kwh=e['annual_energy_kwh'],station_assets_allowance_usd=e['station_electrical_allowance_usd'],vehicle_fleet_allowance_usd=e['vehicle_fleet_allowance_usd'],capital_delta_from_base_usd=e['capital_with_reserve_usd']-v['base_reference']['capital_usd'],annual_opex_delta_from_base_usd=e['annual_opex_usd']-v['base_reference']['annual_opex_usd'],comparison_capital_usd=e['comparison_capital_with_reserve_usd'],comparison_annual_opex_usd=e['comparison_energy_and_operation']['annual_opex_usd'],debt_principal_usd=f['debt_principal_usd'],annual_debt_service_usd=f['annual_repayment'][0]['debt_service_usd'],annual_cases=[{k:r[k] for k in ('fare_usd','year','dscr','annual_funding_gap_usd')} for r in f['annual_cases'] if r['year'] in (1,4)])
    return dict(schema=SCHEMA,candidate_name=v['configuration']['id'],configuration_sha256=v['configuration_sha256'],base_configuration_sha256=v['base_configuration_sha256'],controlled_aw3_kg=v['configuration']['controlled_aw3_kg'],actuator_model_pass=bool(v['actuator_execution']['study_pass'] and v['actuator_execution']['actual_module_force']['passed']),actual_module_force=v['actuator_execution']['actual_module_force'],partial_model_chain_feasible=v.get('partial_model_chain_feasible',False),system_feasible=v['system_feasible'],full_coupled_profile_confirmed=v['full_coupled_profile_confirmed'],system_gates=v['system_gates'],part_volume_audit=volume_audit_summary(v['part_volume_audit']),component_changes=v['component_changes'],financial_view=financial,base_reference=v['base_reference'],selected_for_city_defaults=False,system_qualified=False,**FLAGS)
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=('publish','verify'),nargs='?',default='publish');args=parser.parse_args();print(json.dumps(globals()[args.action](),indent=2))
