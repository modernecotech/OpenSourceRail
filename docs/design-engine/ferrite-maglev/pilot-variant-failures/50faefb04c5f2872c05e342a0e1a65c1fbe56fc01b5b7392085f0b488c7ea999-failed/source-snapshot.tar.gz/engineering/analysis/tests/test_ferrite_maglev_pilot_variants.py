"""Counted variant identity, replacement costs, energy and finance boundaries."""
from copy import deepcopy
import gzip
from hashlib import sha256
import json

import pytest
from engineering.ferrite_maglev import pilot_variants as v,pilot_actuators as a,pilot_corridor as p,model

@pytest.fixture(scope='module')
def candidate():
    values=v.load();return a.variant_configuration(values['body_variant'],values['winding_variant'])

def test_exact_component_mass_and_cost_changes_reconcile(candidate):
    cfg,drive=candidate;r=v.component_changes(cfg,drive);rows={row['id']:row for row in r['rows']}
    assert r['incremental_mass_kg_per_car']==pytest.approx(1299.725392132813)
    assert rows['additional-winding-copper']['mass_change_kg_per_car']==pytest.approx(790.659072)
    assert rows['additional-cooling']['mass_change_kg_per_car']==120 and rows['additional-cooling']['additional_cost_usd_per_car']==7200
    assert rows['detachable-collector-splices']['mass_change_kg_per_car']==pytest.approx(106.01367954281218)
    assert rows['detachable-collector-splices']['hardware_counts_per_car']['new_splice_plates']==96
    assert rows['detachable-collector-splices']['hardware_counts_per_car']['new_m8_bolts']==384
    assert r['additional_non_vehicle_tooling_usd']==3000 and not r['tooling']['fixture_is_onboard_mass']
    assert r['removed_gfrp_cost_credit_usd']==0 and r['mass_and_cost_are_distinct_ledgers']
    cfg=deepcopy(cfg);cfg['controlled_aw3_kg']+=1
    with pytest.raises(ValueError,match='mass changes'):v.component_changes(cfg,drive)

def test_energy_is_component_i_squared_r_and_not_mixed_rust_heat(candidate):
    cfg,drive=candidate;r=v.component_changes(cfg,drive)['energy'];coil=v.drive_design.support(drive)['coil']
    assert r['support_continuous_copper_ceiling_kw_per_car']==pytest.approx(72*60**2*coil['resistance_hot_ohm']/1000)
    assert r['cooling_auxiliary_kw_per_car']==pytest.approx(24*15/1000)
    assert r['additional_services_kw_per_car']>19 and r['source_hotel_removed_kw']==0
    assert not r['base_hotel_support_split_known']

def test_cost_rate_changes_do_not_modify_physical_candidate_mass(candidate):
    cfg,drive=candidate;a=v.load();original=v.component_changes(cfg,drive,a);a['fabricated_steel_usd_per_kg']*=2;changed=v.component_changes(cfg,drive,a)
    assert changed['incremental_mass_kg_per_car']==original['incremental_mass_kg_per_car']
    assert changed['additional_component_cost_usd_per_car']-original['additional_component_cost_usd_per_car']==pytest.approx(original['rows'][0]['additional_cost_usd_per_car'])

def test_exact_executed_groups_are_priced_without_cheaper_substitution(candidate,monkeypatch):
    cfg,drive=candidate;captured={}
    def loss(profile,**values):
        captured.update(values);return dict(feasible=False,controlled_mass_matches=True,candidate={k:values[k] for k in cfg['wayside_drive']},limits=dict(voltage=False))
    monkeypatch.setattr(v.launch,'loss_model',loss);result=v.selected_launch({},cfg,drive)
    assert {k:captured[k] for k in cfg['wayside_drive']}==cfg['wayside_drive']
    assert captured['_context'][2]['configuration_sha256']==cfg['configuration_sha256']
    assert result['candidate_count']==1 and result['selected'] is None
    assert not result['independent_optimum_substituted']

def test_component_addition_reprices_procurement_cash_and_repayment():
    a=p.load();monthly=[dict(month=i+1,capex_usd=1e8/12) for i in range(12)];base=dict(vehicle_fleet_allowance_usd=1e7,capital_with_reserve_usd=1e8,annual_opex_usd=4e6,synthetic_daily_paid_trips=10000.,finance=p.finance(1e8,4e6,10000,monthly,a=a),platform_budget=dict(compact_capital_sensitivity_usd=9e7),factory_startup_funding=dict(pooled_budget_usd=1e8,standalone_budget_usd=1.02e8))
    changes=dict(additional_component_cost_usd_per_car=1000.,rows=[]);r=v.apply_component_costs(base,changes,10,a);rates=model.load()[2]['rates'];delta=1000*60*(1+rates['vehicle_integration_reserve_fraction'])*1.3
    assert base['capital_with_reserve_usd']==1e8 and r['capital_with_reserve_usd']==pytest.approx(1e8+delta)
    assert sum(row['capex_usd'] for row in r['finance']['monthly_construction_cash'])==pytest.approx(1e8+delta)
    assert r['finance']['debt_principal_usd']==pytest.approx((1e8+delta)*.6)
    assert r['annual_opex_usd']==pytest.approx(4e6+delta*.02)

def test_independent_service_screen_rejects_unsafe_window_and_dispatch():
    run=p.service(line=p.city_line());assert all(v.service_screens(run).values())
    broken=deepcopy(run);broken['events'][0]['battery_after_kwh']=0
    assert not v.service_screens(broken)['battery_window']
    broken=deepcopy(run);broken['events'][0]['start_s']=run['horizon_s']
    assert not v.service_screens(broken)['finite_dispatch']

def test_failed_control_or_different_control_identity_holds_candidate():
    cfg=dict(configuration_sha256='exact-candidate');execution=dict(all_negative_controls_held=True,qualified_configuration_sha256='exact-candidate',control_configuration_sha256='exact-candidate')
    assert v.exact_controls_held(execution,cfg)
    execution['all_negative_controls_held']=False;assert not v.exact_controls_held(execution,cfg)
    execution['all_negative_controls_held']=True;execution['control_configuration_sha256']='cheaper-old-case';assert not v.exact_controls_held(execution,cfg)

def test_actual_force_limit_and_unknown_block_full_profile_confirmation():
    profile=dict(exact_tested_profile=True);execution=dict(study_pass=True,full_duration=True,completed_moving_steps=10,planned_moving_steps=10,profile=profile,profile_sha256=sha256(v.encoded(profile)).hexdigest())
    execution['actual_module_force']=v.pilot_limits.actual_module_force(dict(extrema=dict(peak_module_force_n=20000.)))
    assert v.confirmed_profile(execution,profile)
    execution['actual_module_force']=v.pilot_limits.actual_module_force(dict(extrema=dict(peak_module_force_n=20000.01)))
    assert execution['actual_module_force']['state']=='failed' and not v.confirmed_profile(execution,profile)
    execution['actual_module_force']=v.pilot_limits.actual_module_force({})
    assert execution['actual_module_force']['state']=='hold' and not v.confirmed_profile(execution,profile)

def test_gross_box_audit_rejects_inherited_volume_without_claiming_net_material():
    definition=dict(retained_parts=[dict(id='segmented-collector',kind='box',size_m=[.99,.006,.08],at_m=[10.,20.,30.],volume_m3=12*.006*.08),dict(id='drilled-part',kind='box',size_m=[1.,.1,.1],volume_m3=.009)],fixed_parts=[],equipment=[dict(id='packaging',kind='box',size_m=[1.,.2,.1])])
    before=deepcopy(definition);audit=v.part_volume_audit(definition);rows={r['id']:r for r in audit['rows']}
    assert definition==before and audit['inherited_volume_exceeds_bound_ids']==['segmented-collector']
    assert rows['segmented-collector']['gross_bound_volume_m3']==pytest.approx(.0004752)
    assert rows['segmented-collector']['inherited_reported_net_volume_m3']==pytest.approx(.00576)
    assert not rows['drilled-part']['inherited_net_exceeds_placed_gross']
    assert all(r['net_manufactured_volume_m3'] is None and not r['net_solid_reconciled'] for r in rows.values())
    assert audit['state']=='hold' and not audit['mass_or_cost_removal_credit_applied']

def test_current_candidate_segmented_collectors_have_a_visible_volume_hold():
    definition=a.candidate_packaging(v.load()['winding_variant'])['definition'];audit=v.part_volume_audit(definition)
    assert audit['inherited_volume_exceeds_bound_count']>0
    assert any('collector' in identity for identity in audit['inherited_volume_exceeds_bound_ids'])
    assert not v.volume_audit_summary(audit)['net_manufacturing_quantities_reconciled']

def test_published_current_candidate_binds_full_profile_and_rejects_rehashed_price(tmp_path):
    v.publish(tmp_path);value=v.study();summary=v.read_summary(tmp_path)
    assert summary['configuration_sha256']==value['actuator_execution']['configuration_sha256']
    assert summary['base_configuration_sha256']!=summary['configuration_sha256']
    assert not summary['automatic_adoption'] and not summary['system_qualified']
    if summary['full_coupled_profile_confirmed']:
        assert value['actuator_execution']['profile_sha256']==value['launch_search']['selected']['profile_sha256']
        assert value['actuator_execution']['completed_moving_steps']==value['actuator_execution']['planned_moving_steps']
    if value['economics'] is not None:value['economics']['capital_with_reserve_usd']=1.
    else:value['system_feasible']=True
    (tmp_path/'study.json.gz').write_bytes(gzip.compress(v.encoded(value),mtime=0));m=json.loads((tmp_path/'manifest.json').read_bytes());m['files_sha256']['study.json.gz']=v.digest(tmp_path/'study.json.gz');(tmp_path/'manifest.json').write_bytes(v.encoded(m))
    with pytest.raises(ValueError,match='recalculation'):v.verify(tmp_path)
