
import FreeCAD as A,Part,Import,json,pathlib
out=pathlib.Path(__file__).parent;data=json.loads((out/'input.json').read_text());doc=A.newDocument('OSR_Generative_Stock');objects=[];rows=[]
for i,p in enumerate(data['parts']):
    if p['kind']=='box':shape=Part.makeBox(*[x*1000 for x in p['size_m']],A.Vector(*[x*1000 for x in p['at_m']]))
    elif p['kind']=='oriented-RHS':
        w,h,t,L=[p[k]*1000 for k in ('width_m','height_m','wall_m','length_m')]
        shape=Part.makeBox(w,h,L,A.Vector(-w/2,-h/2,0)).cut(Part.makeBox(w-2*t,h-2*t,L,A.Vector(-w/2+t,-h/2+t,0)))
        m=A.Matrix()
        for r in range(3):
            for c in range(3):setattr(m,'A'+str(r+1)+str(c+1),p['basis'][r][c])
        shape.transformShape(m);shape.translate(A.Vector(*[x*1000 for x in p['start_m']]))
    else:raise ValueError('Unsupported actual primitive')
    v=shape.Volume/1e9
    if not shape.isValid() or abs(v-p['volume_m3'])>max(1e-10,1e-7*p['volume_m3']):raise ValueError('Native gross stock differs:'+p['id'])
    obj=doc.addObject('PartDesign::Feature','Stock_'+str(i));obj.Label=p['id'];obj.Shape=shape
    for k,value in [('CandidateID',data['candidate_id']),('OccurrenceID',p['id']),('Scope','Gross stock; complete installed assembly unqualified')]:obj.addProperty('App::PropertyString',k);setattr(obj,k,value)
    objects.append(obj);rows.append(dict(id=p['id'],volume_m3=v))
doc.recompute();doc.saveAs(str(out/'structure.FCStd'));Import.export(objects,str(out/'structure.step'));A.closeDocument(doc.Name)
doc=A.openDocument(str(out/'structure.FCStd'));actual=[o for o in doc.Objects if hasattr(o,'Shape')];reopened=sum(o.Shape.Volume for o in actual)/1e9
if len(actual)!=len(rows):raise ValueError('Reopened occurrences differ')
A.closeDocument(doc.Name);step=Part.Shape();step.read(str(out/'structure.step'));expected=sum(r['volume_m3'] for r in rows)
if abs(reopened-expected)>max(1e-9,expected*1e-7) or abs(step.Volume/1e9-expected)>max(1e-9,expected*1e-7):raise ValueError('Reopened CAD/STEP stock differs')
(out/'result.json').write_text(json.dumps(dict(candidate_id=data['candidate_id'],occurrences=rows,gross_stock_volume_m3=expected,reopened_volume_m3=reopened,STEP_volume_m3=step.Volume/1e9,FreeCAD_version=list(A.Version()),physical_accepted=False),sort_keys=True)+'\n')
