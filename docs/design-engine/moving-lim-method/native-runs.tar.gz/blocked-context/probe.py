from pathlib import Path
import json,sys,subprocess,shutil,time
import numpy as np,scipy
import numpy._core._multiarray_umath as numpycore
import scipy.sparse.linalg._dsolve._superlu as superlu
from engineering.design_search import moving_lim as m
from engineering.station_rail.common import digest,identity,encoded
root=Path('/tmp/osr-objectives-20261027');base=Path('/tmp/osr-fully-overlapped-launch-probe-20261027');started=time.monotonic()
oldpath=Path('/tmp/osr-fine-timestep-20261027/motoring-fine-dt-quarter');old=json.loads((oldpath/'input.json').read_bytes())['request']
source=m.sources(root);head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='e20d5a6fdf5190ad2e0feb5fb0f7171241d2cf6c'
assert subprocess.check_output(['git','status','--short'],cwd=root,text=True)==''
assert source==json.loads((oldpath/'input.json').read_bytes())['source_sha256']
assert source[m.CODE]=='03a4d586fde84296fefd6f5c64c88f9c97373e1a27ef1b2aa6aea02202d81ae6'
r=m.request(old['bundle_definition'],start_m=.5,speed_m_s=0.,voltage_peak_V=2.,frequency_Hz=50.,dt_s=.001,steps=128,mesh_m=.03,temperature_C=80.,current_limit_A=140.,linear=False,transport_method='galerkin');m.validate(r);estimate=m.estimate(r)
assert estimate['nodes']<=75000 and estimate['unstabilized_domain_supported'] and estimate['Peclet_max']==0
mesh=m.mesh_fingerprint(*m.mesh(r))
tool=dict(python=sys.version,python_path=sys.executable,python_sha256=digest(sys.executable),numpy=np.__version__,numpy_core_sha256=digest(numpycore.__file__),scipy=scipy.__version__,superlu_sha256=digest(superlu.__file__),threads=1)
plan=dict(schema='osr-full-overlap-launch-state-probe/1',source_git_HEAD=head,source_sha256=source,tool=tool,name='full-overlap-at-rest',request=r,cheap_estimate=estimate,actual_mesh=mesh,maximum_component_jobs=1,maximum_seconds_per_job_external=90,maximum_seconds_per_job_internal=85,maximum_address_space_bytes=2147483648,maximum_nodes=75000,maximum_planning_and_native_seconds=180,no_retries=True,linear_work_runtime_heuristic_s=57.441*2*(estimate['nodes']/44643)**1.5,runtime_heuristic_is_guarantee=False,coordinate='Component secondary longitudinal start relative to primary; not route nose or installed train transform',comparison_scope='Differentposition/speed/duration/mesh/transport; not a single-variable convergence comparison',physical_accepted=False,operating_map_admitted=False)
plan['plan_id']=identity(plan);(base/'plan.json').write_bytes(encoded(plan));(base/'tool-snapshot.json').write_bytes(encoded(tool))
for name in source:
 p=base/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,p)
command=dict(command=[sys.executable,str(base/'probe.py')],cwd=str(root),environment=dict(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'),source_frozen_before_job=True);(base/'command.json').write_bytes(encoded(command))
print(json.dumps(dict(plan_id=plan['plan_id'],request_id=r['request_id'],estimate=estimate,heuristic_s=plan['linear_work_runtime_heuristic_s'])),flush=True)
native_started=time.monotonic();result=m.run(r,base/'full-overlap-at-rest',root=root);native_wall=time.monotonic()-native_started
assert m.sources(root)==source
verified=m.verify(base/'full-overlap-at-rest',root=root)
report=dict(plan_id=plan['plan_id'],evaluation_id=result['evaluation_id'],execution=result['execution'],state=result.get('state'),reason=result.get('reason'),native_wall_s=native_wall,planning_and_native_wall_s=time.monotonic()-started,source_unchanged=True,verified=verified,physical_accepted=False,operating_map_admitted=False)
report['campaign_id']=identity(report);(base/'campaign.json').write_bytes(encoded(report));print(json.dumps(report),flush=True)
