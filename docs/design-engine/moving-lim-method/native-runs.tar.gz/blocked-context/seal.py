from pathlib import Path
from hashlib import sha256
import json,tarfile,io,gzip,sys,subprocess
from engineering.station_rail.common import encoded,identity,digest
from engineering.design_search import moving_lim as m
base=Path('/tmp/osr-fully-overlapped-launch-probe-20261027');root=Path('/tmp/osr-objectives-20261027');plan=json.loads((base/'plan.json').read_bytes());campaign=json.loads((base/'campaign.json').read_bytes());assessment=json.loads((base/'assessment.json').read_bytes());case=base/'full-overlap-at-rest'
assert m.sources(root)==plan['source_sha256'];verified=m.verify(case,root=root)
resources=dict(schema='osr-launch-probe-resource-report/1',native_attempts=1,retries=0,native_wall_s=campaign['native_wall_s'],internal_step_start_deadline_s=85,internal_step_guard_may_overshoot_until_current_step_completes=True,external_subprocess_deadline_s=90,RLIMIT_AS_bytes=2147483648,actual_peak_RAM_bytes=None,declared_planning_native_budget_s=180,script_reported_planning_and_native_s=campaign['planning_and_native_wall_s'],script_report_scope='In-script preparation plus native job only; preliminary read/cheap-check calls are excluded',first_recorded_cheap_check_UTC='2026-10-27 21:57:38 UTC',native_start_UTC_to_seconds='2026-10-27 21:58:49 UTC',approximate_observed_first_check_to_native_end_s=158,approximate_total_is_not_exact_timing=True,postprocessing_outside_native_budget=True,heuristic_s=plan['linear_work_runtime_heuristic_s'],heuristic_exceeded_internal_budget=True,definition_decision='Original .03 single attempt was already executing when coordinator advised coarser .04 if not started; coordinator explicitly prohibited cancellation/restart/retry once started. No .04 case executed.',source_unchanged=True,read_only_source_enforcement='Instruction and before/after hashes; not an enforced OS read-only source sandbox',physical_accepted=False,operating_map_admitted=False)
(base/'resources.json').write_bytes(encoded(resources))
commands=dict(schema='osr-launch-probe-commands/1',native=dict(argv=[sys.executable,str(base/'probe.py')],cwd=str(root),environment=dict(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONPATH=str(root)),stdout='campaign.stdout.log',stderr='campaign.stderr.log'),analysis=dict(argv=[sys.executable,str(base/'assess.py')],cwd=str(root),environment=dict(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONPATH=str(root)),stdout='assessment.stdout.log',stderr='assessment.stderr.log'),sealed_numerical_sources=plan['source_sha256'],verified=verified)
(base/'commands.json').write_bytes(encoded(commands))
scope=dict(schema='osr-launch-probe-scope/1',physical_candidate=plan['request']['bundle_id'],motor_component_id=plan['request']['motor_component_id'],execution='interrupted',actual_end_time_s=.035,complete_journey=False,available_operating_map=None,complete_installed_mass_kg=None,thermal_duty=None,steady_state_verified=False,time_convergence_verified=False,space_convergence_verified=False,source_grade_measured=False,physical_accepted=False,engineering_accepted=False,configuration_adopted=False,manufacturing_release=False,operating_release=False,qualifying_evidence=False,interpretation='Only firstcold fullcycle has positiveaverage; laterfullcycles unavailable. Instantaneousforces alternate sign. This cannot be used as installed or sustained available traction.',coordinate='Component secondary-start position, no implied installed train/route transform',new_phase_or_architecture_selected=False)
(base/'scope.json').write_bytes(encoded(scope))
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();status=subprocess.check_output(['git','status','--short'],cwd=root,text=True)
(base/'source-integrity.json').write_bytes(encoded(dict(source_git_HEAD_at_native_freeze=plan['source_git_HEAD'],source_git_HEAD_at_postprocessing=head,status_at_postprocessing=status,all10_numerical_producer_hashes_unchanged=m.sources(root)==plan['source_sha256'],source_edits_by_worker=0,original_native_manifest_sha256=digest(case/'manifest.json'))))
files={p.relative_to(base).as_posix():digest(p) for p in sorted(base.rglob('*')) if p.is_file() and p.name!='artifact-index.json'}
index=dict(schema='osr-launch-probe-artifact-index/1',files_sha256=files,files=len(files),plan_id=plan['plan_id'],campaign_id=campaign['campaign_id'],assessment_id=assessment['assessment_id'],evaluation_id=campaign['evaluation_id'],physical_accepted=False,operating_map_admitted=False,source_protected_by_hash_inventory=True,OS_enforced_read_only_isolation=False)
index['artifact_id']=identity(index);(base/'artifact-index.json').write_bytes(encoded(index))
stream=io.BytesIO()
with tarfile.open(fileobj=stream,mode='w') as tar:
 for p in sorted(base.rglob('*')):
  if p.is_symlink():raise ValueError('No links')
  if not p.is_file():continue
  data=p.read_bytes();entry=tarfile.TarInfo(p.relative_to(base).as_posix());entry.mode=0o444;entry.mtime=0;entry.size=len(data);tar.addfile(entry,io.BytesIO(data))
archive=base.with_suffix('.tar.gz');archive.write_bytes(gzip.compress(stream.getvalue(),mtime=0))
for p in base.rglob('*'):
 if p.is_file():p.chmod(0o444)
archive.chmod(0o444)
print(json.dumps(dict(archive=str(archive),bytes=archive.stat().st_size,sha256=digest(archive),files_in_archive=len(files)+1,artifact_id=index['artifact_id'],assessment_id=assessment['assessment_id'],evaluation_id=campaign['evaluation_id'],original_native_manifest_sha256=digest(case/'manifest.json')),indent=2))
