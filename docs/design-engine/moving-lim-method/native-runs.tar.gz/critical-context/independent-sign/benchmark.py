"""Independent manufactured sign/unit controls; no FEM/native imports."""
import json
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent;p=json.loads((HERE/'input.json').read_bytes())
lam=p['wavelength_m'];k=2*np.pi/lam;w=2*np.pi*p['frequency_Hz'];sigma=p['sigma_S_m'];A0=p['A0_T_m'];volume=lam*p['thickness_m']*p['height_m']
x=np.arange(p['x_samples'])*lam/p['x_samples'];time=np.arange(p['time_samples'])/(p['frequency_Hz']*p['time_samples']);phase=k*x[None,:]-w*time[:,None];Ax=-k*A0*np.sin(phase);At=w*A0*np.sin(phase)
phase_index=np.array([0,2,1,0,2,1]);sign=np.array([1,-1,1,-1,1,-1]);theta=np.arange(6)*np.pi/3
error=float(np.max(abs(sign[None,:]*np.cos(w*time[:,None]-phase_index[None,:]*2*np.pi/3)-np.cos(w*time[:,None]-theta[None,:]))));assert error<1e-13
rows=[]
for v in p['speeds_m_s']:
 for direction in (1,-1):
  local_phase=k*x[None,:]-direction*w*time[:,None];ax=-k*A0*np.sin(local_phase);at=direction*w*A0*np.sin(local_phase);u=-np.mean(at+v*ax,axis=1);D=at+v*ax+u[:,None];J=-sigma*D
  F=float(np.mean(J*ax)*volume);heat=float(np.mean(J*J/sigma)*volume);field=float(np.mean(sigma*at*D)*volume);exact=sigma*k*(direction*w-k*v)*A0*A0*volume/2
  assert abs(F-exact)<1e-10 and abs(field-heat-v*F)<1e-9
  rows.append(dict(v_m_s=v,direction=direction,Fx_N=F,closed_form_N=exact,Joule_W=heat,mechanical_W=v*F,field_work_W=field,power_residual_W=field-heat-v*F,net_current_A=float(np.max(abs(J.mean(axis=1)*lam*p['thickness_m'])))))
# Separate imposed RL history: a_dot+alpha*a=omega*A0*exp(-i*omega*t), a(0)=0.
# This mixes a decaying stationary term with a commanded travelling term.
# It is not the finite FEM and does not diagnose the actual archived runs.
startup=[];alpha=p['cold_start_alpha_per_s'];driver=w*A0
for t in p['cold_start_times_s']:
 a=driver*(np.exp(-1j*w*t)-np.exp(-alpha*t))/(alpha-1j*w);adot=driver*np.exp(-1j*w*t)-alpha*a;spatial=np.exp(1j*k*x);at=np.real(adot*spatial);ax=np.real(1j*k*a*spatial);v=20.;D=at+v*ax;J=-sigma*D
 F=float(np.mean(J*ax)*volume);exact=float(-sigma*volume/2*np.real((adot+1j*k*v*a)*np.conj(1j*k*a)));assert abs(F-exact)<1e-10
 startup.append(dict(t_s=t,Fx_N=F,closed_form_N=exact,commanded_nominal_slip_Hz=p['frequency_Hz']-v/lam))
assert any(r['Fx_N']<0 for r in startup) and startup[-1]['Fx_N']>0
r=dict(schema='osr-manufactured-LIM-sign-result/1',winding_register_error=error,periodic_cases=rows,cold_start_imposed_field_example=startup,physical_accepted=False,operating_map_admitted=False,actual_negative_force_cause_diagnosed=False)
(HERE/'benchmark-result.json').write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps(r,sort_keys=True))
