from pathlib import Path
import json,tarfile,io
from engineering.station_rail.common import identity,encoded,digest
base=Path('/tmp/osr-critical-mesh-20261027')
p=base/'next-tasks.json';d=json.loads(p.read_bytes());d.pop('ranking_id')
d['tasks'][2]['required']+='; compare force sign via explicit phase reversal and v=0 blocked-secondary controls before accepting a field-map sign convention'
d['tasks'][3]=dict(rank=4,task='Resolve startup/phase history using separately declared numerical hypotheses',reason='All nonzero16ms traces have negative thrust despite nominal+10Hz slip. This may not be relabelled propulsive performance and remains an unresolved sign/startup diagnosis.',required='After cheap analytic phase/Lorentz-sign audit and appropriate convergence controls: explicit phase-reversal, blocked-secondary, full-overlap and warm-start controls; longer history; distinguish transient entry drag, terminal excitation and actual branch-current phase. Each needs a separate evaluation and newly authorized field budget.')
d['tasks'].append(dict(rank=5,task='Develop and independently test actual current-control and converter/braking interfaces',reason='The present ideal voltage source solves branch-current dynamics but does not implement real current regulation, switching/protection, finite-height return paths or a receiving regenerative sink.',required='Authenticated winding/circuit topology and converter/current limits; controller tracking/limiting tests; protection/fault timing; regeneration and receiving brake-energy sink; repeated losses/cooling with measured limits. Complete installed equipment mass, costs and protection envelopes remain unknown.'))
d['explicitly_precedes_operating_map_selection']=['Numerical time/local/global-space controls','Independent matched2D field/circuit comparison','Unresolved phase/Lorentz sign audit and phase-reversal/blocked/full-overlap/warm-start controls','Actual current-controller/converter/braking interface and repeated-duty checks']
d['ranking_id']=identity(d);p.write_bytes(encoded(d))
(base/'audit-invocation-history.json').write_bytes(encoded(dict(schema='osr-audit-command-history/1',attempts=[dict(command='/home/hayder/Documents/OpenSourceRail/.venv/bin/python /tmp/osr-critical-mesh-20261027/finalize-audit.py',cwd='/tmp/osr-objectives-20261027',returncode=1,reason='ModuleNotFoundError: No module named engineering; invoking an external script did not include checkout on sys.path',field_jobs_started=0),dict(command='PYTHONPATH=. /home/hayder/Documents/OpenSourceRail/.venv/bin/python /tmp/osr-critical-mesh-20261027/finalize-audit.py',cwd='/tmp/osr-objectives-20261027',returncode=0,field_jobs_started=0)],scope='Read-only arithmetic/provenance audit plus focused tests; no additional field solves')))
entries={str(p.relative_to(base)):dict(sha256=digest(p),bytes=p.stat().st_size) for p in sorted(base.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name not in ('artifact-index.json',)}
index=dict(schema='osr-critical-LIM-artifact-index/1',files=entries,raw_field_jobs=6,completed_field_jobs=6,additional_field_jobs_in_audit=0,physical_accepted=False,operating_map_admitted=False,immutability='Content-addressed inventory; not an OS-enforced read-only environment')
index['artifact_index_id']=identity(index);(base/'artifact-index.json').write_bytes(encoded(index))
archive=base.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as out:
    for name in sorted([*entries,'artifact-index.json']):
        p=base/name;data=p.read_bytes();info=tarfile.TarInfo(base.name+'/'+name);info.size=len(data);info.mode=0o444;info.mtime=0;out.addfile(info,io.BytesIO(data))
for name in [*entries,'artifact-index.json']:(base/name).chmod(0o444)
archive.chmod(0o444)
print(json.dumps(dict(ranking_id=d['ranking_id'],artifact_index_id=index['artifact_index_id'],archive=str(archive),archive_sha256=digest(archive),archive_bytes=archive.stat().st_size,files=len(entries)+1),indent=2))
