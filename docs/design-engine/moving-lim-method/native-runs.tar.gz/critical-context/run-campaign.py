from pathlib import Path
from time import monotonic
import json,subprocess,shutil,sys
import numpy as np,scipy
import numpy._core._multiarray_umath as numpycore
import scipy.sparse.linalg._dsolve._superlu as superlu
from engineering.design_search import moving_lim as m,lim_critical_mesh as c,railway_bundle,design_grammar
from engineering.station_rail.common import identity,encoded,digest
root=Path('/tmp/osr-objectives-20261027');base=Path('/tmp/osr-critical-mesh-20261027');epoch=m.sources(root)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();physicalbase=subprocess.check_output(['git','rev-parse','1692bb45f7'],cwd=root,text=True).strip()
tests=['engineering/design_search/tests/test_lim_critical_mesh.py','engineering/design_search/tests/test_lim_transport.py','engineering/design_search/tests/test_moving_lim.py','engineering/design_search/tests/test_transient_lim.py']
for name in (*epoch,*tests):
 p=base/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,p)
tool=dict(python=sys.version,python_path=sys.executable,python_sha256=digest(sys.executable),numpy=np.__version__,numpy_core_sha256=digest(numpycore.__file__),scipy=scipy.__version__,superlu_sha256=digest(superlu.__file__),threads=1)
(base/'tool-snapshot.json').write_bytes(encoded(tool));b=railway_bundle.materialize(design_grammar.initial_candidates()[0])
specs=[('zero-medium',.01,.001875,0.),('motoring-coarse',.02,.00375,2.),('motoring-x-refined',.01,.00375,2.),('motoring-y-refined',.02,.001875,2.),('motoring-medium',.01,.001875,2.),('motoring-fine',.005,.0009375,2.)]
requests=[dict(name=name,request=m.request(b,speed_m_s=20.,frequency_Hz=50.,dt_s=.001,steps=16,transport_method='supg-coth',mesh_family=c.NAME,critical_dx_m=dx,secondary_dy_m=dy,voltage_peak_V=voltage)) for name,dx,dy,voltage in specs]
plan=dict(schema='osr-critical-LIM-plan/1',source_freeze_git_HEAD=head,physical_base_revision=physicalbase,source_sha256=epoch,test_source_sha256={n:digest(root/n) for n in tests},tool=tool,requests=requests,cheap_estimates={x['name']:m.estimate(x['request']) for x in requests},maximum_component_jobs=6,maximum_total_seconds=600,maximum_seconds_per_job=90,maximum_address_space_bytes=2*1024**3,approved_node_cap=75000,physical_accepted=False,operating_map_admitted=False)
plan['plan_id']=identity(plan);(base/'plan.json').write_bytes(encoded(plan));rows=[];started=monotonic()
for item in requests:
 if m.sources(root)!=epoch:raise ValueError('Frozen critical mesh source changed')
 if monotonic()-started+90>600:
  rows.append(dict(name=item['name'],execution='pending-total-budget',request_id=item['request']['request_id']));continue
 t=monotonic();r=m.run(item['request'],base/item['name'],root=root);check=m.verify(base/item['name'],root=root)
 row=dict(name=item['name'],execution=r['execution'],state=r.get('state'),reason=r.get('reason'),request_id=item['request']['request_id'],evaluation_id=r['evaluation_id'],elapsed_s=monotonic()-t,verification=check,trace_rows=len(r.get('trace',[])))
 if r.get('trace'):
  trace=r['trace'];row.update(nodes=r['nodes'],elements=r['elements'],Peclet_max=r['Peclet_max'],mesh_diagnostics=r['mesh_diagnostics'],actual_mesh=r['actual_mesh'],final=trace[-1],peak_current_A=max(abs(i) for p in trace for i in p['path_currents_A']),peak_steel_T=max(p['peak_steel_B_T'] for p in trace),maximum_power_residual_W=max(abs(p['discrete_power_residual_W']) for p in trace),signed_stabilization_J=sum(p['stabilization_work_W']*item['request']['dt_s'] for p in trace))
 rows.append(row);print(json.dumps({k:v for k,v in row.items() if k not in ('verification','final','actual_mesh')}),flush=True)
report=dict(schema='osr-critical-LIM-results/1',plan_id=plan['plan_id'],source_sha256=epoch,source_freeze_git_HEAD=head,physical_base_revision=physicalbase,tool=tool,rows=rows,attempted_jobs=sum(p['execution']!='pending-total-budget' for p in rows),completed_jobs=sum(p['execution']=='completed' and p.get('state')=='completed' for p in rows),elapsed_s=monotonic()-started,source_unchanged=m.sources(root)==epoch,physical_accepted=False,operating_map_admitted=False)
report['campaign_id']=identity(report);(base/'campaign.json').write_bytes(encoded(report));print('CAMPAIGN '+report['campaign_id'],flush=True)
