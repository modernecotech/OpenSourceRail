from pathlib import Path
import sys,json,subprocess,shutil
import numpy as np,scipy
import numpy._core._multiarray_umath as numpycore
import scipy.sparse.linalg._dsolve._superlu as superlu
from engineering.design_search import moving_lim as m,lim_critical_mesh as c
from engineering.station_rail.common import identity,encoded,digest
root=Path('/tmp/osr-objectives-20261027');base=Path('/tmp/osr-fine-timestep-20261027');previous=Path('/tmp/osr-critical-mesh-20261027')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='b4f338a6d07a610c7c5ad4e441dbe2c0def2de09'
source=m.sources(root)
assert source[m.CODE]=='03a4d586fde84296fefd6f5c64c88f9c97373e1a27ef1b2aa6aea02202d81ae6'
assert source[c.CODE]=='201ad4b3fb829437e1b121827416deb63d53c09d12dcbfac0c8c475ebf8aef64'
old_input=json.loads((previous/'motoring-fine'/'input.json').read_bytes());old_request=old_input['request'];old_result=json.loads((previous/'motoring-fine'/'result.json').read_bytes());old_plan=json.loads((previous/'plan.json').read_bytes())
assert source==old_input['source_sha256']==old_plan['source_sha256']
assert old_request['bundle_id']=='70eb0ba82c796bc3ec3c52dbdb1c64db15b0d337c64a021f5a5ed3956a28fdc5'
assert old_request['motor_component_id']=='be98f644c7c5117cb0423970c02501f234c3488689db8b0d017ef34dc6718dc5'
assert old_request['mesh_definition']['critical_dx_m']==.005 and old_request['mesh_definition']['secondary_dy_m']==.0009375
assert old_request['linear'] is False and old_request['frequency_Hz']==50. and old_request['voltage_peak_V']==2. and old_request['speed_m_s']==20. and old_request['start_m']==-8.95 and old_request['temperature_C']==80.
old_verified=m.verify(previous/'motoring-fine',root=root)
tool=dict(python=sys.version,python_path=sys.executable,python_sha256=digest(sys.executable),numpy=np.__version__,numpy_core_sha256=digest(numpycore.__file__),scipy=scipy.__version__,superlu_sha256=digest(superlu.__file__),threads=1)
assert tool==old_plan['tool']
for key in ('python','python_sha256','numpy','scipy','superlu_sha256','threads'):assert tool[key]==old_result['tool'][key]
requests=[]
for name,dt,steps in [('motoring-fine-dt-half',.0005,32),('motoring-fine-dt-quarter',.00025,64)]:
    r=m.request(old_request['bundle_definition'],start_m=-8.95,speed_m_s=20.,voltage_peak_V=2.,frequency_Hz=50.,dt_s=dt,steps=steps,temperature_C=80.,current_limit_A=140.,linear=False,transport_method='supg-coth',mesh_family=c.NAME,critical_dx_m=.005,secondary_dy_m=.0009375)
    differing=[key for key in old_request if old_request[key]!=r[key]]
    assert set(differing)=={'dt_s','steps','request_id'}
    assert dt*steps==.016
    estimate=m.estimate(r)
    assert estimate['nodes']==44643 and estimate['nodes']<=75000
    assert r['maximum_seconds']==85. and r['memory_bytes']==2*1024**3
    requests.append(dict(name=name,request=r,cheap_estimate=estimate,only_request_fields_changed=differing,prior_measured_wall_s=15.1312,linear_work_wall_estimate_s=15.1312*steps/16,estimate_is_runtime_guarantee=False))
points,tri,regions,boundary,branch,sign=m.mesh(requests[0]['request']);mesh=m.mesh_fingerprint(points,tri,regions,boundary,branch,sign)
assert mesh==old_result['actual_mesh']
for name in source:
    dest=base/'source'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,dest)
for name in ('input.json','result.json','manifest.json','worker-result.json','partial-trace.jsonl','stdout.log','stderr.log'):shutil.copyfile(previous/'motoring-fine'/name,base/('prior-fine-'+name))
shutil.copyfile(previous/'plan.json',base/'prior-critical-plan.json')
plan=dict(schema='osr-fine-LIM-timestep-plan/1',frozen_source_git_HEAD=head,source_sha256=source,tool=tool,previous_evaluation_id=old_result['evaluation_id'],previous_request_id=old_request['request_id'],previous_verified=old_verified,prior_source_tools_physical_mesh_equal=True,comparison_variable='dt_s with steps adjusted for fixed16ms endpoint; request_id accordingly',comparison_limitations='Recorded executable/NumPy-core/SuperLU hashes and versions match; no broader archived dynamic-library closure was recorded by the prior campaign',actual_mesh=mesh,requests=requests,maximum_component_jobs=2,maximum_seconds_per_job_external=90,maximum_seconds_per_job_internal=85,maximum_address_space_bytes_per_job=2*1024**3,maximum_nodes=75000,maximum_campaign_seconds=240,no_retries=True,physical_accepted=False,operating_map_admitted=False)
plan['plan_id']=identity(plan);(base/'plan.json').write_bytes(encoded(plan));(base/'tool-snapshot.json').write_bytes(encoded(tool))
print(json.dumps(dict(plan_id=plan['plan_id'],source_head=head,mesh_id=mesh['mesh_discretization_id'],requests=[dict(name=x['name'],request_id=x['request']['request_id'],nodes=x['cheap_estimate']['nodes'],runtime_estimate_s=x['linear_work_wall_estimate_s']) for x in requests],prior_verified=True,source_tools_equal=True),indent=2))
