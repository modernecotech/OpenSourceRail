from pathlib import Path
import json,tarfile,io
from engineering.design_search import moving_lim as m
from engineering.station_rail.common import identity,encoded,digest
base=Path('/tmp/osr-fine-timestep-20261027');root=Path('/tmp/osr-objectives-20261027');plan=json.loads((base/'plan.json').read_bytes());campaign=json.loads((base/'campaign.json').read_bytes());assessment=json.loads((base/'assessment.json').read_bytes())
assert m.sources(root)==m.sources(base/'source')==plan['source_sha256']
assert campaign['attempted_jobs']==campaign['completed_jobs']==2
assert campaign['elapsed_s']<240
for row in campaign['rows']:assert row['elapsed_s']<90 and row['nodes']==44643 and row['elements']==87856
resources=dict(schema='osr-fine-LIM-timestep-resources/1',plan_id=plan['plan_id'],attempted_jobs=2,completed_jobs=2,retries=0,failed_jobs=[],interrupted_jobs=[],pending_authorized_jobs=[],elapsed_campaign_seconds=campaign['elapsed_s'],maximum_campaign_seconds=240,per_job_measured_wall_seconds={row['name']:row['elapsed_s'] for row in campaign['rows']},external_wall_bound_seconds=90,internal_solve_request_seconds=85,enforced_worker_RLIMIT_AS_bytes=2147483648,measured_peak_RAM_bytes=None,nodes_each=44643,node_cap_each=75000,actual_mesh_id=plan['actual_mesh']['mesh_discretization_id'],source_edits=0,source_unchanged=True,field_jobs_in_assessment=0,operating_map_admitted=False,physical_accepted=False)
resources['resource_report_id']=identity(resources);(base/'resources.json').write_bytes(encoded(resources))
summary=dict(schema='osr-fine-LIM-timestep-scope/1',campaign_id=campaign['campaign_id'],assessment_id=assessment['assessment_id'],completed_scope='Two source-bound finite-overlap timestep experiments at same physical state hypotheses and exact16ms endpoint',result='Strong temporal sensitivity remains: half-to-quarter endpointforce19.52%, right-endpoint impulse14.59%; all sampled thrust negative; signed numerical SUPG work changes sign',execution='completed2of2 within resource budget',numerical_validity='Trace/provenance/mesh/time/circuit-closure/discrete-energy checks pass; temporal and whole-domain convergence not established',engineering_screen='No propulsive operating or vehicle/route screen acceptance',evidence_maturity='Conditional computational-method evidence; no measured physical records created',selection_purpose='Rank numerical/evaluator work only',physical_accepted=False,operating_map_admitted=False,complete_installed_mass_kg=None,repeated_cooling_and_thermal_duty_verified=False,receiving_braking_and_converter_protection_sized=False,independent_verification='Separate read-only verifier assigned by coordinator; report may be delivered separately and is not claimed complete by this package',exact_commands='commands.json; prepare.py,run.py,assess.py are retained execution/audit recipes',immutability='Source/input/output bytes inventoried by SHA256 and files set0444 after seal; shared filesystem and permissions are not a claim of OS read-only isolation')
summary['scope_id']=identity(summary);(base/'scope.json').write_bytes(encoded(summary))
entries={str(p.relative_to(base)):dict(sha256=digest(p),bytes=p.stat().st_size) for p in sorted(base.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name!='artifact-index.json'}
index=dict(schema='osr-fine-LIM-timestep-artifact-index/1',plan_id=plan['plan_id'],campaign_id=campaign['campaign_id'],assessment_id=assessment['assessment_id'],files=entries,physical_accepted=False,operating_map_admitted=False)
index['artifact_index_id']=identity(index);(base/'artifact-index.json').write_bytes(encoded(index))
archive=base.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as out:
    for name in sorted([*entries,'artifact-index.json']):
        data=(base/name).read_bytes();info=tarfile.TarInfo(base.name+'/'+name);info.size=len(data);info.mode=0o444;info.mtime=0;out.addfile(info,io.BytesIO(data))
for name in [*entries,'artifact-index.json']:(base/name).chmod(0o444)
archive.chmod(0o444)
print(json.dumps(dict(archive=str(archive),archive_sha256=digest(archive),archive_bytes=archive.stat().st_size,files=len(entries)+1,artifact_index_id=index['artifact_index_id'],resource_report_id=resources['resource_report_id'],scope_id=summary['scope_id']),indent=2))
