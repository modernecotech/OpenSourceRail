from pathlib import Path
import json,math,subprocess
from engineering.design_search import moving_lim as m
from engineering.station_rail.common import identity,encoded,digest
base=Path('/tmp/osr-fine-timestep-20261027');root=Path('/tmp/osr-objectives-20261027');plan=json.loads((base/'plan.json').read_bytes());campaign=json.loads((base/'campaign.json').read_bytes())
assert m.sources(root)==m.sources(base/'source')==plan['source_sha256']
# Authenticate copied reference packet against its unmodified original manifest.
old_manifest=json.loads((base/'prior-fine-manifest.json').read_bytes());old_input=json.loads((base/'prior-fine-input.json').read_bytes());old_result=json.loads((base/'prior-fine-result.json').read_bytes())
assert old_manifest['manifest_id']==identity({k:v for k,v in old_manifest.items() if k!='manifest_id'})
assert old_result['evaluation_id']==old_manifest['evaluation_id']==identity({k:v for k,v in old_result.items() if k!='evaluation_id'})
assert all(digest(base/('prior-fine-'+name))==sha for name,sha in old_manifest['files_sha256'].items())
assert old_result['source_sha256']==old_input['source_sha256']==old_manifest['source_sha256']==plan['source_sha256'];m.validate(old_input['request'])
old_trace=[json.loads(line) for line in (base/'prior-fine-partial-trace.jsonl').read_text().splitlines()]
assert old_trace==old_result['trace']
metrics=[];traces={};cases=[('prior-fine-1ms',old_input['request'],old_result,old_trace)]
for item in plan['requests']:
    name=item['name'];folder=base/name;verification=m.verify(folder,root=base/'source');data=json.loads((folder/'input.json').read_bytes());result=json.loads((folder/'result.json').read_bytes());trace=[json.loads(line) for line in (folder/'partial-trace.jsonl').read_text().splitlines()]
    assert result['trace']==trace and data['request']==item['request'];assert verification['verified'];cases.append((name,data['request'],result,trace))
for name,request,result,trace in cases:
    assert result['actual_mesh']==plan['actual_mesh'];assert request['dt_s']*request['steps']==.016
    assert len(trace)==request['steps'] and trace[-1]['time_s']==.016
    assert result['execution']==result['state']=='completed'
    assert all(result['tool'][k]==plan['tool'][k] for k in ('python','python_sha256','numpy','scipy','superlu_sha256','threads'))
    assert result.get('operating_map_admitted') is False and result.get('physical_accepted') is False
    assert all(trace[i]['time_s']==(i+1)*request['dt_s'] for i in range(len(trace)))
    dt=request['dt_s'];integrals={key:sum(row[key]*dt for row in trace) for key in ('terminal_W','primary_copper_W','secondary_Joule_W','mechanical_W','backward_Euler_dissipation_W','stabilization_work_W')};integrals={k[:-2]+'_J':v for k,v in integrals.items()}
    integrals['force_impulse_right_rectangle_Ns']=sum(row['thrust_N']*dt for row in trace)
    previous=0.;maximum=0.;energy_discrepancy=0.
    for row in trace:
        check=row['terminal_W']-row['primary_copper_W']-row['secondary_Joule_W']-row['mechanical_W']-(row['magnetic_energy_J']-previous)/dt-row['backward_Euler_dissipation_W']-row['stabilization_work_W'];previous=row['magnetic_energy_J'];maximum=max(maximum,abs(check));energy_discrepancy+=check*dt
    assert maximum<1e-8
    metric=dict(name=name,request_id=request['request_id'],evaluation_id=result['evaluation_id'],dt_s=dt,steps=request['steps'],actual_steps=len(trace),actual_final_time_s=trace[-1]['time_s'],source_verified=True,recorded_tool_ids_equal=True,actual_mesh_id=result['actual_mesh']['mesh_discretization_id'],final_force_N=trace[-1]['thrust_N'],minimum_force_N=min(row['thrust_N'] for row in trace),maximum_force_N=max(row['thrust_N'] for row in trace),all_nonzero_samples_negative=all(row['thrust_N']<0 for row in trace),peak_current_A=max(abs(i) for row in trace for i in row['path_currents_A']),final_peak_path_current_A=max(abs(i) for i in trace[-1]['path_currents_A']),final_path_currents_A=trace[-1]['path_currents_A'],final_magnetic_energy_J=trace[-1]['magnetic_energy_J'],integrals=integrals,maximum_independently_recomputed_power_residual_W=maximum,integrated_power_residual_J=energy_discrepancy,maximum_net_secondary_current_A=max(abs(row['net_secondary_current_A']) for row in trace),maximum_net_terminal_current_A=max(abs(row['net_terminal_current_A']) for row in trace),conductor_area_maximum_error_m2=max(abs(row['conductor_area_m2']-.135) for row in trace),physical_accepted=False,operating_map_admitted=False)
    metrics.append(metric);traces[name]=trace
comparisons=[]
for a,b in zip(metrics,metrics[1:]):
    fields={}
    for key in ('final_force_N','peak_current_A','final_peak_path_current_A','final_magnetic_energy_J'):
        fields[key]=dict(A=a[key],B=b[key],absolute_change=b[key]-a[key],relative_change_abs=abs(b[key]-a[key])/max(abs(a[key]),1e-30))
    for key in a['integrals']:
        av=a['integrals'][key];bv=b['integrals'][key];fields[key]=dict(A=av,B=bv,absolute_change=bv-av,relative_change_abs=abs(bv-av)/max(abs(av),1e-30))
    bt={round(row['time_s'],12):row for row in traces[b['name']]};matched=[(row,bt[round(row['time_s'],12)]) for row in traces[a['name']]]
    comparisons.append(dict(A=a['name'],B=b['name'],fields=fields,maximum_common_sample_force_difference_N=max(abs(x['thrust_N']-y['thrust_N']) for x,y in matched),matched_common_time_count=len(matched),temporal_convergence_established=False))
report=dict(schema='osr-fine-LIM-timestep-assessment/1',plan_id=plan['plan_id'],campaign_id=campaign['campaign_id'],source_sha256=plan['source_sha256'],physical_bundle_id=old_input['request']['bundle_id'],motor_component_id=old_input['request']['motor_component_id'],evaluated_component_definition_id=old_input['request']['evaluated_component_definition_id'],actual_mesh_id=plan['actual_mesh']['mesh_discretization_id'],metrics=metrics,comparisons=comparisons,exact_prior_reference_authenticated=True,comparison_variables_only=['dt_s','steps','request_id'],recorded_tool_closure_limit=plan['comparison_limitations'],frozen_source_unchanged=m.sources(root)==plan['source_sha256'],scope=dict(short_startup_seconds=.016,force_sign_diagnosis='Unresolved: all sampled forces negative despite nominal positive slip; no propulsive map interpretation',integration='Right-endpoint sums consistent with actual backward-Euler traces; signed SUPG work is separate from Joule heat',physical_qualification=False,temporal_convergence=False,whole_domain_convergence=False,independent_same_geometry_field_benchmark=False,actual_current_controller=False,repeated_thermal_duty=False,complete_installed_equipment=False),verification_isolation='Read-only assignment on shared filesystem; no OS read-only isolation, no independent second full-field solver',physical_accepted=False,operating_map_admitted=False)
report['assessment_id']=identity(report);(base/'assessment.json').write_bytes(encoded(report))
pending=dict(schema='osr-fine-LIM-timestep-pending/1',assessment_id=report['assessment_id'],approved_remaining_jobs=0,attempted_new_native_jobs=2,retries=0,ranked_next_work=[dict(rank=1,task='Independent sign/phase and matched full-geometry field/circuit checks',reason='Negative startup thrust remains unresolved; scalar/RL controls do not establish full-field truth. Use analytic phase/Lorentz audit then newly budgeted phase-reversal, blocked/full-overlap and warm-start controls.'),dict(rank=2,task='Continue temporal accuracy at fixed fine grid only under new resource budget',reason='The half/quarter endpoint and impulse comparisons quantify remaining sensitivity; three finite dt values alone do not prove an asymptotic limit. Preserve BE and signed SUPG work separately.'),dict(rank=3,task='Outer-field/remote-fin and whole-domain mesh sensitivity',reason='Fine local refinement leaves fixed far-x/steel/outer-air construction rules and coarser remote moving fin; local matching does not establish whole-domain convergence.'),dict(rank=4,task='Measured circuit/controller/thermal/braking qualification workflow',reason='Actual wiring/leakage, material/force correlation, current control, converter/regeneration/protection, repeated losses/cooling and installed equipment quantities remain unverified. No hardware evidence supplied or manufactured by this computation.')],physical_accepted=False,operating_map_admitted=False)
pending['pending_id']=identity(pending);(base/'pending.json').write_bytes(encoded(pending))
commands=dict(schema='osr-fine-LIM-timestep-commands/1',cwd=str(root),source_edits=0,commands=['git status --short','git rev-parse HEAD','sha256sum engineering/design_search/moving_lim.py engineering/design_search/lim_critical_mesh.py','PYTHONPATH=. /home/hayder/Documents/OpenSourceRail/.venv/bin/python /tmp/osr-fine-timestep-20261027/prepare.py','PYTHONPATH=. /home/hayder/Documents/OpenSourceRail/.venv/bin/python /tmp/osr-fine-timestep-20261027/run.py','PYTHONPATH=. /home/hayder/Documents/OpenSourceRail/.venv/bin/python /tmp/osr-fine-timestep-20261027/assess.py'],field_jobs_started=2,no_retries=True,final_git_status=subprocess.check_output(['git','status','--short'],cwd=root,text=True),current_source_git_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip())
(base/'commands.json').write_bytes(encoded(commands))
print(json.dumps(dict(assessment_id=report['assessment_id'],pending_id=pending['pending_id'],metrics=[{k:v for k,v in x.items() if k in ('name','dt_s','steps','actual_final_time_s','final_force_N','peak_current_A','final_peak_path_current_A','final_magnetic_energy_J','integrals','maximum_independently_recomputed_power_residual_W')} for x in metrics],comparisons=comparisons),indent=2))
