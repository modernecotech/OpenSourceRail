from pathlib import Path
from time import monotonic
import json,subprocess
from engineering.design_search import moving_lim as m
from engineering.station_rail.common import identity,encoded
root=Path('/tmp/osr-objectives-20261027');base=Path('/tmp/osr-fine-timestep-20261027');plan=json.loads((base/'plan.json').read_bytes());rows=[];started=monotonic()
for item in plan['requests']:
    if m.sources(root)!=plan['source_sha256']:
        rows.append(dict(name=item['name'],execution='pending-source-change',reason='Frozen source map differs before attempt',request_id=item['request']['request_id']));continue
    if monotonic()-started+90>plan['maximum_campaign_seconds']:
        rows.append(dict(name=item['name'],execution='pending-total-budget',reason='Insufficient complete external90s job budget remains',request_id=item['request']['request_id']));continue
    t=monotonic()
    try:
        result=m.run(item['request'],base/item['name'],root=root);verification=m.verify(base/item['name'],root=root)
        row=dict(name=item['name'],execution=result['execution'],state=result.get('state'),reason=result.get('reason'),request_id=item['request']['request_id'],evaluation_id=result['evaluation_id'],elapsed_s=monotonic()-t,verification=verification,trace_rows=len(result.get('trace',[])))
        if result.get('trace'):
            row.update(actual_final_time_s=result['trace'][-1]['time_s'],actual_final=result['trace'][-1],nodes=result['nodes'],elements=result['elements'],actual_mesh=result['actual_mesh'],peak_current_A=max(abs(i) for p in result['trace'] for i in p['path_currents_A']),peak_steel_T=max(p['peak_steel_B_T'] for p in result['trace']),maximum_discrete_power_residual_W=max(abs(p['discrete_power_residual_W']) for p in result['trace']))
    except Exception as error:
        row=dict(name=item['name'],execution='orchestration-error',reason=type(error).__name__+': '+str(error),elapsed_s=monotonic()-t,request_id=item['request']['request_id'],unsealed_partial_outputs_retained=True)
    rows.append(row)
    print(json.dumps({k:v for k,v in row.items() if k not in ('verification','actual_final','actual_mesh')}),flush=True)
report=dict(schema='osr-fine-LIM-timestep-campaign/1',plan_id=plan['plan_id'],frozen_source_git_HEAD=plan['frozen_source_git_HEAD'],actual_end_git_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),source_sha256=plan['source_sha256'],tool=plan['tool'],rows=rows,attempted_jobs=sum(not p['execution'].startswith('pending-') for p in rows),completed_jobs=sum(p['execution']=='completed' and p.get('state')=='completed' for p in rows),elapsed_s=monotonic()-started,source_unchanged=m.sources(root)==plan['source_sha256'],physical_accepted=False,operating_map_admitted=False)
report['campaign_id']=identity(report);(base/'campaign.json').write_bytes(encoded(report));print('CAMPAIGN '+report['campaign_id'],flush=True)
