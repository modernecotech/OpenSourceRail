from pathlib import Path
from time import monotonic
import json,shutil,subprocess,sys
import numpy as np, scipy
import numpy._core._multiarray_umath as numpycore
import scipy.sparse.linalg._dsolve._superlu as superlu
from engineering.design_search import moving_lim as m,lim_transport,railway_bundle,design_grammar
from engineering.station_rail.common import identity,digest,encoded
root=Path('/tmp/osr-objectives-20261027');base=Path('/tmp/osr-lim-continuation-20261027');epoch=m.sources(root)
tests=['engineering/design_search/tests/test_lim_transport.py','engineering/design_search/tests/test_moving_lim.py','engineering/design_search/tests/test_transient_lim.py']
for name in (*epoch,*tests):
 p=base/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,p)
tool=dict(python=sys.version,python_path=sys.executable,python_sha256=digest(sys.executable),numpy=np.__version__,numpy_core_sha256=digest(numpycore.__file__),scipy=scipy.__version__,superlu_sha256=digest(superlu.__file__),threads=1)
(base/'tool-snapshot.json').write_bytes(encoded(tool))
b=railway_bundle.materialize(design_grammar.initial_candidates()[0]);specs=[('low-dt-1ms',dict(dt_s=.001,steps=16)),('low-dt-half',dict(dt_s=.0005,steps=32)),('low-mesh-30mm',dict(dt_s=.0005,steps=32,mesh_m=.03)),('low-mesh-25mm',dict(dt_s=.0005,steps=32,mesh_m=.025)),('high-supg-dt-2ms',dict(speed_m_s=20.,transport_method='supg-coth',dt_s=.002,steps=8)),('high-supg-dt-1ms',dict(speed_m_s=20.,transport_method='supg-coth',dt_s=.001,steps=16))]
requests=[dict(name=name,request=m.request(b,**args)) for name,args in specs]
plan=dict(schema='osr-LIM-continuation-plan/1',source_base_revision='e108894d246ffdc907acbf7436353c99926d945e',source_sha256=epoch,test_source_sha256={n:digest(root/n) for n in tests},tool=tool,requests=requests,cheap_estimates={item['name']:m.estimate(item['request']) for item in requests},maximum_component_jobs=6,maximum_total_seconds=600,maximum_seconds_per_job=90,maximum_address_space_bytes=2*1024**3,approved_node_cap=75000,physical_accepted=False)
plan['plan_id']=identity(plan);(base/'plan.json').write_bytes(encoded(plan))
started=monotonic();rows=[]
for item in requests:
 if m.sources(root)!=epoch:raise ValueError('Source changed during frozen campaign')
 if monotonic()-started>500:
  rows.append(dict(name=item['name'],execution='pending-total-budget',request_id=item['request']['request_id']));continue
 t=monotonic();result=m.run(item['request'],base/item['name'],root=root);verification=m.verify(base/item['name'],root=root)
 row=dict(name=item['name'],execution=result['execution'],state=result.get('state'),reason=result.get('reason'),evaluation_id=result['evaluation_id'],request_id=item['request']['request_id'],elapsed_s=monotonic()-t,verification=verification,trace_rows=len(result.get('trace',[])))
 if result.get('trace'):
  trace=result['trace'];row.update(nodes=result['nodes'],elements=result['elements'],Peclet_max=result['Peclet_max'],final=trace[-1],max_power_residual_W=max(abs(x['discrete_power_residual_W']) for x in trace),stabilization_work_J=sum(x['stabilization_work_W']*item['request']['dt_s'] for x in trace),min_stabilization_W=min(x['stabilization_work_W'] for x in trace),max_stabilization_W=max(x['stabilization_work_W'] for x in trace),max_current_A=max(abs(v) for x in trace for v in x['path_currents_A']))
 rows.append(row);(base/'progress.json').write_bytes(encoded(dict(plan_id=plan['plan_id'],rows=rows,physical_accepted=False)));print(json.dumps({k:v for k,v in row.items() if k not in ('verification','final')}),flush=True)
report=dict(schema='osr-LIM-continuation-results/1',plan_id=plan['plan_id'],source_sha256=epoch,tool=tool,rows=rows,elapsed_s=monotonic()-started,source_unchanged=m.sources(root)==epoch,physical_accepted=False,operating_map_admitted=False)
report['campaign_id']=identity(report);(base/'campaign.json').write_bytes(encoded(report));print('CAMPAIGN '+report['campaign_id'],flush=True)
