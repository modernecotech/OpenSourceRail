from pathlib import Path
from time import monotonic
import json,shutil,sys
import numpy as np,scipy
import numpy._core._multiarray_umath as numpycore
import scipy.sparse.linalg._dsolve._superlu as superlu
from engineering.design_search import moving_lim as m
from engineering.station_rail.common import encoded,identity,digest
root=Path('/tmp/osr-objectives-20261027');base=Path('/tmp/osr-lim-continuation-20261027');old=json.loads((base/'plan.json').read_bytes());correction=json.loads((base/'source-base-correction.json').read_bytes());baseline=json.loads((base/'high-supg-dt-1ms/input.json').read_bytes())['request'];b=baseline['bundle_definition'];epoch=m.sources(root)
snapshot=base/'source-epoch4';snapshot.mkdir(exist_ok=False)
tests=['engineering/design_search/tests/test_lim_transport.py','engineering/design_search/tests/test_moving_lim.py','engineering/design_search/tests/test_transient_lim.py']
for name in (*epoch,*tests):
 p=snapshot/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,p)
tool=dict(python=sys.version,python_path=sys.executable,python_sha256=digest(sys.executable),numpy=np.__version__,numpy_core_sha256=digest(numpycore.__file__),scipy=scipy.__version__,superlu_sha256=digest(superlu.__file__),threads=1)
requests=[dict(name=name,request=m.request(b,speed_m_s=20.,transport_method='supg-coth',dt_s=.001,steps=16,mesh_m=mesh)) for name,mesh in [('high-supg-mesh-30mm',.03),('high-supg-mesh-25mm',.025)]]
plan=dict(schema='osr-LIM-supplemental-plan/1',parent_plan_id=old['plan_id'],source_base_revision=correction['correct_value'],source_base_correction=correction,source_sha256=epoch,test_source_sha256={n:digest(root/n) for n in tests},source_epoch='source-epoch4',source_change_from_parent='Necessary Nyquist sampling guard only; field/circuit/transport equations unchanged',tool=tool,requests=requests,cheap_estimates={item['name']:m.estimate(item['request']) for item in requests},maximum_component_jobs=2,maximum_total_seconds=180,maximum_seconds_per_job=90,maximum_address_space_bytes=2*1024**3,approved_node_cap=75000,comparison_baseline='high-supg-dt-1ms',physical_accepted=False)
plan['plan_id']=identity(plan);(base/'supplemental-plan.json').write_bytes(encoded(plan));(base/'supplemental-tool-snapshot.json').write_bytes(encoded(tool))
rows=[];start=monotonic()
for item in requests:
 if m.sources(root)!=epoch:raise ValueError('Supplemental frozen source changed')
 t=monotonic();result=m.run(item['request'],base/item['name'],root=root);verification=m.verify(base/item['name'],root=root)
 row=dict(name=item['name'],execution=result['execution'],state=result.get('state'),reason=result.get('reason'),evaluation_id=result['evaluation_id'],request_id=item['request']['request_id'],elapsed_s=monotonic()-t,verification=verification,trace_rows=len(result.get('trace',[])))
 if result.get('trace'):
  trace=result['trace'];row.update(nodes=result['nodes'],elements=result['elements'],Peclet_max=result['Peclet_max'],final=trace[-1],max_power_residual_W=max(abs(x['discrete_power_residual_W']) for x in trace),signed_stabilization_J=sum(x['stabilization_work_W']*item['request']['dt_s'] for x in trace),max_current_A=max(abs(v) for x in trace for v in x['path_currents_A']))
 rows.append(row);print(json.dumps({k:v for k,v in row.items() if k not in ('verification','final')}),flush=True)
report=dict(schema='osr-LIM-supplemental-results/1',plan_id=plan['plan_id'],parent_plan_id=old['plan_id'],source_sha256=epoch,tool=tool,rows=rows,elapsed_s=monotonic()-start,source_unchanged=m.sources(root)==epoch,physical_accepted=False,operating_map_admitted=False)
report['campaign_id']=identity(report);(base/'supplemental-campaign.json').write_bytes(encoded(report));print('SUPPLEMENTAL '+report['campaign_id'],flush=True)
