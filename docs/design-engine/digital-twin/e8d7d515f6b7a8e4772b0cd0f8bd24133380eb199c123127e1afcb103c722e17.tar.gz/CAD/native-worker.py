
import FreeCAD as A,Part,Import,json,pathlib,math
def metric(shape):
    b=shape.BoundBox;solids=shape.Solids;volume=sum(s.Volume for s in solids)
    if not volume:raise ValueError('Native material solid required')
    c=A.Vector()
    for solid in solids:c=c+solid.CenterOfMass*(solid.Volume/volume)
    return dict(volume_m3=volume/1e9,centroid_m=[c.x/1000,c.y/1000,c.z/1000],bounds_min_m=[b.XMin/1000,b.YMin/1000,b.ZMin/1000],bounds_max_m=[b.XMax/1000,b.YMax/1000,b.ZMax/1000])
def reopen(folder,data):
    doc=A.openDocument(str(folder/'railway-twin.FCStd'));rows=[]
    for obj in doc.Objects:
        if not hasattr(obj,'Shape'):continue
        if obj.CandidateID!=data['candidate_id'] or not obj.Shape.isValid():raise ValueError('Invalid native occurrence/candidate')
        rows.append(dict(id=obj.OccurrenceID,component_definition_id=obj.ComponentDefinitionID,geometry_id=obj.GeometryID,**metric(obj.Shape)))
    A.closeDocument(doc.Name);step=Part.Shape();step.read(str(folder/'railway-twin.step'))
    if not step.isValid():raise ValueError('Invalid reopened STEP')
    return dict(candidate_id=data['candidate_id'],FCStd_occurrences=rows,STEP_solids=[metric(s) for s in step.Solids],FreeCAD_version=list(A.Version()))

from hashlib import sha256
def ident(v):return sha256((json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()).hexdigest()
out=pathlib.Path(__file__).parent;data=json.loads((out/'native-input.json').read_text());doc=A.newDocument('OSR_Railway_Research_Twin');objects=[];cache={}
for index,row in enumerate(data['occurrences']):
    p=row['geometry'];key=ident(p)
    if key not in cache:
        if p['kind'] in ('box','box-with-rectangular-cutouts'):
            shape=Part.makeBox(*[v*1000 for v in p['size_m']],A.Vector(*[v*1000 for v in p['at_m']]))
            for hole in p.get('holes',[]):
                axis='xyz'.index(hole.get('axis','z'));start=list(p['at_m']);direction=[0.,0.,0.];direction[axis]=1.
                for j in range(3):start[j]+=hole.get('start_m',0.) if j==axis else hole.get('xyz'[j]+'_m',0.)
                shape=shape.cut(Part.makeCylinder(hole['diameter_m']*500,hole.get('length_m',p['size_m'][axis])*1000,A.Vector(*[v*1000 for v in start]),A.Vector(*direction)))
            for cut in p.get('rectangular_cutouts',[]):shape=shape.cut(Part.makeBox(*[v*1000 for v in cut['size_m']],A.Vector(*[v*1000 for v in cut['at_m']])))
        elif p['kind']=='oriented-RHS':
            a=A.Vector(*p['start_m']);b=A.Vector(*p['end_m']);w=b-a;L=w.Length;w.normalize();u=A.Vector(0,0,1).cross(w)
            if u.Length<1e-10:u=A.Vector(1,0,0)
            u.normalize();v=w.cross(u);m=A.Matrix()
            for r in range(3):
                for c,basis in enumerate((u,v,w)):setattr(m,'A'+str(r+1)+str(c+1),getattr(basis,'xyz'[r]))
            width,height,wall=[p[k]*1000 for k in ('width_m','height_m','wall_m')]
            shape=Part.makeBox(width,height,L*1000,A.Vector(-width/2,-height/2,0)).cut(Part.makeBox(width-2*wall,height-2*wall,L*1000,A.Vector(-width/2+wall,-height/2+wall,0)))
            shape.transformShape(m);shape.translate(a*1000)
        else:
            at=A.Vector(*[v*1000 for v in p['at_m']]);axis=A.Vector(*p['axis']);shape=Part.makeCylinder(p['radius_m']*1000,p['length_m']*1000,at,axis)
            if p.get('inner_radius_m',0):shape=shape.cut(Part.makeCylinder(p['inner_radius_m']*1000,p['length_m']*1000,at,axis))
        if not shape.isValid():raise ValueError('Invalid native primitive')
        cache[key]=shape
    shape=cache[key].copy();shape.translate(A.Vector(*[v*1000 for v in row['translation_m']]))
    obj=doc.addObject('PartDesign::Feature','Occurrence_'+str(index));obj.Label=row['id'];obj.Shape=shape
    for name,value in [('CandidateID',data['candidate_id']),('OccurrenceID',row['id']),('ComponentDefinitionID',row['component_definition_id']),('GeometryID',key)]:obj.addProperty('App::PropertyString',name);setattr(obj,name,value)
    objects.append(obj)
doc.recompute();doc.saveAs(str(out/'railway-twin.FCStd'))
# Import.export can apply the user's single-object origin-reset preference.
# Export an explicit world-space compound through the native Part writer so
# every retained solid keeps its actual placement, independent of GUI settings.
Part.makeCompound([obj.Shape for obj in objects]).exportStep(str(out/'railway-twin.step'))
A.closeDocument(doc.Name)
(out/'native-result.json').write_text(json.dumps(reopen(out,data),sort_keys=True)+'\n')
