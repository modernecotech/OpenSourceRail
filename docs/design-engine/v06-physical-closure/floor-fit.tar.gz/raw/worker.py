
import FreeCAD as A,Part,Import,json,pathlib
folder=pathlib.Path(__file__).parent;data=json.loads((folder/'definition.json').read_text());parts=data['physical_definition']['geometry_parts']
doc=A.newDocument('OSR_floor_ports');objects=[];mass=0.;volume=0.;errors=[];shapes=[]
for i,p in enumerate(parts):
    sh=Part.makeBox(*[s*1000 for s in p['size_m']],A.Vector(*[s*1000 for s in p['at_m']]))
    for hole in p.get('holes',[]):
        start=list(p['at_m']);start[0]+=hole.get('x_m',0.);start[1]+=hole.get('y_m',0.)
        sh=sh.cut(Part.makeCylinder(hole['diameter_m']*500,p['size_m'][2]*1000,A.Vector(*[s*1000 for s in start]),A.Vector(0,0,1)))
    for cut in p.get('rectangular_cutouts',[]):
        sh=sh.cut(Part.makeBox(*[s*1000 for s in cut['size_m']],A.Vector(*[s*1000 for s in cut['at_m']])))
    vm=sh.Volume/1e9
    if not sh.isValid() or abs(vm-p['volume_m3'])>max(1e-11,p['volume_m3']*1e-7):errors.append(p['id'])
    mass+=vm*p['density_kg_m3'];volume+=vm;shapes.append(sh)
    obj=doc.addObject('PartDesign::Feature','Part_'+str(i));obj.Label=p['id'];obj.Shape=sh;objects.append(obj)
clashes=[]
for i,a in enumerate(shapes):
    for j,b in enumerate(shapes[i+1:],i+1):
        if 'source_part_id' in parts[i] and 'source_part_id' in parts[j]:continue
        if min(min(parts[i]['at_m'][k]+parts[i]['size_m'][k],parts[j]['at_m'][k]+parts[j]['size_m'][k])-max(parts[i]['at_m'][k],parts[j]['at_m'][k]) for k in range(3))<=1e-10:continue
        overlap=a.common(b).Volume/1e9
        if overlap>1e-11:clashes.append({'a':parts[i]['id'],'b':parts[j]['id'],'overlap_volume_m3':overlap})
doc.recompute();doc.saveAs(str(folder/'floor-fit.FCStd'));Import.export(objects,str(folder/'floor-fit.step'));A.closeDocument(doc.Name)
doc=A.openDocument(str(folder/'floor-fit.FCStd'));reopened=sum(o.Shape.Volume for o in doc.Objects if hasattr(o,'Shape'))/1e9
step=Part.Shape();step.read(str(folder/'floor-fit.step'));stepvol=step.Volume/1e9
(folder/'native-result.json').write_text(json.dumps(dict(part_count=len(parts),native_mass_kg=mass,native_volume_m3=volume,
volume_error_ids=errors,positive_volume_clashes=clashes,reopened_volume_m3=reopened,step_volume_m3=stepvol,FreeCAD_version=list(A.Version())),sort_keys=True,indent=2)+'\n')
A.closeDocument(doc.Name)
