"""Authenticate compact evidence; no solvers or external files are executed."""
import hashlib,json,math
from pathlib import Path
P=Path(__file__).resolve().parent

def load(n):return json.loads((P/n).read_bytes())
def identity(v):return hashlib.sha256((json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()).hexdigest()
def sealed(v,key='evaluation_id'):
    assert v[key]==identity({k:x for k,x in v.items() if k!=key}), 'Seal differs: '+key
    return v

manifest=sealed(load('compact-members.json'))
for n,spec in manifest['members'].items():
    f=P/n
    assert f.is_file() and f.stat().st_size==spec['bytes'], 'Size/file differs: '+n
    assert hashlib.sha256(f.read_bytes()).hexdigest()==spec['sha256'], 'SHA differs: '+n
train=sealed(load('axle-input.json'));civil=sealed(load('civil.json'));spec=sealed(load('native-input.json'),'input_id');report=sealed(load('report.json'))
assert report['system_candidate_id']==train['candidate_id']==spec['system_candidate_id']==civil['system_candidate_id']
assert report['civil_candidate_id']==civil['civil_candidate_id']==spec['candidate_id']==identity(civil['physical_definition'])
assert report['civil_evaluation_id']==civil['evaluation_id']
assert report['input_load_evaluation_id']==train['evaluation_id']==spec['input_load_evaluation_id']==civil['input_load_evaluation_id']
assert report['native_input_id']==spec['input_id']
assert report['source_unchanged'] and report['upstream_source_unchanged']
interface=train['track_interface']
assert interface==civil['physical_definition']['rail_interface']['track_interface']==spec['track_interface']
assert interface['inner_face_gauge_m']==1.435 and interface['nominal_rail_head_width_m']==.07
assert interface['nominal_contact_centres_y_m']==[-.7525,.7525]
assert spec['rail_patch_hypothesis']['centres_y_m']==interface['nominal_contact_centres_y_m']
for kind,mapping in [('numerical',load('source-before.json')),('upstream',train['source_sha256'])]:
    for n,want in mapping.items():assert hashlib.sha256((P/'source'/kind/n).read_bytes()).hexdigest()==want, 'Source differs: '+n
for case in train['load_cases']:
    total=math.fsum(a['vertical_force_N'] for a in case['axles'])
    assert abs(total-case['train_mass_kg']*9.80665)<1e-7*total
step=P/'gross-beam-cad/execution/assembly.step'
assert hashlib.sha256(step.read_bytes()).hexdigest()==spec['cad_artifact']['step_sha256']
assert abs(load('independent-cad-summary.json')['total_volume_m3']-civil['quantities']['concrete_beam_m3'])<1e-6
results=[]
for i in (1,2,3):
    root='case-'+str(i)+'/';r=sealed(load(root+'result.json'));m=sealed(load(root+'mesh.json'),'mesh_id')
    assert r['candidate_id']==civil['civil_candidate_id'] and r['input_id']==spec['input_id']
    assert r['mesh_id']==m['mesh_id'] and len(m['elements'])<=50000
    assert r['cross_solver_screen_passed'] and r['cross_solver_relative_difference']<=.02
    assert r['support_audit']['rotation_free_line_definition_resolved']
    for row in r['support_audit']['rows']:
        assert row['node_x_range_m']==[row['axis_x_m'],row['axis_x_m']]
        assert abs(row['vertical_reaction_bending_couple_Nm'])<1e-6
    for tool in ('fieldcraft','calculix'):
        v=r[tool]
        assert v['force_equilibrium_passed'] and v['moment_equilibrium_passed']
        assert v['physical_accepted'] is False and v['engineering_accepted'] is False
    F=math.fsum(v[2] for v in m['nodal_load_N'].values())
    assert abs(F-m['applied_N'][2])<1e-8*abs(F)
    # Independent second-moment audit detects a symmetric wrong rail spacing
    # which total force and first lateral moment alone cannot detect.
    patch=spec['rail_patch_hypothesis'];centres=patch['centres_y_m']
    live=math.fsum(a['force_N'] for a in spec['live_pose']['points'])
    live_m2=-live*(math.fsum(y*y for y in centres)/2+patch['width_m']**2/12)
    line=spec['line_equipment_gravity'];line_m2=-line['mass_kg']*9.80665*(line['lateral_y_m']**2+line['spread_width_m']**2/12)
    calls=[json.loads(row) for row in (P/root/'fieldcraft/stdin.jsonl').read_text().splitlines()]
    cmds=[c for call in calls if call.get('method')=='tools/call' for c in call['params']['arguments'].get('commands',[])]
    forces={int(c['params']['name'][9:]):c['params']['vector'][2] for c in cmds if c['command']=='model.load.create' and c['params']['name'].startswith('PilotLoad')}
    actual_m2=math.fsum(m['nodes'][str(n)][1]**2*f for n,f in forces.items())
    assert abs(actual_m2-live_m2-line_m2)<1e-7*abs(live_m2+line_m2), 'FieldCraft actual lateral load second moment differs'
    body_m2=0.
    for e in m['elements'].values():
        points=[m['nodes'][str(n)] for n in e[:4]];a=points[0]
        b,c,d=[[v[j]-a[j] for j in range(3)] for v in points[1:]]
        volume=abs(b[0]*(c[1]*d[2]-c[2]*d[1])-b[1]*(c[0]*d[2]-c[2]*d[0])+b[2]*(c[0]*d[1]-c[1]*d[0]))/6
        ys=[v[1] for v in points]
        body_m2-=2500*9.80665*volume*(sum(ys)**2+sum(y*y for y in ys))/20
    reserve_m2=-(spec['superimposed_mass_kg']-line['mass_kg'])*9.80665/3
    actual_total=math.fsum(m['nodes'][str(n)][1]**2*v[2] for n,v in m['nodal_load_N'].items())
    assert abs(actual_total-(body_m2+reserve_m2+line_m2+live_m2))<1e-7*abs(actual_total), 'CalculiX assembled lateral load second moment differs'
    line=spec['line_equipment_gravity'];expected=-line['mass_kg']*9.80665*line['lateral_y_m']
    assert abs(m['applied_moment_Nm'][0]-expected)<1e-6*abs(expected), 'Conductor eccentric moment differs'
    for tool in ('mesh-native','fieldcraft','calculix'):
        usage=load(root+tool+'/usage.json')
        assert usage['exit']==0 and usage['peak_rss_kib']<=3072*1024
        if 'user_s' in usage:assert usage['user_s']+usage['system_s']<=75
    results.append(r)
for a,b in zip(results,results[1:]):
    u=a['fieldcraft']['displacement_m'][2];v=b['fieldcraft']['displacement_m'][2]
    assert abs(u-v)/abs(v)<=.05
assert report['refinement_screen_passed'] and report['physical_accepted'] is False
print(json.dumps(dict(status='verified',files=len(manifest['members']),system_candidate_id=train['candidate_id'],civil_candidate_id=civil['civil_candidate_id'],report_id=report['evaluation_id'],numerical_refinement_screen_passed=True,physical_accepted=False)))
