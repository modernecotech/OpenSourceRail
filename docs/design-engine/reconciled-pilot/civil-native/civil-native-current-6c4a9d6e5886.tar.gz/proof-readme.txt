OpenSourceRail source-bound final-load civil comparison

Run `python verify.py` after extracting this archive into a fresh directory. The verifier checks member hashes, candidate and load identities, source snapshots, CAD volume, solver equilibrium, support-line reactions, resource records and mesh refinement.

This is a gross elastic numerical comparison for one normal-base load pose. It does not qualify bearing contact or compliance, joints, reinforcement, prestress, cracking, fatigue, soil, construction, or physical acceptance. All release and acceptance flags remain false.

Replaceable rolling checkpoints, intermediate mesh exports, bytecode and duplicate STEP copies are listed with hashes in omissions.json. The full private-run manifest is retained.
