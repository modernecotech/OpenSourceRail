
import gmsh,json,sys,math
from pathlib import Path
request=json.loads(Path(sys.argv[1]).read_text());gmsh.initialize();gmsh.option.setNumber('General.NumThreads',1)
gmsh.option.setNumber('General.Terminal',1);gmsh.option.setString('Geometry.OCCTargetUnit','M')
v=gmsh.model.occ.importShapes(request['step']);gmsh.model.occ.synchronize()
original=sum(gmsh.model.occ.getMass(3,t) for d,t in v if d==3)
# Fragment exact imported CAD into one conformal, perfectly bonded continuum.
vol=[v for v in gmsh.model.getEntities(3)]
if len(vol)>1:gmsh.model.occ.fragment(vol[:1],vol[1:]);gmsh.model.occ.synchronize()
volume=sum(gmsh.model.occ.getMass(3,t) for d,t in gmsh.model.getEntities(3))
if abs(volume-request['volume'])>1e-6*request['volume']:raise ValueError('STEP volume differs from canonical SI stock')
# An explicit observation point lies on the actual deck face, not an invented CAD solid.
pt=gmsh.model.occ.addPoint(10.,0.,0.);gmsh.model.occ.synchronize()
top=[t for d,t in gmsh.model.getEntities(2) if abs(gmsh.model.occ.getCenterOfMass(d,t)[2])<1e-8]
inside=[t for t in top if gmsh.model.isInside(2,t,[10.,0.,0.])]
if len(inside)!=1:raise ValueError('Unique canonical top-deck observation surface required')
gmsh.model.mesh.embed(0,[pt],2,inside[0])

# Embed transverse support lines into the exact imported bottom surface. A
# longitudinal band of fixed U3 would introduce an unintended bending couple.
depth=min(gmsh.model.getBoundingBox(3,t)[2] for d,t in gmsh.model.getEntities(3))
# OCC bounding boxes carry geometric tolerance; obtain the exact planar bottom.
bottom=[t for d,t in gmsh.model.getEntities(2) if abs(gmsh.model.occ.getCenterOfMass(d,t)[2]-request['bottom_z_m'])<1e-8]
for x in request['bearing_lines_x_m']:
 for lo,hi in request['bearing_intervals_y_m']:
  candidates=[t for t in bottom if gmsh.model.isInside(2,t,[x,(lo+hi)/2,request['bottom_z_m']])]
  if len(candidates)!=1:raise ValueError('Unique exact bottom bearing surface required')
  a=gmsh.model.occ.addPoint(x,lo,request['bottom_z_m']);b=gmsh.model.occ.addPoint(x,hi,request['bottom_z_m'])
  edge=gmsh.model.occ.addLine(a,b);gmsh.model.occ.synchronize();gmsh.model.mesh.embed(1,[edge],2,candidates[0])

gmsh.option.setNumber('Mesh.MeshSizeMin',request['size']);gmsh.option.setNumber('Mesh.MeshSizeMax',request['size'])
gmsh.option.setNumber('Mesh.Algorithm',6);gmsh.option.setNumber('Mesh.Algorithm3D',1);gmsh.model.mesh.generate(3)
gmsh.option.setNumber('Mesh.SecondOrderLinear',1);gmsh.model.mesh.setOrder(2)
# Straight-sided planar prisms need no curved midside projection.
nt,coords,_=gmsh.model.mesh.getNodes();nodes={str(int(n)):list(map(float,coords[3*i:3*i+3])) for i,n in enumerate(nt)}
types,tags,conn=gmsh.model.mesh.getElements(3);elements={}
for typ,ids,links in zip(types,tags,conn):
 if int(typ)!=11:raise ValueError('Only actual quadratic tetrahedra admitted')
 for i,n in enumerate(ids):elements[str(int(n))]=[int(links[10*i+j]) for j in (0,1,2,3,4,5,6,7,9,8)]
if len(elements)>50000:raise ValueError('Cell budget exceeded; execution retained')
faces=[]
for surf in top:
 types,tags,conn=gmsh.model.mesh.getElements(2,surf)
 for typ,ids,links in zip(types,tags,conn):
  if int(typ)!=9:raise ValueError('Quadratic deck triangles required')
  faces += [list(map(int,links[6*i:6*i+6])) for i in range(len(ids))]
ids=list(map(int,elements));qualities=list(map(float,gmsh.model.mesh.getElementQualities(ids,'minSJ')))
if not qualities or min(qualities)<=0:raise ValueError('Nonpositive Jacobian quality')
Path(request['output']).write_text(json.dumps(dict(nodes=nodes,elements=elements,top_faces=faces,element_type='tet10',gmsh_version=gmsh.__version__,
 original_imported_volume_m3=original,fused_volume_m3=volume,min_scaled_jacobian=min(qualities),geometry_route='Gmsh/OpenCASCADE exact SolidCraft STEP import, fragments touching stock, quadratic tetrahedra; perfect bond hypothesis'))+'\n')
gmsh.write(request['msh']);gmsh.finalize()
