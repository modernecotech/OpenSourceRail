# Fixed-service station recovery economics

Calculated research comparison; powered-bogie packaging and physical force/duty evidence remain held. No installed selection or passenger-operation approval.

Study `a8688d6410c562ba9a37bf9c4846a013eb2aea468b68e7c2d68ff30e8e9f54c0`; source `37788e925010b9b53636809553271d68482bb6de`.
Exact body `c89556f453e39448a8f3e9bf2d0d4d008f97cd20d252ac417284e40965e261b3`; 11 physical variants / 32 evaluations.

All cases retain 276 normal places, 85% planning occupancy, 4,000 pphpd demand, 200 s headway, 90 s opposing phase, 3 active + 1 spare trains, 35 s dwell, 45 s turnback and counted full-tail terminal geometry. Nominal grade is zero. All stores start empty. Hardware windows, five capture stages, force/power ceilings, grid equipment, independent brakes, service batteries and charging provision remain counted.

| Case | Arrivals | Model screen | Grid traction kWh / 16 | Annual grid MWh | Base capital $m | 30-year NPV $m |
|---|---:|---|---:|---:|---:|---:|
| no-store | 16/16 | pass | 122.26189 | 6939.31 | 37.6940 | 71.3069 |
| steel-0.25MJ-share0.2 | 16/16 | pass | 122.48007 | 6990.26 | 38.9663 | 73.5538 |
| steel-0.25MJ-share0.5 | 16/16 | pass | 122.48007 | 6990.26 | 38.9663 | 73.5538 |
| steel-0.25MJ-share0.8 | 16/16 | pass | 122.48007 | 6990.26 | 38.9663 | 73.5538 |
| steel-0.5MJ-share0.2 | 16/16 | pass | 122.41063 | 6989.37 | 38.9954 | 73.6037 |
| steel-0.5MJ-share0.5 | 16/16 | pass | 122.41063 | 6989.37 | 38.9954 | 73.6037 |
| steel-0.5MJ-share0.8 | 16/16 | pass | 122.41063 | 6989.37 | 38.9954 | 73.6037 |
| steel-1MJ-share0.2 | 16/16 | pass | 122.27176 | 6987.59 | 39.0536 | 73.7035 |
| steel-1MJ-share0.5 | 16/16 | pass | 122.27176 | 6987.59 | 39.0536 | 73.7035 |
| steel-1MJ-share0.8 | 16/16 | pass | 122.27176 | 6987.59 | 39.0536 | 73.7035 |
| steel-2MJ-share0.2 | 16/16 | pass | 121.99402 | 6984.04 | 39.1700 | 73.9032 |
| steel-2MJ-share0.5 | 16/16 | pass | 121.99402 | 6984.04 | 39.1700 | 73.9032 |
| steel-2MJ-share0.8 | 16/16 | pass | 121.99402 | 6984.04 | 39.1700 | 73.9032 |
| steel-4MJ-share0.2 | 16/16 | pass | 121.51428 | 6977.98 | 39.4028 | 74.3044 |
| steel-4MJ-share0.5 | 16/16 | pass | 121.51428 | 6977.98 | 39.4028 | 74.3044 |
| steel-4MJ-share0.8 | 16/16 | pass | 121.51428 | 6977.98 | 39.4028 | 74.3044 |
| hydraulic-0.25MJ-share0.2 | 16/16 | pass | 122.48399 | 6990.42 | 39.2398 | 74.0084 |
| hydraulic-0.25MJ-share0.5 | 16/16 | pass | 122.48399 | 6990.42 | 39.2398 | 74.0084 |
| hydraulic-0.25MJ-share0.8 | 16/16 | pass | 122.48399 | 6990.42 | 39.2398 | 74.0084 |
| hydraulic-0.5MJ-share0.2 | 16/16 | pass | 122.41848 | 6989.69 | 39.2424 | 74.0118 |
| hydraulic-0.5MJ-share0.5 | 16/16 | pass | 122.41848 | 6989.69 | 39.2424 | 74.0118 |
| hydraulic-0.5MJ-share0.8 | 16/16 | pass | 122.41848 | 6989.69 | 39.2424 | 74.0118 |
| hydraulic-1MJ-share0.2 | 16/16 | pass | 122.28746 | 6988.24 | 39.2477 | 74.0186 |
| hydraulic-1MJ-share0.5 | 16/16 | pass | 122.28746 | 6988.24 | 39.2477 | 74.0186 |
| hydraulic-1MJ-share0.8 | 16/16 | pass | 122.28746 | 6988.24 | 39.2477 | 74.0186 |
| hydraulic-2MJ-share0.2 | 16/16 | pass | 122.02543 | 6985.34 | 39.2582 | 74.0322 |
| hydraulic-2MJ-share0.5 | 16/16 | pass | 122.02543 | 6985.34 | 39.2582 | 74.0322 |
| hydraulic-2MJ-share0.8 | 16/16 | pass | 122.02543 | 6985.34 | 39.2582 | 74.0322 |
| hydraulic-4MJ-share0.2 | 16/16 | pass | 121.62790 | 6981.12 | 39.2793 | 74.0623 |
| hydraulic-4MJ-share0.5 | 16/16 | pass | 121.62790 | 6981.12 | 39.2793 | 74.0623 |
| hydraulic-4MJ-share0.8 | 16/16 | pass | 121.62790 | 6981.12 | 39.2793 | 74.0623 |
| hydraulic-4MJ-recovery-disabled | 16/16 | pass | 122.54951 | 6966.07 | 39.2793 | 74.0346 |

Economic Pareto alternatives: no-store.

The disabled hydraulic 4 MJ case has identical hardware and mass to its enabled counterpart. The no-store control removes the interface kit and station packages and therefore has a different physical identity. Residual bank energy is retained, with no invented dump or credit. Station standby, cooling, reset, losses, interface mass, stock, renewals and all fourteen lifecycle scopes remain included.

These prices are calculated low/base/high outline assumptions. Supplier/site prices, equipment duty, availability and lifetimes are not verified. Complete per-case accounts, request/result identities, retained failures and native resource receipts are in this package.

Commands: `python -m engineering.recovery_search plan`; `python -m engineering.recovery_search run --output <new-private-directory>`; `python -m engineering.recovery_search verify --output <directory>`. Verification checks recorded integrity and derivations; it does not independently rerun physical solvers.
