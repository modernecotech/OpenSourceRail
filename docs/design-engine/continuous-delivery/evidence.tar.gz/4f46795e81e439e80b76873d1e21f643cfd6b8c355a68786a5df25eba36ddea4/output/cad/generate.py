import sys,json
sys.path[:0]=['/home/hayder/Documents/OpenSourceRail', '/home/hayder/Documents/OpenSourceRail/design/component-catalogue/src']
from engineering.factory_examples.native import export_native
try:
    export_native('/home/hayder/.local/state/opensourcerail/continuous-design/epochs/aa1070e8547a5bb079a602688cdabd65b5c318f013aced20f1a485d5a9b8ae6f/attempts/4f46795e81e439e80b76873d1e21f643cfd6b8c355a68786a5df25eba36ddea4/001/output/model-definition.json','/home/hayder/.local/state/opensourcerail/continuous-design/epochs/aa1070e8547a5bb079a602688cdabd65b5c318f013aced20f1a485d5a9b8ae6f/attempts/4f46795e81e439e80b76873d1e21f643cfd6b8c355a68786a5df25eba36ddea4/001/output/cad')
except Exception as error:
    state="failed" if isinstance(error,ValueError) and str(error).startswith(('native primitive correspondence:', 'fixture solid interference:', 'native reopen identity mismatch', 'native reopen state or shape changed', 'STEP occupied volume round-trip mismatch')) else "hold"
    with open('/home/hayder/.local/state/opensourcerail/continuous-design/epochs/aa1070e8547a5bb079a602688cdabd65b5c318f013aced20f1a485d5a9b8ae6f/attempts/4f46795e81e439e80b76873d1e21f643cfd6b8c355a68786a5df25eba36ddea4/001/output/cad/native-outcome.json',"w") as stream:json.dump(dict(state=state,error=str(error)),stream)
    raise
