from pathlib import Path
import json,tarfile,io
from engineering.station_rail.common import identity,encoded,digest
from engineering.design_search import lim_static_benchmark as b
execution=Path('/tmp/osr-lim-static-benchmark-20261027');context=Path('/tmp/osr-lim-static-benchmark-audit-20261027');root=Path('/tmp/osr-objectives-20261027')
plan=b.read(execution/'plan.json');manifest=b.read(execution/'manifest.json');assessment=b.read(context/'assessment.json')
assert b.sources(root)==b.sources(execution/'source')==plan['source_sha256']
original={p.relative_to(execution).as_posix():digest(p) for p in execution.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.relative_to(execution).as_posix()!='manifest.json'}
assert original==manifest['files_sha256']
commands=dict(cwd=str(root),source_edits=['engineering/design_search/lim_static_benchmark.py','engineering/design_search/tests/test_lim_static_benchmark.py'],source_phase_git_HEAD=plan['source_git_HEAD'],plan_command=['/home/hayder/Documents/OpenSourceRail/.venv/bin/python','-m','engineering.design_search.lim_static_benchmark','plan','--output',str(execution),'--parent','/tmp/osr-fine-timestep-20261027/motoring-fine-dt-quarter','--getdp',plan['tool']['path']],run_command=['/home/hayder/Documents/OpenSourceRail/.venv/bin/python','-m','engineering.design_search.lim_static_benchmark','run','--output',str(execution)],matching_context_audit_command='OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONPATH=. /home/hayder/Documents/OpenSourceRail/.venv/bin/python '+str(context/'audit.py'),native_component_jobs=4,postrun_new_native_solves=0,source_hashes_unchanged=True,qualification=False)
(context/'commands.json').write_bytes(encoded(commands))
entries={}
for prefix,base in [('execution',execution),('context',context)]:
    for path in sorted(base.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:entries[prefix+'/'+path.relative_to(base).as_posix()]=dict(sha256=digest(path),bytes=path.stat().st_size)
index=dict(schema='osr-static-LIM-package-index/1',native_plan_id=plan['plan_id'],native_manifest_sha256=digest(execution/'manifest.json'),assessment_id=assessment['assessment_id'],files=entries,immutability='Content-hash inventory and0444files on sharedFS; no OS read-only isolation claim',operating_map_admitted=False,physical_accepted=False)
index['artifact_index_id']=identity(index);idx=Path('/tmp/osr-lim-static-benchmark-package-20261027.index.json');idx.write_bytes(encoded(index))
archive=Path('/tmp/osr-lim-static-benchmark-package-20261027.tar.xz')
with tarfile.open(archive,'w:xz',preset=6) as output:
    for name in sorted(entries):
        prefix,relative=name.split('/',1);base=execution if prefix=='execution' else context;data=(base/relative).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o444;info.mtime=0;output.addfile(info,io.BytesIO(data))
    data=idx.read_bytes();info=tarfile.TarInfo('index.json');info.size=len(data);info.mode=0o444;info.mtime=0;output.addfile(info,io.BytesIO(data))
for base in (execution,context):
    for path in base.rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts:path.chmod(0o444)
idx.chmod(0o444);archive.chmod(0o444)
print(json.dumps(dict(archive=str(archive),archive_bytes=archive.stat().st_size,archive_sha256=digest(archive),index=str(idx),index_id=index['artifact_index_id'],index_sha256=digest(idx),files=len(entries)+1,native_plan_sha256=digest(execution/'plan.json'),original_native_manifest_sha256=digest(execution/'manifest.json')),indent=2))
