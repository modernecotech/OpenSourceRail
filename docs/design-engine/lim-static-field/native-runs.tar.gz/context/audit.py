from pathlib import Path
import json,subprocess,shutil
import numpy as np
from engineering.design_search import lim_static_benchmark as b
from engineering.station_rail.common import identity,encoded,digest
root=Path('/tmp/osr-objectives-20261027');base=Path('/tmp/osr-lim-static-benchmark-20261027');audit=Path('/tmp/osr-lim-static-benchmark-audit-20261027');plan=b.read(base/'plan.json');campaign=b.read(base/'campaign.json')
verification=b.verify(base,root=root);data=b.mesh_data(plan['parent_request']);points,tri,reg,boundary,branch,sign,area,grad,tags,outer=data
assert b.sources(root)==b.sources(base/'source')==plan['source_sha256']
assert campaign['attempted_jobs']==campaign['completed_jobs']==4
assert campaign['elapsed_s']<240
assert all(r['analysis']['numerical_subset_agreement'] for r in campaign['rows'])
p=plan['parent_request']['physical_geometry'];height=p['active_height_m'];density=p['turns_per_coil']/(p['slot_width_m']*p['slot_depth_m'])
values={};records=[]
for case,row in zip(plan['cases'],campaign['rows']):
    folder=base/case['name'];A=b.node_table(folder/'a.txt',len(points));B=b.element_table(folder/'b.txt',len(tri));I=np.asarray(case['path_currents_A'])
    links=[];positive=[];negative=[]
    for k in range(30):
        pos=tags==1000+2*k;neg=tags==1001+2*k;meanA=A[tri].mean(axis=1)
        links.append(height*density*(area[pos]@meanA[pos]-area[neg]@meanA[neg]));positive.append(float(area[pos].sum()*density*I[k]));negative.append(float(-area[neg].sum()*density*I[k]))
    links=np.asarray(links);work=float(I@links);energy=row['analysis']['getdp_energy_J'];nu=np.where(reg==3,1/(b.transient.MU0*1000),1/b.transient.MU0);Benergy=float(height*np.sum(.5*area*nu*np.sum(B*B,axis=1)))
    assert abs(work-2*energy)<1e-10
    assert np.allclose(positive,200*I,rtol=1e-12,atol=1e-10) and np.allclose(negative,-200*I,rtol=1e-12,atol=1e-10)
    assert abs(sum(positive)+sum(negative))<1e-10
    assert np.allclose(Benergy,energy,rtol=1e-10,atol=1e-20)
    values[case['name']]=dict(A=A,B=B,links=links,energy=energy,I=I)
    records.append(dict(name=case['name'],request_id=case['request_id'],evaluation_id=row['evaluation_id'],execution=row['execution'],elapsed_outer_s=row['elapsed_outer_s'],analysis=row['analysis'],path_linkages_Wb=links.tolist(),independent_source_work_J=work,source_work_minus_twice_energy_J=work-2*energy,independent_energy_from_getdp_cell_B_J=Benergy,each_path_positive_source_Aturn=positive,each_path_negative_source_Aturn=negative,model_msh_sha256=digest(folder/'model.msh'),model_pro_sha256=digest(folder/'model.pro')))
    assert (folder/'model.pro').read_text()==b.formulation(plan['parent_request'],case['path_currents_A'])
    assert (folder/'model.msh').read_text()==b.msh_text(points,tri,tags,outer)
q=values['quarter-current'];n=values['reversed-current'];u=values['unit-path'];z=values['zero']
controls=dict(zero_A_max=float(max(abs(z['A']))),zero_B_max=float(max(abs(z['B']).ravel())),zero_energy_J=z['energy'],polarity_A_max_abs_Wb_m=float(max(abs(q['A']+n['A']))),polarity_B_max_abs_T=float(max(abs(q['B']+n['B']).ravel())),polarity_energy_abs_difference_J=abs(q['energy']-n['energy']),reciprocity_q_dot_lambda_unit_Wb_A=float(q['I']@u['links']),reciprocity_unit_dot_lambda_q_Wb_A=float(u['I']@q['links']))
controls['reciprocity_absolute_residual_J']=abs(controls['reciprocity_q_dot_lambda_unit_Wb_A']-controls['reciprocity_unit_dot_lambda_q_Wb_A'])
assert controls['zero_A_max']==controls['zero_B_max']==controls['zero_energy_J']==0
assert controls['polarity_A_max_abs_Wb_m']<1e-13 and controls['polarity_B_max_abs_T']<1e-11 and controls['reciprocity_absolute_residual_J']<1e-10
report=dict(schema='osr-independent-static-subset-arithmetic-audit/1',plan_id=plan['plan_id'],campaign_id=campaign['campaign_id'],verification=verification,source_sha256=plan['source_sha256'],source_unchanged=True,exact_same_canonical_mesh_id=plan['actual_mesh']['mesh_discretization_id'],cases=records,controls=controls,source_normalization='Each closed path has5positive+5negative legs,40turns per coil: signed current-density cross-section integrals +/-200I ampere-turn; no extrusion height in Js, height0.16m only in total energy/linkage',static_secondary='Aluminium has mu_r1 and no eddy current here; the finite9m descriptor remains ancestry, its position does not affect a homogeneous nonmagnetic static region',independence='GetDP assembles its own P1curl weakoperator/source integrals; geometry shared intentionally. This audit is arithmetic/read-back on sharedFS, not a second independent full-model verifier.',scope='Sampled linearstaticfield/operator/winding-normalization subset only; no transient/motion/circuit/controller/force/nonlinear-material/thermal/installed-equipment/map/route qualification',physical_accepted=False,operating_map_admitted=False)
report['assessment_id']=identity(report);(audit/'assessment.json').write_bytes(encoded(report))
command=['/home/hayder/Documents/OpenSourceRail/.venv/bin/python','-m','pytest','-q','--import-mode=importlib','engineering/design_search/tests/test_lim_static_benchmark.py'];test=subprocess.run(command,cwd=root,capture_output=True,text=True);(audit/'tests.log').write_text(test.stdout+test.stderr);assert test.returncode==0
check=subprocess.run(['git','diff','--check'],cwd=root,capture_output=True,text=True);(audit/'diff-check.log').write_text(check.stdout+check.stderr);assert check.returncode==0
shutil.copyfile(root/'engineering/design_search/tests/test_lim_static_benchmark.py',audit/'test_lim_static_benchmark.py')
meta=dict(schema='osr-static-benchmark-closeout/1',assessment_id=report['assessment_id'],test_command=command,test_returncode=test.returncode,test_log_sha256=digest(audit/'tests.log'),test_source_sha256=digest(audit/'test_lim_static_benchmark.py'),source_changed=False,source_git_HEAD=plan['source_git_HEAD'],GetDP_native_jobs=4,additional_field_solves_in_audit=0,retries=0,failed_jobs=[],interrupted_jobs=[],remaining_authorized_jobs=0,memory=dict(enforced_worker_RLIMIT_AS_bytes=2147483648,measured_whole_worker_peak_RAM_bytes=None,GetDP_reported_RAM='See each native stdout.log, not a whole-worker highwater measurement'),execution_commands=['python -m engineering.design_search.lim_static_benchmark plan --output PRIVATE --parent EXPLICIT_PARENT --getdp EXPLICIT_GETDP','python -m engineering.design_search.lim_static_benchmark run --output PRIVATE','python -m engineering.design_search.lim_static_benchmark verify --output PRIVATE'],git_metadata_refusal='Worker git switch initially refused read-only .git metadata; coordinator switched branch. This is tool-specific and is not OS-wide read-only isolation.',primary_references=['https://getdp.info/doc/texinfo/getdp.html','https://github.com/getdp-project/getdp/blob/master/templates/Lib_Magnetostatics_a_phi.pro','https://petsc.org/release/manualpages/Sys/PetscInitialize/'],next_tasks=['Independent review of generated source groups/material/gauge/output comparisons','Moving linear A/u+floating-conductor+circuit benchmark is separate future evaluator work','Phase reversal/blocked/full-overlap/warm-start and temporal/global mesh controls remain open','Actual wiring/leakage/current controller, nonlinear material, converter/braking/protection, repeated thermal and installed equipment remain unqualified'],physical_accepted=False,operating_map_admitted=False)
meta['closeout_id']=identity(meta);(audit/'closeout.json').write_bytes(encoded(meta));print(json.dumps(dict(assessment_id=report['assessment_id'],controls=controls,case_metrics=[dict(name=r['name'],A_relative=r['analysis']['nodal_A_relative_L2'],B_relative=r['analysis']['cell_B_relative_area_L2'],energy_relative=r['analysis']['energy_relative_error'],energy_J=r['analysis']['getdp_energy_J']) for r in records],tests=test.stdout.strip()),indent=2))
