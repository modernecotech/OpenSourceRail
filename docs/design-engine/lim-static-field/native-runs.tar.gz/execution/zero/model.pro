// Independent static A_z weak form from official GetDP magnetostatics template.
mu0=4.e-7*Pi;
Group{Air=Region[1];Steel=Region[3];Coils=Region[{1000,1001,1002,1003,1004,1005,1006,1007,1008,1009,1010,1011,1012,1013,1014,1015,1016,1017,1018,1019,1020,1021,1022,1023,1024,1025,1026,1027,1028,1029,1030,1031,1032,1033,1034,1035,1036,1037,1038,1039,1040,1041,1042,1043,1044,1045,1046,1047,1048,1049,1050,1051,1052,1053,1054,1055,1056,1057,1058,1059}];Domain=Region[{Air,Steel,Coils}];Outer=Region[901];}
Function{nu[Region[{Air,Coils}]]=1/mu0;nu[Steel]=1/(1000*mu0);js[Region[1000]]=Vector[0,0,0];
js[Region[1001]]=Vector[0,0,-0];
js[Region[1002]]=Vector[0,0,0];
js[Region[1003]]=Vector[0,0,-0];
js[Region[1004]]=Vector[0,0,0];
js[Region[1005]]=Vector[0,0,-0];
js[Region[1006]]=Vector[0,0,0];
js[Region[1007]]=Vector[0,0,-0];
js[Region[1008]]=Vector[0,0,0];
js[Region[1009]]=Vector[0,0,-0];
js[Region[1010]]=Vector[0,0,0];
js[Region[1011]]=Vector[0,0,-0];
js[Region[1012]]=Vector[0,0,0];
js[Region[1013]]=Vector[0,0,-0];
js[Region[1014]]=Vector[0,0,0];
js[Region[1015]]=Vector[0,0,-0];
js[Region[1016]]=Vector[0,0,0];
js[Region[1017]]=Vector[0,0,-0];
js[Region[1018]]=Vector[0,0,0];
js[Region[1019]]=Vector[0,0,-0];
js[Region[1020]]=Vector[0,0,0];
js[Region[1021]]=Vector[0,0,-0];
js[Region[1022]]=Vector[0,0,0];
js[Region[1023]]=Vector[0,0,-0];
js[Region[1024]]=Vector[0,0,0];
js[Region[1025]]=Vector[0,0,-0];
js[Region[1026]]=Vector[0,0,0];
js[Region[1027]]=Vector[0,0,-0];
js[Region[1028]]=Vector[0,0,0];
js[Region[1029]]=Vector[0,0,-0];
js[Region[1030]]=Vector[0,0,0];
js[Region[1031]]=Vector[0,0,-0];
js[Region[1032]]=Vector[0,0,0];
js[Region[1033]]=Vector[0,0,-0];
js[Region[1034]]=Vector[0,0,0];
js[Region[1035]]=Vector[0,0,-0];
js[Region[1036]]=Vector[0,0,0];
js[Region[1037]]=Vector[0,0,-0];
js[Region[1038]]=Vector[0,0,0];
js[Region[1039]]=Vector[0,0,-0];
js[Region[1040]]=Vector[0,0,0];
js[Region[1041]]=Vector[0,0,-0];
js[Region[1042]]=Vector[0,0,0];
js[Region[1043]]=Vector[0,0,-0];
js[Region[1044]]=Vector[0,0,0];
js[Region[1045]]=Vector[0,0,-0];
js[Region[1046]]=Vector[0,0,0];
js[Region[1047]]=Vector[0,0,-0];
js[Region[1048]]=Vector[0,0,0];
js[Region[1049]]=Vector[0,0,-0];
js[Region[1050]]=Vector[0,0,0];
js[Region[1051]]=Vector[0,0,-0];
js[Region[1052]]=Vector[0,0,0];
js[Region[1053]]=Vector[0,0,-0];
js[Region[1054]]=Vector[0,0,0];
js[Region[1055]]=Vector[0,0,-0];
js[Region[1056]]=Vector[0,0,0];
js[Region[1057]]=Vector[0,0,-0];
js[Region[1058]]=Vector[0,0,0];
js[Region[1059]]=Vector[0,0,-0];}
Constraint{{Name Boundary;Case{{Region Outer;Value 0.;}}}}
Jacobian{{Name Vol;Case{{Region All;Jacobian Vol;}}}}
Integration{{Name Gauss;Case{{Type Gauss;Case{{GeoElement Triangle;NumberOfPoints 3;}}}}}}
FunctionSpace{{Name As;Type Form1P;BasisFunction{{Name sn;NameOfCoef an;Function BF_PerpendicularEdge;Support Domain;Entity NodesOf[All];}}Constraint{{NameOfCoef an;EntityType NodesOf;NameOfConstraint Boundary;}}}}
Formulation{{Name Static;Type FemEquation;Quantity{{Name a;Type Local;NameOfSpace As;}}Equation{
Integral{[nu[]*Dof{d a},{d a}];In Domain;Jacobian Vol;Integration Gauss;}
Integral{[-js[],{a}];In Coils;Jacobian Vol;Integration Gauss;}
}}}
Resolution{{Name Solve;System{{Name S;NameOfFormulation Static;}}Operation{Generate[S];Solve[S];SaveSolution[S];}}}
PostProcessing{{Name Result;NameOfFormulation Static;Quantity{
{Name az;Value{Local{[CompZ[{a}]];In Domain;Jacobian Vol;}}}
{Name b;Value{Term{[{d a}];In Domain;Jacobian Vol;}}}
{Name energy;Value{Integral{[.5*nu[]*SquNorm[{d a}]];In Domain;Jacobian Vol;Integration Gauss;}}}
{Name work;Value{Integral{[CompZ[js[]]*CompZ[{a}]];In Coils;Jacobian Vol;Integration Gauss;}}}
}}}
PostOperation{{Name Result;NameOfPostProcessing Result;Operation{
Print[az,OnElementsOf Domain,File "a.txt",Format NodeTable];
Print[b,OnElementsOf Domain,Depth 0,File "b.txt",Format ElementTable];
Print[energy[Domain],OnGlobal,File "energy.txt",Format Table];
Print[work[Coils],OnGlobal,File "work.txt",Format Table];
}}}
