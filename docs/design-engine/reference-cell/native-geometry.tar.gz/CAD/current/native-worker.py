
import os,json,resource
import FreeCAD as App, Part
FOLDER=globals().get('FOLDER',os.getcwd())
VERIFY_ONLY=globals().get('VERIFY_ONLY',False)
data=json.load(open(os.path.join(FOLDER,'native-input.json')))
def details(shape):
    # Every current canonical box/cylinder/tube/envelope is one solid. An OCC
    # wrapper may be a Compound, which need not expose CenterOfMass itself.
    # Never average disconnected primitive output or hide an extra solid.
    solids=list(shape.Solids)
    if len(solids)!=1:raise ValueError('A canonical primitive must contain exactly one solid')
    volume=sum(s.Volume for s in solids)
    if volume<=0:raise ValueError('Positive primitive volume required')
    centres=[s.CenterOfMass for s in solids]
    c=App.Vector(*[sum(s.Volume*getattr(p,axis) for s,p in zip(solids,centres))/volume for axis in ('x','y','z')])
    b=shape.BoundBox
    return dict(volume_m3=shape.Volume/1e9,centroid_m=[c.x/1000,c.y/1000,c.z/1000],
        bounds_min_m=[b.XMin/1000,b.YMin/1000,b.ZMin/1000],bounds_max_m=[b.XMax/1000,b.YMax/1000,b.ZMax/1000])
if not VERIFY_ONLY:
    doc=App.newDocument('ReferenceCell');shapes={}
    for item in data['items']:
        g=item['geometry'];d=g['dimensions_m'];key=item['part_definition_id']
        if key not in shapes:
            if g['kind'] in ('box','envelope'):
                shape=Part.makeBox(d[0]*1000,d[1]*1000,d[2]*1000,App.Vector(-d[0]*500,-d[1]*500,-d[2]*500))
            else:
                r=d.get('outer_radius',d.get('radius'));length=d['length']*1000
                shape=Part.makeCylinder(r*1000,length,App.Vector(0,0,-length/2))
                if g['kind']=='tube':shape=shape.cut(Part.makeCylinder(d['inner_radius']*1000,length,App.Vector(0,0,-length/2)))
            if shape.isNull() or not shape.isValid():raise ValueError('Invalid native primitive')
            shapes[key]=shape
        obj=doc.addObject('PartDesign::Feature','P'+str(len(doc.Objects)))
        obj.Shape=shapes[key].copy();m=[list(row) for row in item['transform']]
        for i in range(3):m[i][3]*=1000
        obj.Placement=App.Placement(App.Matrix(*[x for row in m for x in row]))
        for name,value in (('OccurrenceId',item['occurrence_id']),('PartDefinitionId',key),
            ('PartRevisionId',item['part_revision_id']),('GeometryScope',g['kind'])):
            obj.addProperty('App::PropertyString',name);setattr(obj,name,value)
    doc.recompute();doc.saveAs(os.path.join(FOLDER,'vehicle.FCStd'))
    Part.export(list(doc.Objects),os.path.join(FOLDER,'vehicle.step'));App.closeDocument(doc.Name)
doc=App.openDocument(os.path.join(FOLDER,'vehicle.FCStd'))
rows=[]
for obj in doc.Objects:
    if hasattr(obj,'Shape') and not obj.Shape.isNull():
        row=details(obj.Shape);row.update(occurrence_id=obj.OccurrenceId,part_definition_id=obj.PartDefinitionId,
            part_revision_id=obj.PartRevisionId,geometry_kind=obj.GeometryScope);rows.append(row)
App.closeDocument(doc.Name)
step=Part.read(os.path.join(FOLDER,'vehicle.step'))
result=dict(candidate_id=data['candidate_id'],cars=data['cars'],FreeCAD_version=list(App.Version()),
    enforced_address_space_limit_bytes=resource.getrlimit(resource.RLIMIT_AS)[0],
    FCStd_occurrences=rows,STEP_solids=[details(s) for s in step.Solids],complete_installed_geometry=False,
    physical_accepted=False,manufacturing_release=False)
output=globals().get('OUTPUT',os.path.join(FOLDER,'native-result.json'))
with open(output,'w') as stream:json.dump(result,stream,sort_keys=True,allow_nan=False)
