"""Bounded actual geometry workers; private immutable records, not qualification."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from hashlib import sha256
import gzip,json,os,subprocess,sys,time,resource
ROOT=Path('/home/hayder/.local/state/opensourcerail/reference-cell-source-20261028')
STATE=Path('/home/hayder/.local/state/opensourcerail/reference-cell-native-20261028')
sys.path.insert(0,str(ROOT))
from engineering.station_rail.common import identity,digest,encoded
EXPECTED={'engineering/reference_cell/geometry.py':'134bf2846ca8cd6bf8dd6207f0f49c8c5dd02b8524467247d3e91c55068f0d48','engineering/reference_cell/vehicles.py':'49c7fded9b68a464f25b7e101635fd92b1c52f5c25e84ea42e487114ec822304'}
def check():
 for p,h in EXPECTED.items():
  if digest(ROOT/p)!=h:raise ValueError('Owned geometry/vehicle source changed: '+p)
def seal(v):v['record_id']=identity(v);return v

def ifc_worker(name):
 from engineering.reference_cell import vehicles,geometry
 import ifcopenshell,numpy
 import ifcopenshell._ifcopenshell_wrapper as native
 check();begin=time.monotonic();v=vehicles.evaluate(name,root=ROOT);cache=STATE/'vehicles'/f'{name}.json.gz';cache.parent.mkdir(exist_ok=True)
 if cache.exists():raise ValueError('Fresh immutable vehicle cache required')
 cache.write_bytes(gzip.compress(encoded(v),mtime=0))
 out=STATE/'IFC'/name
 receipt=geometry.export_ifc(v,out);verified=geometry.verify_ifc(v,out);check()
 value=seal(dict(schema='osr-private-reference-cell-geometry-worker/1',vehicle=name,candidate_id=v['candidate_id'],vehicle_evaluation_id=v['evaluation_id'],
  source_sha256=v['source_sha256'],producer_sha256=EXPECTED,execution='completed',elapsed_s=time.monotonic()-begin,
  cache_sha256=digest(cache),receipt=receipt,verification=verified,
  tool=dict(python=sys.version,python_binary_sha256=digest(sys.executable),ifcopenshell_version=ifcopenshell.version,ifcopenshell_native_sha256=digest(native.__file__),numpy=numpy.__version__),
  physical_accepted=False,manufacturing_release=False,operating_release=False))
 (STATE/f'{name}-worker.json').write_bytes(encoded(value));return value

def spawn_ifc(name):
 started=time.monotonic()
 def limit():resource.setrlimit(resource.RLIMIT_AS,(3*1024**3,3*1024**3))
 try:
  p=subprocess.run([sys.executable,str(STATE/'driver.py'),'--ifc-worker',name],cwd=ROOT,capture_output=True,timeout=180,preexec_fn=limit,
   env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1'})
  (STATE/f'{name}-stdout.log').write_bytes(p.stdout);(STATE/f'{name}-stderr.log').write_bytes(p.stderr)
  if p.returncode:return seal(dict(vehicle=name,execution='failed',reason='Worker exit '+str(p.returncode),elapsed_s=time.monotonic()-started,physical_accepted=False))
  return json.loads((STATE/f'{name}-worker.json').read_bytes())
 except subprocess.TimeoutExpired as e:
  (STATE/f'{name}-stdout.log').write_bytes(e.stdout or b'');(STATE/f'{name}-stderr.log').write_bytes(e.stderr or b'')
  return seal(dict(vehicle=name,execution='interrupted',reason='180s bounded IFC worker deadline; partial outputs retained',elapsed_s=time.monotonic()-started,physical_accepted=False))

if __name__=='__main__' and len(sys.argv)==3 and sys.argv[1]=='--ifc-worker':
 ifc_worker(sys.argv[2]);raise SystemExit(0)
check();started=time.monotonic();results=[]
with ThreadPoolExecutor(max_workers=2) as pool:
 pending={pool.submit(spawn_ifc,n):n for n in ('V1','V2','V3','V4','V5')}
 for future in as_completed(pending):
  value=future.result();results.append(value)
  (STATE/'IFC-progress.json').write_bytes(encoded(dict(results=sorted(results,key=lambda x:x['vehicle']),elapsed_s=time.monotonic()-started)))
  print(value['vehicle'],value['execution'],round(value['elapsed_s'],3),flush=True)
check();native=dict(execution='not-run',reason='V1 actual IFC worker did not complete',physical_accepted=False)
if any(v['vehicle']=='V1' and v['execution']=='completed' for v in results):
 if time.monotonic()-started>240:native=dict(execution='not-run',reason='Cannot reserve two240s native/reopen requests within720s coordinator budget',physical_accepted=False)
 else:
  from engineering.reference_cell import geometry
  vehicle=json.loads(gzip.decompress((STATE/'vehicles/V1.json.gz').read_bytes()))
  try:
   native=geometry.export_native(vehicle,STATE/'CAD/V1-car1',cars=(1,),timeout_s=240,memory_bytes=3*1024**3)
   if native['execution']=='completed':
    (STATE/'native-export.json').write_bytes(encoded(native))
    verified=geometry.verify_native(vehicle,STATE/'CAD/V1-car1',native)
    native=dict(receipt=native,verification=verified,execution='completed',physical_accepted=False)
  except Exception as error:
   native=dict(execution='failed-or-interrupted',reason=type(error).__name__+': '+str(error),partial_files_retained=True,physical_accepted=False)
check();report=seal(dict(schema='osr-private-reference-cell-native-campaign/1',source_sha256=EXPECTED,
 ifc=sorted(results,key=lambda x:x['vehicle']),native=native,elapsed_s=time.monotonic()-started,
 maximum_ifc_workers=5,maximum_IFC_concurrency=2,maximum_native_export_workers=1,maximum_native_reopen_workers=1,
 maximum_native_seconds_per_worker=240,memory_bytes_per_worker=3*1024**3,
 physical_accepted=False,engineering_accepted=False,manufacturing_release=False,operating_release=False))
(STATE/'campaign.json').write_bytes(encoded(report));print('FINAL',report['record_id'],native['execution'],round(report['elapsed_s'],3),flush=True)
