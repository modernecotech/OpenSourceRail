from pathlib import Path
import sys,gzip,json,time
ROOT=Path('/home/hayder/.local/state/opensourcerail/reference-cell-source-20261028');sys.path.insert(0,str(ROOT))
from engineering.station_rail.common import identity,digest,encoded
from engineering.reference_cell import native_cad
state=Path('/home/hayder/.local/state/opensourcerail/reference-cell-native-20261028')
v=json.loads(gzip.decompress((state/'vehicles/V1.json.gz').read_bytes()))
expected='e45fd48e575f63c577e6cac818e032630598ef584caffaaff068d80020e8e7cf'
assert digest(ROOT/'engineering/reference_cell/native_cad.py')==expected
begin=time.monotonic();out=state/'CAD/V1-car1-compound-safe'
try:
 r=native_cad.export_native(v,out,cars=(1,),timeout_s=240,memory_bytes=3*1024**3,root=ROOT)
 verified=native_cad.verify_native(v,out,r,root=ROOT) if r['execution']=='completed' else None
 value=dict(schema='osr-private-revised-native-campaign/1',execution=r['execution'],receipt=r,verification=verified)
except Exception as error:
 value=dict(schema='osr-private-revised-native-campaign/1',execution='failed-or-interrupted',reason=type(error).__name__+': '+str(error),partial_files_retained=True)
assert digest(ROOT/'engineering/reference_cell/native_cad.py')==expected
value.update(elapsed_s=time.monotonic()-begin,candidate_id=v['candidate_id'],source_sha256={'engineering/reference_cell/native_cad.py':expected},
 ancestry_failure_manifest_sha256=digest(state/'native-failure-manifest.json'),maximum_export_workers=1,maximum_reopen_workers=1,
 maximum_seconds_per_worker=240,memory_bytes=3*1024**3,physical_accepted=False,manufacturing_release=False,operating_release=False)
value['record_id']=identity(value);(state/'revised-native-campaign.json').write_bytes(encoded(value));print(value['execution'],value['record_id'],round(value['elapsed_s'],3),flush=True)
