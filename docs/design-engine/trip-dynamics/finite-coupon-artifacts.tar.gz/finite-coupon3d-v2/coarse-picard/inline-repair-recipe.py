from pathlib import Path
import shutil
root=Path('/home/hayder/Documents/OpenSourceRail/build/trip-dynamics/finite-coupon3d-v2')
d=root/'coarse-picard';d.mkdir()
shutil.copyfile(root/'coarse/coupon.msh',d/'coupon.msh')
s=(root/'coarse/coupon.pro').read_text()
a=s.index(' Integral{[-mu[-{d p}]*{d p},{d p}];In Steel;')
b=s.index('\n}}}',a)
s=s[:a]+' Integral{[-mu[-{d p}]*Dof{d p},{d p}];In Steel;Jacobian V;Integration I;}'+s[b:]
s=s.replace('$iter<60','$iter<80')
(d/'coupon.pro').write_text(s)
print(d)
