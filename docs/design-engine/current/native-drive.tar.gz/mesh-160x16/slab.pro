// Complex magnetic diffusion benchmark, following official GetDP
// Lib_Magnetodynamics2D_av_Cir: curl(nu curl A) + j omega sigma A = 0.
mu0=4.e-7*Pi;sigma=20000000.0;Freq=5.0;
k=12.566370614359172;gr=21.944458951395493;gi=17.990153091401197;ur=0.9951686647164111;ui=-0.022035804566216906;A0=0.015915494309189534;
Group { Plate=Region[1]; Boundary=Region[101]; }
Function {
 r[]=Cosh[gr*Y[]]*Cos[gi*Y[]]*ur-Sinh[gr*Y[]]*Sin[gi*Y[]]*ui;
 i[]=Cosh[gr*Y[]]*Cos[gi*Y[]]*ui+Sinh[gr*Y[]]*Sin[gi*Y[]]*ur;
 exact[]=A0*Complex[r[]*Cos[k*X[]]+i[]*Sin[k*X[]],i[]*Cos[k*X[]]-r[]*Sin[k*X[]]];
}
Constraint { { Name Exact; Case { { Region Boundary; Value exact[]; } } } }
Jacobian { { Name Vol;Case { { Region All;Jacobian Vol; } } } }
Integration { { Name Gauss;Case { { Type Gauss;Case { { GeoElement Triangle;NumberOfPoints 7; } } } } } }
FunctionSpace { { Name Aspace;Type Form1P;
 BasisFunction { { Name sn;NameOfCoef an;Function BF_PerpendicularEdge;Support Plate;Entity NodesOf[All]; } }
 Constraint { { NameOfCoef an;EntityType NodesOf;NameOfConstraint Exact; } }
} }
Formulation { { Name Diffusion;Type FemEquation;
 Quantity { { Name a;Type Local;NameOfSpace Aspace; } }
 Equation {
  Integral { [1/mu0*Dof{d a},{d a}];In Plate;Jacobian Vol;Integration Gauss; }
  Integral { DtDof [sigma*Dof{a},{a}];In Plate;Jacobian Vol;Integration Gauss; }
 }
} }
Resolution { { Name Solve;System { { Name S;NameOfFormulation Diffusion;Type ComplexValue;Frequency Freq; } }
 Operation { Generate[S];Solve[S];SaveSolution[S]; }
} }
PostProcessing { { Name Result;NameOfFormulation Diffusion;
 Quantity {
 { Name Joule;Value { Integral { [.5*sigma*Re[CompZ[Dt[{a}]]*Conj[CompZ[Dt[{a}]]]]];In Plate;Jacobian Vol;Integration Gauss; } } }
 { Name ForceX;Value { Integral { [.5*sigma*Re[CompZ[Dt[{a}]]*Conj[CompY[{d a}]]]];In Plate;Jacobian Vol;Integration Gauss; } } }
 { Name PotentialError;Value { Integral { [Re[(CompZ[{a}]-exact[])*Conj[CompZ[{a}]-exact[]]]];In Plate;Jacobian Vol;Integration Gauss; } } }
 }
} }
PostOperation { { Name Result;NameOfPostProcessing Result;Operation {
 Print[Joule[Plate],OnGlobal,File "joule.txt",Format Table];
 Print[ForceX[Plate],OnGlobal,File "force.txt",Format Table];
 Print[PotentialError[Plate],OnGlobal,File "error.txt",Format Table];
} } }
