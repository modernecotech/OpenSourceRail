// Manufactured conducting slab, periodic-wave exact Dirichlet boundary.
Point(1)={0,-0.0075,0,1};Point(2)={0.5,-0.0075,0,1};
Point(3)={0.5,0.0075,0,1};Point(4)={0,0.0075,0,1};
Line(1)={1,2};Line(2)={2,3};Line(3)={3,4};Line(4)={4,1};
Curve Loop(1)={1,2,3,4};Plane Surface(1)={1};
Transfinite Curve{1,3}=81;Transfinite Curve{2,4}=9;
Transfinite Surface{1};
Physical Surface("Al_hypothesis",1)={1};
Physical Curve("exact_boundary",101)={1,2,3,4};
Mesh.MshFileVersion=2.2;
