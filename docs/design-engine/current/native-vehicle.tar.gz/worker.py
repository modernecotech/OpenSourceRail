
import FreeCAD as A, Part, Import
import json, pathlib, sys
folder=pathlib.Path(__file__).parent
inputs=json.loads((folder/'input.json').read_text())
doc=A.newDocument('OSR_v06_station_rail')
groups={};mass=0.;volume=0.;mismatch=[]
for p in inputs['parts']:
    origin=A.Vector(*[x*1000 for x in p['at_m']])
    if p['kind']=='box':
        sh=Part.makeBox(*[x*1000 for x in p['size_m']],origin)
        for hole in p.get('holes',[]):
            axis=hole.get('axis','z');index='xyz'.index(axis)
            start=list(p['at_m'])
            for j,key in enumerate(('x_m','y_m','z_m')):
                if j!=index:start[j]+=hole.get(key,0.)
            direction=[0.,0.,0.];direction[index]=1.
            cutter=Part.makeCylinder(hole['diameter_m']*500,hole.get('length_m',p['size_m'][index])*1000,A.Vector(*[x*1000 for x in start]),A.Vector(*direction))
            sh=sh.cut(cutter)
    else:
        axis=A.Vector(*p['axis'])
        sh=Part.makeCylinder(p['radius_m']*1000,p['length_m']*1000,origin,axis)
        if p.get('inner_radius_m',0)>0:
            sh=sh.cut(Part.makeCylinder(p['inner_radius_m']*1000,p['length_m']*1000,origin,axis))
    vm3=sh.Volume/1e9
    if abs(vm3-p['volume_m3'])>max(1e-10,p['volume_m3']*1e-8):mismatch.append(p['id'])
    mass+=vm3*p['density_kg_m3'];volume+=vm3
    groups.setdefault(p.get('system','body-fitout'),[]).append(sh)
objects=[]
for i,(name,shapes) in enumerate(sorted(groups.items())):
    obj=doc.addObject('PartDesign::Feature','Material_'+str(i));obj.Label=name
    obj.Shape=Part.makeCompound(shapes);objects.append(obj)
doc.recompute();doc.saveAs(str(folder/'vehicle.FCStd'))
Import.export(objects,str(folder/'vehicle.step'))
A.closeDocument(doc.Name)
reopened=A.openDocument(str(folder/'vehicle.FCStd'))
reopenedvol=sum(obj.Shape.Volume for obj in reopened.Objects if hasattr(obj,'Shape'))/1e9
step_shape=Part.Shape();step_shape.read(str(folder/'vehicle.step'))
step_volume=step_shape.Volume/1e9
result={'FreeCAD_version':list(A.Version()),'part_count':len(inputs['parts']),'material_groups':len(groups),
        'native_material_kg':mass,'native_volume_m3':volume,'reopened_volume_m3':reopenedvol,
        'part_volume_mismatch_ids':mismatch,'all_part_volumes_match':not mismatch,
        'reopened_volume_matches':abs(reopenedvol-volume)<1e-8,
        'step_reopened_volume_m3':step_volume,'step_reopened_volume_matches':abs(step_volume-volume)<1e-8,
        'complete_installed_geometry':False,'interference_and_removal_qualified':False}
(folder/'cad-result.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
A.closeDocument(reopened.Name)
