"""Independent local line-supported face fixture; not actual anchor/civil approval."""
from pathlib import Path
from hashlib import sha256
import json,math,subprocess,os,time
ROOT=Path('/home/hayder/Documents/OpenSourceRail')
OUT=ROOT/'build/physical-feasibility-round/guideway-native'
OUT.mkdir(exist_ok=False)
SOURCE=Path(__file__);original=SOURCE.read_bytes();(OUT/'worker.py').write_bytes(original)
def encoded(x):return (json.dumps(x,sort_keys=True,indent=2)+'\n').encode()
def deck(nx,t,P):
    ny=4;L=.5;w=.4;nodes={};lines=['*HEADING','OSR local passive face shell, line supports; SI m N Pa','*NODE']
    for j in range(2*ny+1):
        for i in range(2*nx+1):
            if i%2 and j%2:continue
            nodes[i,j]=len(nodes)+1;lines.append(f'{nodes[i,j]},{L*i/(2*nx):.12g},{w*j/(2*ny):.12g},0.')
    lines+=['*ELEMENT,TYPE=S8R,ELSET=ALL'];elements=0
    for j in range(0,2*ny,2):
        for i in range(0,2*nx,2):
            elements+=1;grid=((i,j),(i+2,j),(i+2,j+2),(i,j+2),(i+1,j),(i+2,j+1),(i+1,j+2),(i,j+1))
            lines.append(','.join(map(str,[elements,*[nodes[k] for k in grid]])))
    ends=[n for (i,j),n in nodes.items() if i in (0,2*nx)];left=[n for (i,j),n in nodes.items() if i==0]
    middle=[nodes[nx,j] for j in range(2*ny+1)]
    weights=[1 if j in (0,2*ny) else 4 if j%2 else 2 for j in range(2*ny+1)]
    for name,values in [('ENDS',ends),('LEFT',left),('MIDDLE',middle),('ANCHOR',[nodes[0,0]])]:
        lines.append('*NSET,NSET='+name)
        for k in range(0,len(values),12):lines.append(','.join(map(str,values[k:k+12])))
    lines+=['*MATERIAL,NAME=STEEL','*ELASTIC','200.e9,.30','*SHELL SECTION,ELSET=ALL,MATERIAL=STEEL',str(t),
        '*BOUNDARY','ENDS,3,3','LEFT,1,1','ANCHOR,2,2','*STEP','*STATIC','*CLOAD']
    lines += [f'{node},3,{-P*weight/sum(weights):.14g}' for node,weight in zip(middle,weights)]
    lines+=['*NODE PRINT,NSET=MIDDLE','U','*NODE PRINT,NSET=ENDS','RF','*END STEP']
    return '\n'.join(lines)+'\n',dict(nx=nx,ny=ny,nodes=len(nodes),elements=elements,ends=ends,middle=middle,weights=weights)
def parse(text,mesh):
    u={};rf={};mode=None
    for line in text.splitlines():
        lo=line.lower()
        if 'displacements' in lo and 'set middle' in lo:mode='u';continue
        if 'forces' in lo and 'set ends' in lo:mode='rf';continue
        f=line.split()
        if len(f)!=4 or not f[0].isdigit():continue
        try:values=[float(v.replace('D','E')) for v in f[1:]]
        except ValueError:continue
        if mode=='u':u[int(f[0])]=values
        if mode=='rf':rf[int(f[0])]=values
    if set(u)!=set(mesh['middle']) or set(rf)!=set(mesh['ends']):raise ValueError('incomplete native output')
    return dict(mean_deflection_m=-sum(u[n][2]*w for n,w in zip(mesh['middle'],mesh['weights']))/sum(mesh['weights']),
        mid_transverse_min_deflection_m=-max(v[2] for v in u.values()),mid_transverse_max_deflection_m=-min(v[2] for v in u.values()),
        reaction_z_N=sum(v[2] for v in rf.values()))
rows=[]
for t,P in ((.020,40000.),(.035,40000.),(.035,70000.)):
    case=[]
    for nx in (8,16):
        name=f't{int(t*1000)}-P{int(P)}-n{nx}';folder=OUT/name;folder.mkdir();text,mesh=deck(nx,t,P);(folder/'face.inp').write_text(text)
        start=time.monotonic();command=['/usr/bin/ccx','-i','face']
        env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',CCX_NPROC_RESULTS='1',CCX_NPROC_EQUATION_SOLVER='1')
        trial=subprocess.run(command,cwd=folder,env=env,capture_output=True,timeout=60)
        (folder/'stdout.log').write_bytes(trial.stdout);(folder/'stderr.log').write_bytes(trial.stderr)
        row=dict(case=name,thickness_m=t,force_N=P,mesh=mesh,command=command,returncode=trial.returncode,elapsed_s=time.monotonic()-start,
            actual_anchor_pair_supports_included=False,full_civil_qualified=False,physical_accepted=False)
        if trial.returncode==0:
            row['native']=parse((folder/'face.dat').read_text(),mesh)
            analytic=P*.5**3/(48*200e9*(.4*t**3/12))
            row.update(beam_deflection_m=analytic,native_over_beam=row['native']['mean_deflection_m']/analytic,
                force_residual_N=abs(row['native']['reaction_z_N']-P),fixture_1mm_screen='pass' if row['native']['mean_deflection_m']<=.001 else 'fail')
        (folder/'record.json').write_bytes(encoded(row));rows.append(row);case.append(row)
    if all(r['returncode']==0 for r in case):case[-1]['refinement_relative_change']=abs(case[1]['native']['mean_deflection_m']/case[0]['native']['mean_deflection_m']-1)
probe=subprocess.run(['/usr/bin/ccx','-v'],capture_output=True,text=True,timeout=10)
result=dict(schema='osr-local-face-native-fixture/1',scope='Independent isotropic S8R local strip with ideal line supports; no anchor/concrete/whole-beam or installed magnetic load qualification',
    worker_sha256=sha256(original).hexdigest(),tool=dict(path='/usr/bin/ccx',sha256=sha256(Path('/usr/bin/ccx').read_bytes()).hexdigest(),version_stdout=probe.stdout,version_stderr=probe.stderr),
    material=dict(E_Pa=200e9,nu=.3,actual_facing_grade_qualified=False),length_m=.5,width_m=.4,rows=rows,
    force_is_actual_magnetic_collapse_bound=False,physical_accepted=False)
assert SOURCE.read_bytes()==original
(OUT/'result.json').write_bytes(encoded(result))
m=dict(source_sha256={'worker.py':sha256(original).hexdigest()},files_sha256={p.relative_to(OUT).as_posix():sha256(p.read_bytes()).hexdigest() for p in OUT.rglob('*') if p.is_file()},physical_accepted=False)
(OUT/'manifest.json').write_bytes(encoded(m));print(json.dumps(result,sort_keys=True))
