"""Exact box counterexamples at one stated car/span pose; no swept/nativeCAD pass."""
from pathlib import Path
from hashlib import sha256
import gzip,json
ROOT=Path('/home/hayder/Documents/OpenSourceRail');OUT=ROOT/'build/physical-feasibility-round/guideway-clearance';OUT.mkdir(exist_ok=False)
SOURCE=Path(__file__);(OUT/'worker.py').write_bytes(SOURCE.read_bytes())
CAR='docs/design-engine/ferrite-maglev/comfort-design/design.json.gz'
GRID='build/physical-feasibility-round/guideway-v2/result.json.gz'
body=json.loads(gzip.decompress((ROOT/CAR).read_bytes()))['vehicle'];campaign=json.loads(gzip.decompress((ROOT/GRID).read_bytes()))
assert campaign['parent_vehicle_candidate_id']==body['candidate_id']
rows=[]
for case in campaign['cases']:
 if case['guideway_candidate_id'] not in campaign['pareto_candidate_ids']:continue
 d=case['physical_definition'];face_top=d['working_face_bottom_z_m']+d['facing_thickness_m'];top=face_top+d['new_head_depth_m'];rib=d.get('integral_crosshead_width_x_m')
 heads=[(0.,25.)] if rib is None else [(x-rib/2,x+rib/2) for x in d['integral_crosshead_centres_x_m']]
 shapes=[]
 for x0,x1 in heads:
  if x1<4. or x0>21.:continue
  # Exact material in the upper solid head is above every removed RHS/box
  # cavity (whose top is <=face_top+.158), and above the protection slot.
  assert face_top+.158 < -.90
  shapes.append(dict(id='solid-upper-head',at_m=[x0-12.5,-1.13,-.90],size_m=[x1-x0,2.26,top+.90]))
 hits=[]
 for part in body['geometry_parts']:
  if part.get('primitive',part.get('kind'))!='box':continue
  for shape in shapes:
   overlap=[max(0.,min(part['at_m'][i]+part['size_m'][i],shape['at_m'][i]+shape['size_m'][i])-max(part['at_m'][i],shape['at_m'][i])) for i in range(3)]
   volume=overlap[0]*overlap[1]*overlap[2]
   if volume>1e-12:
    hits.append(dict(material_part_id=part['id'],material_part_at_m=part['at_m'],material_part_size_m=part['size_m'],
      guideway_solid=shape,common_box_dimensions_m=overlap,positive_common_volume_m3=volume));break
 rows.append(dict(guideway_candidate_id=case['guideway_candidate_id'],family=d['family'],head_form='continuous' if rib is None else 'discrete-integral',
  pose=dict(car_centre_x_m_on_span=12.5,car_to_span_y_m=0.,car_to_span_z_m=0.,coupon_reference_gap_m=.012),
  tested_geometry='Only solid upper RChead vs exact selected material boxes; cylinders/remaininggeometry/sweptmotion not cleared',
  head_top_z_m=top,material_box_intersections=len(hits),counterexamples=hits,
  stated_pose_clearance_screen='fail' if hits else 'unknown',physical_accepted=False))
result=dict(schema='osr-guideway-material-box-counterexamples/1',parent_vehicle_candidate_id=body['candidate_id'],body_candidate_id=body['body_candidate_id'],magnet_component_id=body['magnet_component_id'],
 guideway_campaign_id=campaign['campaign_id'],source_sha256={CAR:sha256((ROOT/CAR).read_bytes()).hexdigest(),GRID:sha256((ROOT/GRID).read_bytes()).hexdigest()},
 scope='Definite positive-volume box/box collisions at one stated static pose; missing geometry or absent hits never imply clearance qualification',rows=rows,
 physical_accepted=False,default_configuration_changed=False)
(OUT/'result.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
(OUT/'manifest.json').write_text(json.dumps(dict(worker_sha256=sha256(SOURCE.read_bytes()).hexdigest(),files_sha256={p.name:sha256(p.read_bytes()).hexdigest() for p in OUT.iterdir() if p.is_file()},physical_accepted=False),sort_keys=True,indent=2)+'\n')
print([(r['family'],r['head_form'],r['material_box_intersections']) for r in rows])
