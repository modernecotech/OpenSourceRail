import sys,runpy
from pathlib import Path
sys.path[:0]=['/home/hayder/Documents/OpenSourceRail', '/home/hayder/Documents/OpenSourceRail/design/component-catalogue/src']
module=runpy.run_path('/home/hayder/Documents/OpenSourceRail/engineering/design_engine/native_cad.py')
module["native"]('/home/hayder/.local/state/opensourcerail/twin-workflow/2026-10-17-native-v2/runs/17580388375dce68f01682644df830e9f7d46338c099993042851a4de5255fad/artifacts/definition.json','/home/hayder/.local/state/opensourcerail/twin-workflow/2026-10-17-native-v2/runs/17580388375dce68f01682644df830e9f7d46338c099993042851a4de5255fad/artifacts/cad')
Path('/home/hayder/.local/state/opensourcerail/twin-workflow/2026-10-17-native-v2/runs/17580388375dce68f01682644df830e9f7d46338c099993042851a4de5255fad/artifacts/cad/completed').write_text("completed")
