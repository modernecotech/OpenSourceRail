import sys,runpy
from pathlib import Path
sys.path[:0]=['/home/hayder/Documents/OpenSourceRail', '/home/hayder/Documents/OpenSourceRail/design/component-catalogue/src']
module=runpy.run_path('/home/hayder/Documents/OpenSourceRail/engineering/design_engine/native_cad.py')
module["native"]('/home/hayder/.local/state/opensourcerail/twin-workflow/2026-10-17-native-v2/runs/e5e887eb5acd477c8c9824c0a14b2fb70e8cae4a999b192ef47d4f6ba9abff78/artifacts/definition.json','/home/hayder/.local/state/opensourcerail/twin-workflow/2026-10-17-native-v2/runs/e5e887eb5acd477c8c9824c0a14b2fb70e8cae4a999b192ef47d4f6ba9abff78/artifacts/cad')
Path('/home/hayder/.local/state/opensourcerail/twin-workflow/2026-10-17-native-v2/runs/e5e887eb5acd477c8c9824c0a14b2fb70e8cae4a999b192ef47d4f6ba9abff78/artifacts/cad/completed').write_text("completed")
