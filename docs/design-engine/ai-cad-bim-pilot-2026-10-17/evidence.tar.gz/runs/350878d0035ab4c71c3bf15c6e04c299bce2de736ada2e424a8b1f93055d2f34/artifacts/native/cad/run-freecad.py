import runpy
module=runpy.run_path('/home/hayder/Documents/OpenSourceRail/engineering/design_engine/generated_parts_native.py')
module['native_cad_export']('/home/hayder/.local/state/opensourcerail/twin-workflow/2026-10-17-native-v2/runs/350878d0035ab4c71c3bf15c6e04c299bce2de736ada2e424a8b1f93055d2f34/artifacts/native/cad/definition.json','/home/hayder/.local/state/opensourcerail/twin-workflow/2026-10-17-native-v2/runs/350878d0035ab4c71c3bf15c6e04c299bce2de736ada2e424a8b1f93055d2f34/artifacts/native/cad')
