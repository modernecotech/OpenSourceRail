import runpy
module=runpy.run_path('/home/hayder/Documents/OpenSourceRail/engineering/design_engine/generated_parts_native.py')
module['native_cad_export']('/home/hayder/.local/state/opensourcerail/twin-workflow/2026-10-17-native-v2/runs/6e3ec7c9ccffee7fe20e78820949f4fb2a86d2af5dd9198afb73f7d9eb194bb6/artifacts/native/cad/definition.json','/home/hayder/.local/state/opensourcerail/twin-workflow/2026-10-17-native-v2/runs/6e3ec7c9ccffee7fe20e78820949f4fb2a86d2af5dd9198afb73f7d9eb194bb6/artifacts/native/cad')
