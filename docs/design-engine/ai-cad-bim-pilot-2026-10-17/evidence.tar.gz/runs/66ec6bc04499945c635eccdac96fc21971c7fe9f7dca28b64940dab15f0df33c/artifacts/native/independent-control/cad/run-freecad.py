import runpy
module=runpy.run_path('/home/hayder/Documents/OpenSourceRail/engineering/design_engine/generated_parts_native.py')
module['native_cad_export']('/home/hayder/.local/state/opensourcerail/twin-workflow/2026-10-17-native-v2/runs/66ec6bc04499945c635eccdac96fc21971c7fe9f7dca28b64940dab15f0df33c/artifacts/native/independent-control/cad/definition.json','/home/hayder/.local/state/opensourcerail/twin-workflow/2026-10-17-native-v2/runs/66ec6bc04499945c635eccdac96fc21971c7fe9f7dca28b64940dab15f0df33c/artifacts/native/independent-control/cad')
