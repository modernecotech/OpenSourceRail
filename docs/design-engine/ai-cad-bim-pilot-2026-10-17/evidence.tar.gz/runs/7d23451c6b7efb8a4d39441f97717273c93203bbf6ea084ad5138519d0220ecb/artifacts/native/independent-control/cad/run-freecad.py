import runpy
module=runpy.run_path('/home/hayder/Documents/OpenSourceRail/engineering/design_engine/generated_parts_native.py')
module['native_cad_export']('/home/hayder/.local/state/opensourcerail/twin-workflow/2026-10-17-native-v2/runs/7d23451c6b7efb8a4d39441f97717273c93203bbf6ea084ad5138519d0220ecb/artifacts/native/independent-control/cad/definition.json','/home/hayder/.local/state/opensourcerail/twin-workflow/2026-10-17-native-v2/runs/7d23451c6b7efb8a4d39441f97717273c93203bbf6ea084ad5138519d0220ecb/artifacts/native/independent-control/cad')
