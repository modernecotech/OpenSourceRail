import runpy
module=runpy.run_path('/home/hayder/Documents/OpenSourceRail/engineering/design_engine/generated_parts_native.py')
module['native_cad_export']('/home/hayder/.local/state/opensourcerail/twin-workflow/2026-10-17-native-v2/runs/6599d35f3bebf1939a3c5b6fceecd678e7a0aece54ca2778a0318b3a8b248a65/artifacts/native/independent-control/cad/definition.json','/home/hayder/.local/state/opensourcerail/twin-workflow/2026-10-17-native-v2/runs/6599d35f3bebf1939a3c5b6fceecd678e7a0aece54ca2778a0318b3a8b248a65/artifacts/native/independent-control/cad')
