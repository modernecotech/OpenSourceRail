import sys,runpy
from pathlib import Path
sys.path[:0]=['/home/hayder/Documents/OpenSourceRail', '/home/hayder/Documents/OpenSourceRail/design/component-catalogue/src']
module=runpy.run_path('/home/hayder/Documents/OpenSourceRail/engineering/design_engine/native_cad.py')
module["native"]('/home/hayder/.local/state/opensourcerail/twin-workflow/2026-10-17-native-v2/runs/d3ad5594f4ea40579c80dc37ffdf30ee7572db8c58dcf5bf6f4a46f5988415ac/artifacts/definition.json','/home/hayder/.local/state/opensourcerail/twin-workflow/2026-10-17-native-v2/runs/d3ad5594f4ea40579c80dc37ffdf30ee7572db8c58dcf5bf6f4a46f5988415ac/artifacts/cad')
Path('/home/hayder/.local/state/opensourcerail/twin-workflow/2026-10-17-native-v2/runs/d3ad5594f4ea40579c80dc37ffdf30ee7572db8c58dcf5bf6f4a46f5988415ac/artifacts/cad/completed').write_text("completed")
