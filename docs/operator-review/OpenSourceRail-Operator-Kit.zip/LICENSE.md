# OpenSourceRail Licensing

OpenSourceRail uses a path-based multi-license model. The complete
license texts are tracked in [`LICENSES/`](https://github.com/modernecotech/OpenSourceRail/blob/main/LICENSES/README.md).

| Material | Default license |
|---|---|
| Software source, tests, scripts, and formal-model source | [Apache License 2.0](https://github.com/modernecotech/OpenSourceRail/blob/main/LICENSES/Apache-2.0.txt) |
| Hardware designs, mechanical CAD source/output, fabrication definitions, and assembly drawings | [CERN Open Hardware Licence Version 2 — Strongly Reciprocal](https://github.com/modernecotech/OpenSourceRail/blob/main/LICENSES/CERN-OHL-S-2.0.txt) |
| Documentation and original diagrams/media | [Creative Commons Attribution-ShareAlike 4.0 International](https://github.com/modernecotech/OpenSourceRail/blob/main/LICENSES/CC-BY-SA-4.0.txt) |

More-specific notices in a file or directory override this default.
Third-party inputs and generated artifacts retain their applicable
upstream terms. In particular, OpenStreetMap-derived data must preserve
its required attribution and database-license notices.

See [`LICENSES/README.md`](https://github.com/modernecotech/OpenSourceRail/blob/main/LICENSES/README.md) for the path mapping and
contribution rule.
