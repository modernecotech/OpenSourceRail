// Generated from quantities.json by capture-workforce.mjs
const workforceStudy = {
  "operating_options": {
    "metropolitan-mainlines": {
      "annual_grid_gwh": 1954.897475395032,
      "annual_train_km": 91968471.07579927,
      "infrastructure_network": "metropolitan",
      "initial_training_labour": {
        "cases": {
          "base": {
            "instructor_usd": 360981.25807692314,
            "learner_usd": 3771280.650769231,
            "mentor_usd": 1081579.005769231,
            "total_usd_m": 5.2138409146153855
          },
          "high": {
            "instructor_usd": 423760.5365384616,
            "learner_usd": 4427155.420769231,
            "mentor_usd": 1269679.4903846155,
            "total_usd_m": 6.120595447692309
          },
          "low": {
            "instructor_usd": 329591.61884615384,
            "learner_usd": 3443343.3638461535,
            "mentor_usd": 987528.7634615384,
            "total_usd_m": 4.760463746153845
          }
        },
        "classroom_instructor_hours": 42320,
        "field_mentor_hours": 126800,
        "learner_hours": 1014240,
        "learners": 6339,
        "maximum_learners_per_mentor": 4,
        "scope": "One initial GoA4 operating intake, within commissioning"
      },
      "iraq_payroll": {
        "basis": "Baghdad October 2026 construction wage proxies for local private-sector hires",
        "cases": {
          "base": {
            "assisted": {
              "annual_opex_usd_m_year": 787.1907997367998,
              "embedded_credit_usd_m_year": 42.63187284768212,
              "net_opex_delta_usd_m_year": 9.258997892317886,
              "payroll_usd_m_year": 51.890870740000004
            },
            "goa4": {
              "annual_opex_usd_m_year": 784.3265774567998,
              "embedded_credit_usd_m_year": 42.63187284768212,
              "net_opex_delta_usd_m_year": 6.394775612317886,
              "payroll_usd_m_year": 49.026648460000004
            },
            "loaded_usd_per_fte_year": {
              "OCC control, traction, incidents and information": 17741.99,
              "civil, track and power response": 14415.36,
              "depot rolling-stock technicians": 12197.62,
              "onboard commissioning supervisors": 17741.99,
              "onboard passenger assistants": 7762.12,
              "planning, payroll, stores and trainers": 11643.18,
              "scheduled onboard staff": 7762.12,
              "station duty and passenger assistance": 7762.12,
              "station security and cleaning": 4989.93
            },
            "rail_and_shift_premium": 0.15,
            "supervised": {
              "annual_opex_usd_m_year": 810.5137546967998,
              "embedded_credit_usd_m_year": 42.63187284768212,
              "net_opex_delta_usd_m_year": 32.58195285231788,
              "payroll_usd_m_year": 75.2138257
            }
          },
          "high": {
            "assisted": {
              "annual_opex_usd_m_year": 796.2152959167998,
              "embedded_credit_usd_m_year": 42.63187284768212,
              "net_opex_delta_usd_m_year": 18.283494072317886,
              "payroll_usd_m_year": 60.915366920000004
            },
            "goa4": {
              "annual_opex_usd_m_year": 792.8529494667998,
              "embedded_credit_usd_m_year": 42.63187284768212,
              "net_opex_delta_usd_m_year": 14.921147622317882,
              "payroll_usd_m_year": 57.55302047
            },
            "loaded_usd_per_fte_year": {
              "OCC control, traction, incidents and information": 20827.55,
              "civil, track and power response": 16922.38,
              "depot rolling-stock technicians": 14318.94,
              "onboard commissioning supervisors": 20827.55,
              "onboard passenger assistants": 9112.05,
              "planning, payroll, stores and trainers": 13668.08,
              "scheduled onboard staff": 9112.05,
              "station duty and passenger assistance": 9112.05,
              "station security and cleaning": 5857.75
            },
            "rail_and_shift_premium": 0.35,
            "supervised": {
              "annual_opex_usd_m_year": 823.5944132667998,
              "embedded_credit_usd_m_year": 42.63187284768212,
              "net_opex_delta_usd_m_year": 45.66261142231788,
              "payroll_usd_m_year": 88.29448427
            }
          },
          "low": {
            "assisted": {
              "annual_opex_usd_m_year": 782.6785510767997,
              "embedded_credit_usd_m_year": 42.63187284768212,
              "net_opex_delta_usd_m_year": 4.746749232317882,
              "payroll_usd_m_year": 47.37862208
            },
            "goa4": {
              "annual_opex_usd_m_year": 780.0633927267997,
              "embedded_credit_usd_m_year": 42.63187284768212,
              "net_opex_delta_usd_m_year": 2.13159088231788,
              "payroll_usd_m_year": 44.76346373
            },
            "loaded_usd_per_fte_year": {
              "OCC control, traction, incidents and information": 16199.21,
              "civil, track and power response": 13161.85,
              "depot rolling-stock technicians": 11136.95,
              "onboard commissioning supervisors": 16199.21,
              "onboard passenger assistants": 7087.15,
              "planning, payroll, stores and trainers": 10630.73,
              "scheduled onboard staff": 7087.15,
              "station duty and passenger assistance": 7087.15,
              "station security and cleaning": 4556.03
            },
            "rail_and_shift_premium": 0.05,
            "supervised": {
              "annual_opex_usd_m_year": 803.9734266867998,
              "embedded_credit_usd_m_year": 42.63187284768212,
              "net_opex_delta_usd_m_year": 26.041624842317873,
              "payroll_usd_m_year": 68.67349768999999
            }
          }
        },
        "currency": {
          "basis": "Central Bank selling rate to banks used for project translation",
          "effective_date": "2026-10-07",
          "iqd_per_usd": 1510,
          "source": "https://cbi.iq/news/view/3355"
        },
        "employer_social_insurance_share": 0.12,
        "estimated_credit_by_envelope_usd_m_year": {
          "Non-energy train operations": 9.898228697571744,
          "Power maintenance": 1.7883408388520972,
          "Station operations": 30.94530331125828
        },
        "paid_days_year": 260,
        "proxy_daily_iqd": {
          "OCC control, traction, incidents and information": 80000,
          "civil, track and power response": 65000,
          "depot rolling-stock technicians": 55000,
          "onboard commissioning supervisors": 80000,
          "onboard passenger assistants": 35000,
          "planning, payroll, stores and trainers": 52500,
          "scheduled onboard staff": 35000,
          "station duty and passenger assistance": 35000,
          "station security and cleaning": 22500
        }
      },
      "opex": {
        "baseline_usd_m_year": 777.9318018444819,
        "eligible_envelopes_usd_m_year": {
          "Non-energy train operations": 239.1180247970781,
          "Power maintenance": 24.226080000000003,
          "Station operations": 280
        },
        "embedded_payroll_usd_m_year": null,
        "operator_pay_rates_usd_per_fte_year": null,
        "other_costs_usd_m_year": 234.58769704740382
      },
      "source_diagram_evaluation_id": "5ee1a40e7375cf32c7c97b3a0aeed48a046f07482856d183d8c09d73645d4741",
      "source_evaluation_id": "54c45fc9feb942bd0f63b2d9aaf4688cb794409801793967f047050e61586db3",
      "source_physical_id": "28d1d23756788171634dbf3ac50dbbae0254f4ca9cd5b732821ae9a88635408c",
      "train_hours_day_including_minimum_turns": 6951.086666666667,
      "workforce_scenarios": {
        "assisted": {
          "duty_hours_per_year": {
            "OCC control, traction, incidents and information": 140160,
            "civil, track and power response": 735840,
            "depot rolling-stock technicians": 700800,
            "onboard passenger assistants": 634287,
            "planning, payroll, stores and trainers": 123840,
            "station duty and passenger assistance": 5518800,
            "station security and cleaning": 3679200
          },
          "name": "Onboard passenger assistance",
          "onboard_duty_fraction": 0.25,
          "onboard_role": "onboard passenger assistants",
          "posts_fte": {
            "OCC control, traction, incidents and information": 82,
            "civil, track and power response": 428,
            "depot rolling-stock technicians": 408,
            "onboard passenger assistants": 369,
            "planning, payroll, stores and trainers": 72,
            "station duty and passenger assistance": 3209,
            "station security and cleaning": 2140
          },
          "total_fte": 6708,
          "train_duty_basis": "All 14 routes have timed workings, totalling 6,951.1 train-hours/day including minimum turns. 5 access sections are deferred. The full 280-station and 934-set capital programme and built line upkeep are retained."
        },
        "goa4": {
          "duty_hours_per_year": {
            "OCC control, traction, incidents and information": 140160,
            "civil, track and power response": 735840,
            "depot rolling-stock technicians": 700800,
            "planning, payroll, stores and trainers": 123840,
            "scheduled onboard staff": 0,
            "station duty and passenger assistance": 5518800,
            "station security and cleaning": 3679200
          },
          "name": "Unattended GoA4",
          "onboard_duty_fraction": 0,
          "onboard_role": "scheduled onboard staff",
          "posts_fte": {
            "OCC control, traction, incidents and information": 82,
            "civil, track and power response": 428,
            "depot rolling-stock technicians": 408,
            "planning, payroll, stores and trainers": 72,
            "scheduled onboard staff": 0,
            "station duty and passenger assistance": 3209,
            "station security and cleaning": 2140
          },
          "total_fte": 6339,
          "train_duty_basis": "All 14 routes have timed workings, totalling 6,951.1 train-hours/day including minimum turns. 5 access sections are deferred. The full 280-station and 934-set capital programme and built line upkeep are retained."
        },
        "supervised": {
          "duty_hours_per_year": {
            "OCC control, traction, incidents and information": 140160,
            "civil, track and power response": 735840,
            "depot rolling-stock technicians": 700800,
            "onboard commissioning supervisors": 2537147,
            "planning, payroll, stores and trainers": 123840,
            "station duty and passenger assistance": 5518800,
            "station security and cleaning": 3679200
          },
          "name": "Supervised commissioning",
          "onboard_duty_fraction": 1,
          "onboard_role": "onboard commissioning supervisors",
          "posts_fte": {
            "OCC control, traction, incidents and information": 82,
            "civil, track and power response": 428,
            "depot rolling-stock technicians": 408,
            "onboard commissioning supervisors": 1476,
            "planning, payroll, stores and trainers": 72,
            "station duty and passenger assistance": 3209,
            "station security and cleaning": 2140
          },
          "total_fte": 7815,
          "train_duty_basis": "All 14 routes have timed workings, totalling 6,951.1 train-hours/day including minimum turns. 5 access sections are deferred. The full 280-station and 934-set capital programme and built line upkeep are retained."
        }
      }
    }
  },
  "schema": "osr.factory-workforce.study.4",
  "source_sha256": {
    "cities/Baghdad/iraq-market.toml": "f044ba071d77b58b2427384954f5bfdf3713b48c2ba5af872e1f24c53fd3ee2b",
    "cities/Baghdad/service-diagrams.json": "37fab32fe7b04570ee7a521101d3807291173db545082660d00de190b1663ccb",
    "cities/Baghdad/system-results.json": "be01359239e9b97efdae45822628688ffb1225a17afd36df136aaffb0928c06e",
    "cities/Baghdad/system.toml": "5a847f9bf78cb1ad0ed81a66136a511cce39a5ee0bc99bb20d35717da848a035",
    "docs/operator-review/delivery/calculate.py": "e69287d7f29cf58763363d5053719f6f86048de6268990b4785be899a33edc89",
    "docs/reference-v07/concept.toml": "033849bb4db3a0b28adb5a345a39601330f5160cd8c100a4dd4b790123485a18",
    "docs/reference-v07/cost/README.md": "f7d799e4f954d4bec341ed63b457e2c6918e07546a875349569cc1aefae9a75d",
    "docs/reference-v07/digital/production/handoff.json": "c8f89fd421e9413ddbe6ef4b934c153469b0a87f1ed54d8761a1d57c77512a4c",
    "docs/reference-v07/integration/timetable.py": "955867f78178e7eaabcd5bba5b1092268bb3893a6fb6c324cd1c7f32656bf671"
  },
  "status": "capacity and quotation study",
  "studies": {
    "core": {
      "civil": {
        "beams": 6000,
        "civil_yard_day_posts": 36,
        "erection_day_posts": 16,
        "erection_fronts": 2,
        "minimum_pre_erection_stock_per_yard": 440,
        "off_yard_slots_needed_per_yard": 260,
        "yards": 2
      },
      "opex": {
        "baseline_usd_m_year": 30.495,
        "eligible_envelopes_usd_m_year": {
          "Civil, station and overhead maintenance": 6,
          "Control and operations staff": 4,
          "Fleet maintenance": 10,
          "Insurance and administration": 3
        },
        "embedded_payroll_usd_m_year": null,
        "operator_pay_rates_usd_per_fte_year": null,
        "other_costs_usd_m_year": 7.495000000000001
      },
      "production_day_posts": 202,
      "roster": {
        "duty_hours_per_year": {
          "OCC control, traction, incidents and information": 35040,
          "civil, track and power response": 35040,
          "depot rolling-stock technicians": 58400,
          "planning, payroll, stores and trainers": 10320,
          "station duty and passenger assistance": 236520,
          "station security and cleaning": 157680,
          "train operators": 156220
        },
        "field_groups": 1,
        "posts_fte": {
          "OCC control, traction, incidents and information": 21,
          "civil, track and power response": 21,
          "depot rolling-stock technicians": 34,
          "planning, payroll, stores and trainers": 6,
          "station duty and passenger assistance": 138,
          "station security and cleaning": 92,
          "train operators": 91
        },
        "total_fte": 403,
        "train_operator_hours_per_day": 428
      },
      "source_diagram_evaluation_id": "66624c217e2ee50fbc6acb9850609d35a3e5632fbd2e02f6bfe33c91e1e6366b",
      "source_evaluation_id": "63dbda54f7498fcd3a2e390fe37571fb6049fa39c02f9640fe39e15d70560dbc",
      "source_physical_id": "osr-v07-joined-civil-518dad57a3af5046f40c8f4f",
      "source_selection_id": "osr-v07-digital-design-20261117",
      "train_hours_day_including_minimum_turns": 413.8,
      "vehicle": {
        "cars": 306,
        "cars_capacity": 380,
        "cars_per_line_in_window": 76,
        "direct_content_hours": 220320,
        "direct_content_job_years_at_1720_hours": 128.1,
        "direct_posts_all_lines": 130,
        "direct_posts_by_stage": {
          "HVAC and auxiliaries": 3,
          "body": 9,
          "bogies and drive": 4,
          "doors and interior": 3,
          "marriage and test": 3,
          "wiring, collection and cooling": 4
        },
        "direct_posts_per_line": 26,
        "effective_line_days": 408,
        "first_car_effective_day": 30,
        "hours_per_car_by_stage": {
          "HVAC and auxiliaries": 80,
          "body": 260,
          "bogies and drive": 120,
          "doors and interior": 80,
          "marriage and test": 80,
          "wiring, collection and cooling": 100
        },
        "lines": 5,
        "scheduled_workdays": 480,
        "support_posts_all_lines": 20,
        "takt_effective_days": 5
      },
      "workforce_scenarios": {
        "assisted": {
          "duty_hours_per_year": {
            "OCC control, traction, incidents and information": 35040,
            "civil, track and power response": 35040,
            "depot rolling-stock technicians": 58400,
            "onboard passenger assistants": 37760,
            "planning, payroll, stores and trainers": 10320,
            "station duty and passenger assistance": 236520,
            "station security and cleaning": 157680
          },
          "name": "Onboard passenger assistance",
          "onboard_duty_fraction": 0.25,
          "onboard_role": "onboard passenger assistants",
          "posts_fte": {
            "OCC control, traction, incidents and information": 21,
            "civil, track and power response": 21,
            "depot rolling-stock technicians": 34,
            "onboard passenger assistants": 22,
            "planning, payroll, stores and trainers": 6,
            "station duty and passenger assistance": 138,
            "station security and cleaning": 92
          },
          "total_fte": 334,
          "train_duty_basis": "576 daily train workings account for 385.0 passenger train-hours and 28.8 minimum turnback hours. Each onboard duty still needs crew relief, stabling moves and handover."
        },
        "goa4": {
          "duty_hours_per_year": {
            "OCC control, traction, incidents and information": 35040,
            "civil, track and power response": 35040,
            "depot rolling-stock technicians": 58400,
            "planning, payroll, stores and trainers": 10320,
            "scheduled onboard staff": 0,
            "station duty and passenger assistance": 236520,
            "station security and cleaning": 157680
          },
          "name": "Unattended GoA4",
          "onboard_duty_fraction": 0,
          "onboard_role": "scheduled onboard staff",
          "posts_fte": {
            "OCC control, traction, incidents and information": 21,
            "civil, track and power response": 21,
            "depot rolling-stock technicians": 34,
            "planning, payroll, stores and trainers": 6,
            "scheduled onboard staff": 0,
            "station duty and passenger assistance": 138,
            "station security and cleaning": 92
          },
          "total_fte": 312,
          "train_duty_basis": "576 daily train workings account for 385.0 passenger train-hours and 28.8 minimum turnback hours. Each onboard duty still needs crew relief, stabling moves and handover."
        },
        "supervised": {
          "duty_hours_per_year": {
            "OCC control, traction, incidents and information": 35040,
            "civil, track and power response": 35040,
            "depot rolling-stock technicians": 58400,
            "onboard commissioning supervisors": 151037,
            "planning, payroll, stores and trainers": 10320,
            "station duty and passenger assistance": 236520,
            "station security and cleaning": 157680
          },
          "name": "Supervised commissioning",
          "onboard_duty_fraction": 1,
          "onboard_role": "onboard commissioning supervisors",
          "posts_fte": {
            "OCC control, traction, incidents and information": 21,
            "civil, track and power response": 21,
            "depot rolling-stock technicians": 34,
            "onboard commissioning supervisors": 88,
            "planning, payroll, stores and trainers": 6,
            "station duty and passenger assistance": 138,
            "station security and cleaning": 92
          },
          "total_fte": 400,
          "train_duty_basis": "576 daily train workings account for 385.0 passenger train-hours and 28.8 minimum turnback hours. Each onboard duty still needs crew relief, stabling moves and handover."
        }
      }
    },
    "first": {
      "civil": {
        "beams": 29640,
        "civil_yard_day_posts": 108,
        "erection_day_posts": 48,
        "erection_fronts": 6,
        "peak_month_end_total_inventory": 983,
        "slots_per_yard_if_balanced": 164,
        "slots_per_yard_offered": 180,
        "yards": 6
      },
      "initial_training_labour": {
        "cases": {
          "base": {
            "instructor_usd": 87345.18153846155,
            "learner_usd": 944120.9846153846,
            "mentor_usd": 260670.77615384618,
            "total_usd_m": 1.2921369423076923
          },
          "high": {
            "instructor_usd": 102535.63076923077,
            "learner_usd": 1108315.886153846,
            "mentor_usd": 306004.7730769231,
            "total_usd_m": 1.51685629
          },
          "low": {
            "instructor_usd": 79749.95692307691,
            "learner_usd": 862023.523076923,
            "mentor_usd": 238003.77769230766,
            "total_usd_m": 1.1797772576923078
          }
        },
        "classroom_instructor_hours": 10240,
        "field_mentor_hours": 30560,
        "learner_hours": 244160,
        "learners": 1526,
        "maximum_learners_per_mentor": 4,
        "scope": "One initial GoA4 operating intake, within commissioning"
      },
      "iraq_payroll": {
        "basis": "Baghdad October 2026 construction wage proxies for local private-sector hires",
        "cases": {
          "base": {
            "assisted": {
              "annual_opex_usd_m_year": 199.3786631505817,
              "embedded_credit_usd_m_year": 10.672672847682122,
              "net_opex_delta_usd_m_year": 2.4003983123178774,
              "payroll_usd_m_year": 13.07307116
            },
            "goa4": {
              "annual_opex_usd_m_year": 198.5791647905817,
              "embedded_credit_usd_m_year": 10.672672847682122,
              "net_opex_delta_usd_m_year": 1.600899952317878,
              "payroll_usd_m_year": 12.2735728
            },
            "loaded_usd_per_fte_year": {
              "OCC control, traction, incidents and information": 17741.99,
              "civil, track and power response": 14415.36,
              "depot rolling-stock technicians": 12197.62,
              "onboard commissioning supervisors": 17741.99,
              "onboard passenger assistants": 7762.12,
              "planning, payroll, stores and trainers": 11643.18,
              "scheduled onboard staff": 7762.12,
              "station duty and passenger assistance": 7762.12,
              "station security and cleaning": 4989.93
            },
            "rail_and_shift_premium": 0.15,
            "supervised": {
              "annual_opex_usd_m_year": 205.88886467058168,
              "embedded_credit_usd_m_year": 10.672672847682122,
              "net_opex_delta_usd_m_year": 8.910599832317878,
              "payroll_usd_m_year": 19.58327268
            }
          },
          "high": {
            "assisted": {
              "annual_opex_usd_m_year": 201.6522396605817,
              "embedded_credit_usd_m_year": 10.672672847682122,
              "net_opex_delta_usd_m_year": 4.673974822317877,
              "payroll_usd_m_year": 15.34664767
            },
            "goa4": {
              "annual_opex_usd_m_year": 200.71369851058168,
              "embedded_credit_usd_m_year": 10.672672847682122,
              "net_opex_delta_usd_m_year": 3.7354336723178765,
              "payroll_usd_m_year": 14.408106519999999
            },
            "loaded_usd_per_fte_year": {
              "OCC control, traction, incidents and information": 20827.55,
              "civil, track and power response": 16922.38,
              "depot rolling-stock technicians": 14318.94,
              "onboard commissioning supervisors": 20827.55,
              "onboard passenger assistants": 9112.05,
              "planning, payroll, stores and trainers": 13668.08,
              "scheduled onboard staff": 9112.05,
              "station duty and passenger assistance": 9112.05,
              "station security and cleaning": 5857.75
            },
            "rail_and_shift_premium": 0.35,
            "supervised": {
              "annual_opex_usd_m_year": 209.2946491105817,
              "embedded_credit_usd_m_year": 10.672672847682122,
              "net_opex_delta_usd_m_year": 12.316384272317876,
              "payroll_usd_m_year": 22.98905712
            }
          },
          "low": {
            "assisted": {
              "annual_opex_usd_m_year": 198.2418742405817,
              "embedded_credit_usd_m_year": 10.672672847682122,
              "net_opex_delta_usd_m_year": 1.2636094023178774,
              "payroll_usd_m_year": 11.93628225
            },
            "goa4": {
              "annual_opex_usd_m_year": 197.51189779058168,
              "embedded_credit_usd_m_year": 10.672672847682122,
              "net_opex_delta_usd_m_year": 0.5336329523178769,
              "payroll_usd_m_year": 11.206305799999999
            },
            "loaded_usd_per_fte_year": {
              "OCC control, traction, incidents and information": 16199.21,
              "civil, track and power response": 13161.85,
              "depot rolling-stock technicians": 11136.95,
              "onboard commissioning supervisors": 16199.21,
              "onboard passenger assistants": 7087.15,
              "planning, payroll, stores and trainers": 10630.73,
              "scheduled onboard staff": 7087.15,
              "station duty and passenger assistance": 7087.15,
              "station security and cleaning": 4556.03
            },
            "rail_and_shift_premium": 0.05,
            "supervised": {
              "annual_opex_usd_m_year": 204.1859723105817,
              "embedded_credit_usd_m_year": 10.672672847682122,
              "net_opex_delta_usd_m_year": 7.207707472317878,
              "payroll_usd_m_year": 17.88038032
            }
          }
        },
        "currency": {
          "basis": "Central Bank selling rate to banks used for project translation",
          "effective_date": "2026-10-07",
          "iqd_per_usd": 1510,
          "source": "https://cbi.iq/news/view/3355"
        },
        "employer_social_insurance_share": 0.12,
        "estimated_credit_by_envelope_usd_m_year": {
          "Non-energy train operations": 3.1704158940397353,
          "Power maintenance": 0.4261933774834437,
          "Station operations": 7.076063576158942
        },
        "paid_days_year": 260,
        "proxy_daily_iqd": {
          "OCC control, traction, incidents and information": 80000,
          "civil, track and power response": 65000,
          "depot rolling-stock technicians": 55000,
          "onboard commissioning supervisors": 80000,
          "onboard passenger assistants": 35000,
          "planning, payroll, stores and trainers": 52500,
          "scheduled onboard staff": 35000,
          "station duty and passenger assistance": 35000,
          "station security and cleaning": 22500
        }
      },
      "opex": {
        "baseline_usd_m_year": 196.9782648382638,
        "eligible_envelopes_usd_m_year": {
          "Non-energy train operations": 64.13266080000001,
          "Power maintenance": 5.928,
          "Station operations": 64
        },
        "embedded_payroll_usd_m_year": null,
        "operator_pay_rates_usd_per_fte_year": null,
        "other_costs_usd_m_year": 62.91760403826379
      },
      "production_day_posts": 624,
      "roster": {
        "duty_hours_per_year": {
          "OCC control, traction, incidents and information": 70080,
          "civil, track and power response": 175200,
          "depot rolling-stock technicians": 233600,
          "planning, payroll, stores and trainers": 41280,
          "station duty and passenger assistance": 1261440,
          "station security and cleaning": 840960,
          "train operators": 729270
        },
        "field_groups": 5,
        "posts_fte": {
          "OCC control, traction, incidents and information": 41,
          "civil, track and power response": 102,
          "depot rolling-stock technicians": 136,
          "planning, payroll, stores and trainers": 24,
          "station duty and passenger assistance": 734,
          "station security and cleaning": 489,
          "train operators": 424
        },
        "total_fte": 1950,
        "train_operator_hours_per_day": 1998
      },
      "source_diagram_evaluation_id": "5ee1a40e7375cf32c7c97b3a0aeed48a046f07482856d183d8c09d73645d4741",
      "source_evaluation_id": "12d4630a9c69a023b7c538c6b9a7413b38622697b7c127db6839d89d93170054",
      "source_physical_id": "f6844cd4d9f5d9320fa421b37eb074b9911d3cd695d350fdc464cc3597184a72",
      "vehicle": {
        "cars": 1452,
        "cars_capacity": 1464,
        "cars_per_line_in_window": 122,
        "direct_assembly_labour": {
          "cars_order": 1452,
          "cars_per_train": 6,
          "cases": {
            "base": {
              "usd_by_stage_per_car": {
                "HVAC and auxiliaries": 978.4183872224388,
                "body": 2755.878457343202,
                "bogies and drive": 1467.6275808336582,
                "doors and interior": 2331.897156213479,
                "marriage and test": 994.7253603428128,
                "wiring, collection and cooling": 2446.045968056097
              },
              "usd_m_order": 15.935108905336971,
              "usd_per_car": 10974.592910011688,
              "usd_per_train": 65847.55746007012
            },
            "high": {
              "usd_by_stage_per_car": {
                "HVAC and auxiliaries": 1148.5781067393848,
                "body": 3235.1616673159338,
                "bogies and drive": 1722.8671601090773,
                "doors and interior": 2737.444487728867,
                "marriage and test": 1167.7210751850412,
                "wiring, collection and cooling": 2871.445266848462
              },
              "usd_m_order": 18.706432193221666,
              "usd_per_car": 12883.217763926767,
              "usd_per_train": 77299.3065835606
            },
            "low": {
              "usd_by_stage_per_car": {
                "HVAC and auxiliaries": 893.338527463966,
                "body": 2516.2368523568375,
                "bogies and drive": 1340.0077911959488,
                "doors and interior": 2129.1234904557855,
                "marriage and test": 908.2275029216987,
                "wiring, collection and cooling": 2233.3463186599147
              },
              "usd_m_order": 14.54944726139463,
              "usd_per_car": 10020.280483054152,
              "usd_per_train": 60121.682898324914
            }
          },
          "hours_per_car": 1000,
          "productive_hours_per_employee_year": 1360,
          "proxy_daily_iqd_by_stage": {
            "HVAC and auxiliaries": 75000,
            "body": 65000,
            "bogies and drive": 75000,
            "doors and interior": 55000,
            "marriage and test": 76250,
            "wiring, collection and cooling": 75000
          },
          "scope": "Direct repeat assembly labour within train purchase"
        },
        "direct_content_hours": 1452000,
        "direct_content_job_years_at_1720_hours": 844.2,
        "direct_posts_all_lines": 420,
        "direct_posts_by_stage": {
          "HVAC and auxiliaries": 3,
          "body": 9,
          "bogies and drive": 4,
          "doors and interior": 9,
          "marriage and test": 3,
          "wiring, collection and cooling": 7
        },
        "direct_posts_per_line": 35,
        "effective_line_days": 637,
        "first_car_effective_day": 30,
        "hours_per_car_by_stage": {
          "HVAC and auxiliaries": 80,
          "body": 260,
          "bogies and drive": 120,
          "doors and interior": 260,
          "marriage and test": 80,
          "wiring, collection and cooling": 200
        },
        "lines": 12,
        "scheduled_workdays": 750,
        "support_posts_all_lines": 48,
        "takt_effective_days": 5
      },
      "workforce_scenarios": {
        "assisted": {
          "duty_hours_per_year": {
            "OCC control, traction, incidents and information": 70080,
            "civil, track and power response": 175200,
            "depot rolling-stock technicians": 233600,
            "onboard passenger assistants": 176878,
            "planning, payroll, stores and trainers": 41280,
            "station duty and passenger assistance": 1261440,
            "station security and cleaning": 840960
          },
          "name": "Onboard passenger assistance",
          "onboard_duty_fraction": 0.25,
          "onboard_role": "onboard passenger assistants",
          "posts_fte": {
            "OCC control, traction, incidents and information": 41,
            "civil, track and power response": 102,
            "depot rolling-stock technicians": 136,
            "onboard passenger assistants": 103,
            "planning, payroll, stores and trainers": 24,
            "station duty and passenger assistance": 734,
            "station security and cleaning": 489
          },
          "total_fte": 1629,
          "train_duty_basis": "1,938.4 diagrammed train-hours/day including minimum turnbacks."
        },
        "goa4": {
          "duty_hours_per_year": {
            "OCC control, traction, incidents and information": 70080,
            "civil, track and power response": 175200,
            "depot rolling-stock technicians": 233600,
            "planning, payroll, stores and trainers": 41280,
            "scheduled onboard staff": 0,
            "station duty and passenger assistance": 1261440,
            "station security and cleaning": 840960
          },
          "name": "Unattended GoA4",
          "onboard_duty_fraction": 0,
          "onboard_role": "scheduled onboard staff",
          "posts_fte": {
            "OCC control, traction, incidents and information": 41,
            "civil, track and power response": 102,
            "depot rolling-stock technicians": 136,
            "planning, payroll, stores and trainers": 24,
            "scheduled onboard staff": 0,
            "station duty and passenger assistance": 734,
            "station security and cleaning": 489
          },
          "total_fte": 1526,
          "train_duty_basis": "1,938.4 diagrammed train-hours/day including minimum turnbacks."
        },
        "supervised": {
          "duty_hours_per_year": {
            "OCC control, traction, incidents and information": 70080,
            "civil, track and power response": 175200,
            "depot rolling-stock technicians": 233600,
            "onboard commissioning supervisors": 707509,
            "planning, payroll, stores and trainers": 41280,
            "station duty and passenger assistance": 1261440,
            "station security and cleaning": 840960
          },
          "name": "Supervised commissioning",
          "onboard_duty_fraction": 1,
          "onboard_role": "onboard commissioning supervisors",
          "posts_fte": {
            "OCC control, traction, incidents and information": 41,
            "civil, track and power response": 102,
            "depot rolling-stock technicians": 136,
            "onboard commissioning supervisors": 412,
            "planning, payroll, stores and trainers": 24,
            "station duty and passenger assistance": 734,
            "station security and cleaning": 489
          },
          "total_fte": 1938,
          "train_duty_basis": "1,938.4 diagrammed train-hours/day including minimum turnbacks."
        }
      }
    },
    "metropolitan": {
      "civil": {
        "beams": 121156,
        "civil_yard_day_posts": 180,
        "erection_day_posts": 80,
        "erection_fronts": 10,
        "peak_month_end_total_inventory": 1638,
        "slots_per_yard_if_balanced": 164,
        "slots_per_yard_offered": 180,
        "yards": 10
      },
      "initial_training_labour": {
        "cases": {
          "base": {
            "instructor_usd": 360981.25807692314,
            "learner_usd": 3771280.650769231,
            "mentor_usd": 1081579.005769231,
            "total_usd_m": 5.2138409146153855
          },
          "high": {
            "instructor_usd": 423760.5365384616,
            "learner_usd": 4427155.420769231,
            "mentor_usd": 1269679.4903846155,
            "total_usd_m": 6.120595447692309
          },
          "low": {
            "instructor_usd": 329591.61884615384,
            "learner_usd": 3443343.3638461535,
            "mentor_usd": 987528.7634615384,
            "total_usd_m": 4.760463746153845
          }
        },
        "classroom_instructor_hours": 42320,
        "field_mentor_hours": 126800,
        "learner_hours": 1014240,
        "learners": 6339,
        "maximum_learners_per_mentor": 4,
        "scope": "One initial GoA4 operating intake, within commissioning"
      },
      "iraq_payroll": {
        "basis": "Baghdad October 2026 construction wage proxies for local private-sector hires",
        "cases": {
          "base": {
            "assisted": {
              "annual_opex_usd_m_year": 789.7777344732223,
              "embedded_credit_usd_m_year": 42.63187284768212,
              "net_opex_delta_usd_m_year": 9.282284252317886,
              "payroll_usd_m_year": 51.914157100000004
            },
            "goa4": {
              "annual_opex_usd_m_year": 786.8902258332222,
              "embedded_credit_usd_m_year": 42.63187284768212,
              "net_opex_delta_usd_m_year": 6.394775612317886,
              "payroll_usd_m_year": 49.026648460000004
            },
            "loaded_usd_per_fte_year": {
              "OCC control, traction, incidents and information": 17741.99,
              "civil, track and power response": 14415.36,
              "depot rolling-stock technicians": 12197.62,
              "onboard commissioning supervisors": 17741.99,
              "onboard passenger assistants": 7762.12,
              "planning, payroll, stores and trainers": 11643.18,
              "scheduled onboard staff": 7762.12,
              "station duty and passenger assistance": 7762.12,
              "station security and cleaning": 4989.93
            },
            "rail_and_shift_premium": 0.15,
            "supervised": {
              "annual_opex_usd_m_year": 813.2903069532222,
              "embedded_credit_usd_m_year": 42.63187284768212,
              "net_opex_delta_usd_m_year": 32.79485673231788,
              "payroll_usd_m_year": 75.42672958
            }
          },
          "high": {
            "assisted": {
              "annual_opex_usd_m_year": 798.8062804432222,
              "embedded_credit_usd_m_year": 42.63187284768212,
              "net_opex_delta_usd_m_year": 18.310830222317882,
              "payroll_usd_m_year": 60.94270307
            },
            "goa4": {
              "annual_opex_usd_m_year": 795.4165978432222,
              "embedded_credit_usd_m_year": 42.63187284768212,
              "net_opex_delta_usd_m_year": 14.921147622317882,
              "payroll_usd_m_year": 57.55302047
            },
            "loaded_usd_per_fte_year": {
              "OCC control, traction, incidents and information": 20827.55,
              "civil, track and power response": 16922.38,
              "depot rolling-stock technicians": 14318.94,
              "onboard commissioning supervisors": 20827.55,
              "onboard passenger assistants": 9112.05,
              "planning, payroll, stores and trainers": 13668.08,
              "scheduled onboard staff": 9112.05,
              "station duty and passenger assistance": 9112.05,
              "station security and cleaning": 5857.75
            },
            "rail_and_shift_premium": 0.35,
            "supervised": {
              "annual_opex_usd_m_year": 826.4079922432222,
              "embedded_credit_usd_m_year": 42.63187284768212,
              "net_opex_delta_usd_m_year": 45.91254202231789,
              "payroll_usd_m_year": 88.54441487000001
            }
          },
          "low": {
            "assisted": {
              "annual_opex_usd_m_year": 785.2634609032223,
              "embedded_credit_usd_m_year": 42.63187284768212,
              "net_opex_delta_usd_m_year": 4.768010682317879,
              "payroll_usd_m_year": 47.39988353
            },
            "goa4": {
              "annual_opex_usd_m_year": 782.6270411032222,
              "embedded_credit_usd_m_year": 42.63187284768212,
              "net_opex_delta_usd_m_year": 2.13159088231788,
              "payroll_usd_m_year": 44.76346373
            },
            "loaded_usd_per_fte_year": {
              "OCC control, traction, incidents and information": 16199.21,
              "civil, track and power response": 13161.85,
              "depot rolling-stock technicians": 11136.95,
              "onboard commissioning supervisors": 16199.21,
              "onboard passenger assistants": 7087.15,
              "planning, payroll, stores and trainers": 10630.73,
              "scheduled onboard staff": 7087.15,
              "station duty and passenger assistance": 7087.15,
              "station security and cleaning": 4556.03
            },
            "rail_and_shift_premium": 0.05,
            "supervised": {
              "annual_opex_usd_m_year": 806.7314655832222,
              "embedded_credit_usd_m_year": 42.63187284768212,
              "net_opex_delta_usd_m_year": 26.236015362317872,
              "payroll_usd_m_year": 68.86788820999999
            }
          }
        },
        "currency": {
          "basis": "Central Bank selling rate to banks used for project translation",
          "effective_date": "2026-10-07",
          "iqd_per_usd": 1510,
          "source": "https://cbi.iq/news/view/3355"
        },
        "employer_social_insurance_share": 0.12,
        "estimated_credit_by_envelope_usd_m_year": {
          "Non-energy train operations": 9.898228697571744,
          "Power maintenance": 1.7883408388520972,
          "Station operations": 30.94530331125828
        },
        "paid_days_year": 260,
        "proxy_daily_iqd": {
          "OCC control, traction, incidents and information": 80000,
          "civil, track and power response": 65000,
          "depot rolling-stock technicians": 55000,
          "onboard commissioning supervisors": 80000,
          "onboard passenger assistants": 35000,
          "planning, payroll, stores and trainers": 52500,
          "scheduled onboard staff": 35000,
          "station duty and passenger assistance": 35000,
          "station security and cleaning": 22500
        }
      },
      "opex": {
        "baseline_usd_m_year": 780.4954502209043,
        "eligible_envelopes_usd_m_year": {
          "Non-energy train operations": 240.4121078274824,
          "Power maintenance": 24.226080000000003,
          "Station operations": 280
        },
        "embedded_payroll_usd_m_year": null,
        "operator_pay_rates_usd_per_fte_year": null,
        "other_costs_usd_m_year": 235.85726239342193
      },
      "production_day_posts": 1040,
      "roster": {
        "duty_hours_per_year": {
          "OCC control, traction, incidents and information": 140160,
          "civil, track and power response": 735840,
          "depot rolling-stock technicians": 700800,
          "planning, payroll, stores and trainers": 123840,
          "station duty and passenger assistance": 5518800,
          "station security and cleaning": 3679200,
          "train operators": 2815610
        },
        "field_groups": 21,
        "posts_fte": {
          "OCC control, traction, incidents and information": 82,
          "civil, track and power response": 428,
          "depot rolling-stock technicians": 408,
          "planning, payroll, stores and trainers": 72,
          "station duty and passenger assistance": 3209,
          "station security and cleaning": 2140,
          "train operators": 1637
        },
        "total_fte": 7976,
        "train_operator_hours_per_day": 7714
      },
      "source_diagram_evaluation_id": "5ee1a40e7375cf32c7c97b3a0aeed48a046f07482856d183d8c09d73645d4741",
      "source_evaluation_id": "54c45fc9feb942bd0f63b2d9aaf4688cb794409801793967f047050e61586db3",
      "source_physical_id": "28d1d23756788171634dbf3ac50dbbae0254f4ca9cd5b732821ae9a88635408c",
      "vehicle": {
        "cars": 5604,
        "cars_capacity": 5840,
        "cars_per_line_in_window": 292,
        "direct_assembly_labour": {
          "cars_order": 5604,
          "cars_per_train": 6,
          "cases": {
            "base": {
              "usd_by_stage_per_car": {
                "HVAC and auxiliaries": 978.4183872224388,
                "body": 2755.878457343202,
                "bogies and drive": 1467.6275808336582,
                "doors and interior": 2331.897156213479,
                "marriage and test": 994.7253603428128,
                "wiring, collection and cooling": 2446.045968056097
              },
              "usd_m_order": 61.5016186677055,
              "usd_per_car": 10974.592910011688,
              "usd_per_train": 65847.55746007012
            },
            "high": {
              "usd_by_stage_per_car": {
                "HVAC and auxiliaries": 1148.5781067393848,
                "body": 3235.1616673159338,
                "bogies and drive": 1722.8671601090773,
                "doors and interior": 2737.444487728867,
                "marriage and test": 1167.7210751850412,
                "wiring, collection and cooling": 2871.445266848462
              },
              "usd_m_order": 72.19755234904561,
              "usd_per_car": 12883.217763926767,
              "usd_per_train": 77299.3065835606
            },
            "low": {
              "usd_by_stage_per_car": {
                "HVAC and auxiliaries": 893.338527463966,
                "body": 2516.2368523568375,
                "bogies and drive": 1340.0077911959488,
                "doors and interior": 2129.1234904557855,
                "marriage and test": 908.2275029216987,
                "wiring, collection and cooling": 2233.3463186599147
              },
              "usd_m_order": 56.15365182703547,
              "usd_per_car": 10020.280483054152,
              "usd_per_train": 60121.682898324914
            }
          },
          "hours_per_car": 1000,
          "productive_hours_per_employee_year": 1360,
          "proxy_daily_iqd_by_stage": {
            "HVAC and auxiliaries": 75000,
            "body": 65000,
            "bogies and drive": 75000,
            "doors and interior": 55000,
            "marriage and test": 76250,
            "wiring, collection and cooling": 75000
          },
          "scope": "Direct repeat assembly labour within train purchase"
        },
        "direct_content_hours": 5604000,
        "direct_content_job_years_at_1720_hours": 3258.1,
        "direct_posts_all_lines": 700,
        "direct_posts_by_stage": {
          "HVAC and auxiliaries": 3,
          "body": 9,
          "bogies and drive": 4,
          "doors and interior": 9,
          "marriage and test": 3,
          "wiring, collection and cooling": 7
        },
        "direct_posts_per_line": 35,
        "effective_line_days": 1487,
        "first_car_effective_day": 30,
        "hours_per_car_by_stage": {
          "HVAC and auxiliaries": 80,
          "body": 260,
          "bogies and drive": 120,
          "doors and interior": 260,
          "marriage and test": 80,
          "wiring, collection and cooling": 200
        },
        "lines": 20,
        "scheduled_workdays": 1750,
        "support_posts_all_lines": 80,
        "takt_effective_days": 5
      },
      "workforce_scenarios": {
        "assisted": {
          "duty_hours_per_year": {
            "OCC control, traction, incidents and information": 140160,
            "civil, track and power response": 735840,
            "depot rolling-stock technicians": 700800,
            "onboard passenger assistants": 639794,
            "planning, payroll, stores and trainers": 123840,
            "station duty and passenger assistance": 5518800,
            "station security and cleaning": 3679200
          },
          "name": "Onboard passenger assistance",
          "onboard_duty_fraction": 0.25,
          "onboard_role": "onboard passenger assistants",
          "posts_fte": {
            "OCC control, traction, incidents and information": 82,
            "civil, track and power response": 428,
            "depot rolling-stock technicians": 408,
            "onboard passenger assistants": 372,
            "planning, payroll, stores and trainers": 72,
            "station duty and passenger assistance": 3209,
            "station security and cleaning": 2140
          },
          "total_fte": 6711,
          "train_duty_basis": "3,975.4 diagrammed train-hours/day including minimum turnbacks. Add 3,036 train-hours/day estimated from peak fleet and hourly frequency for unresolved groups M01, M02, M04, M09."
        },
        "goa4": {
          "duty_hours_per_year": {
            "OCC control, traction, incidents and information": 140160,
            "civil, track and power response": 735840,
            "depot rolling-stock technicians": 700800,
            "planning, payroll, stores and trainers": 123840,
            "scheduled onboard staff": 0,
            "station duty and passenger assistance": 5518800,
            "station security and cleaning": 3679200
          },
          "name": "Unattended GoA4",
          "onboard_duty_fraction": 0,
          "onboard_role": "scheduled onboard staff",
          "posts_fte": {
            "OCC control, traction, incidents and information": 82,
            "civil, track and power response": 428,
            "depot rolling-stock technicians": 408,
            "planning, payroll, stores and trainers": 72,
            "scheduled onboard staff": 0,
            "station duty and passenger assistance": 3209,
            "station security and cleaning": 2140
          },
          "total_fte": 6339,
          "train_duty_basis": "3,975.4 diagrammed train-hours/day including minimum turnbacks. Add 3,036 train-hours/day estimated from peak fleet and hourly frequency for unresolved groups M01, M02, M04, M09."
        },
        "supervised": {
          "duty_hours_per_year": {
            "OCC control, traction, incidents and information": 140160,
            "civil, track and power response": 735840,
            "depot rolling-stock technicians": 700800,
            "onboard commissioning supervisors": 2559174,
            "planning, payroll, stores and trainers": 123840,
            "station duty and passenger assistance": 5518800,
            "station security and cleaning": 3679200
          },
          "name": "Supervised commissioning",
          "onboard_duty_fraction": 1,
          "onboard_role": "onboard commissioning supervisors",
          "posts_fte": {
            "OCC control, traction, incidents and information": 82,
            "civil, track and power response": 428,
            "depot rolling-stock technicians": 408,
            "onboard commissioning supervisors": 1488,
            "planning, payroll, stores and trainers": 72,
            "station duty and passenger assistance": 3209,
            "station security and cleaning": 2140
          },
          "total_fte": 7827,
          "train_duty_basis": "3,975.4 diagrammed train-hours/day including minimum turnbacks. Add 3,036 train-hours/day estimated from peak fleet and hourly frequency for unresolved groups M01, M02, M04, M09."
        }
      }
    }
  },
  "study_evaluation_sha256": "4938687fe9db277880504312861d1795fad74e6c7ec0bed2b65c57d3d8d87cc9"
};
