// Generated from quantities.json by capture-workforce.mjs
const workforceStudy = {
  "operating_options": {
    "metropolitan-mainlines": {
      "annual_grid_gwh": 1954.897475395032,
      "annual_train_km": 91968471.07579927,
      "infrastructure_network": "metropolitan",
      "opex": {
        "baseline_usd_m_year": 777.9318018444819,
        "eligible_envelopes_usd_m_year": {
          "Non-energy train operations": 239.1180247970781,
          "Power maintenance": 24.226080000000003,
          "Station operations": 280
        },
        "embedded_payroll_usd_m_year": null,
        "operator_pay_rates_usd_per_fte_year": null,
        "other_costs_usd_m_year": 234.58769704740382
      },
      "source_diagram_evaluation_id": "5ee1a40e7375cf32c7c97b3a0aeed48a046f07482856d183d8c09d73645d4741",
      "source_evaluation_id": "54c45fc9feb942bd0f63b2d9aaf4688cb794409801793967f047050e61586db3",
      "source_physical_id": "28d1d23756788171634dbf3ac50dbbae0254f4ca9cd5b732821ae9a88635408c",
      "train_hours_day_including_minimum_turns": 6951.086666666667,
      "workforce_scenarios": {
        "assisted": {
          "duty_hours_per_year": {
            "OCC control, traction, incidents and information": 140160,
            "civil, track and power response": 735840,
            "depot rolling-stock technicians": 700800,
            "onboard passenger assistants": 634287,
            "planning, payroll, stores and trainers": 123840,
            "station duty and passenger assistance": 5518800,
            "station security and cleaning": 3679200
          },
          "name": "Onboard passenger assistance",
          "onboard_duty_fraction": 0.25,
          "onboard_role": "onboard passenger assistants",
          "posts_fte": {
            "OCC control, traction, incidents and information": 82,
            "civil, track and power response": 428,
            "depot rolling-stock technicians": 408,
            "onboard passenger assistants": 369,
            "planning, payroll, stores and trainers": 72,
            "station duty and passenger assistance": 3209,
            "station security and cleaning": 2140
          },
          "total_fte": 6708,
          "train_duty_basis": "All 14 routes have timed workings, totalling 6,951.1 train-hours/day including minimum turns. 5 access sections are deferred. The full 280-station and 934-set capital programme and built line upkeep are retained."
        },
        "goa4": {
          "duty_hours_per_year": {
            "OCC control, traction, incidents and information": 140160,
            "civil, track and power response": 735840,
            "depot rolling-stock technicians": 700800,
            "planning, payroll, stores and trainers": 123840,
            "scheduled onboard staff": 0,
            "station duty and passenger assistance": 5518800,
            "station security and cleaning": 3679200
          },
          "name": "Unattended GoA4",
          "onboard_duty_fraction": 0,
          "onboard_role": "scheduled onboard staff",
          "posts_fte": {
            "OCC control, traction, incidents and information": 82,
            "civil, track and power response": 428,
            "depot rolling-stock technicians": 408,
            "planning, payroll, stores and trainers": 72,
            "scheduled onboard staff": 0,
            "station duty and passenger assistance": 3209,
            "station security and cleaning": 2140
          },
          "total_fte": 6339,
          "train_duty_basis": "All 14 routes have timed workings, totalling 6,951.1 train-hours/day including minimum turns. 5 access sections are deferred. The full 280-station and 934-set capital programme and built line upkeep are retained."
        },
        "supervised": {
          "duty_hours_per_year": {
            "OCC control, traction, incidents and information": 140160,
            "civil, track and power response": 735840,
            "depot rolling-stock technicians": 700800,
            "onboard commissioning supervisors": 2537147,
            "planning, payroll, stores and trainers": 123840,
            "station duty and passenger assistance": 5518800,
            "station security and cleaning": 3679200
          },
          "name": "Supervised commissioning",
          "onboard_duty_fraction": 1,
          "onboard_role": "onboard commissioning supervisors",
          "posts_fte": {
            "OCC control, traction, incidents and information": 82,
            "civil, track and power response": 428,
            "depot rolling-stock technicians": 408,
            "onboard commissioning supervisors": 1476,
            "planning, payroll, stores and trainers": 72,
            "station duty and passenger assistance": 3209,
            "station security and cleaning": 2140
          },
          "total_fte": 7815,
          "train_duty_basis": "All 14 routes have timed workings, totalling 6,951.1 train-hours/day including minimum turns. 5 access sections are deferred. The full 280-station and 934-set capital programme and built line upkeep are retained."
        }
      }
    }
  },
  "schema": "osr.factory-workforce.study.3",
  "source_sha256": {
    "cities/Baghdad/service-diagrams.json": "37fab32fe7b04570ee7a521101d3807291173db545082660d00de190b1663ccb",
    "cities/Baghdad/system-results.json": "be01359239e9b97efdae45822628688ffb1225a17afd36df136aaffb0928c06e",
    "cities/Baghdad/system.toml": "5a847f9bf78cb1ad0ed81a66136a511cce39a5ee0bc99bb20d35717da848a035",
    "docs/operator-review/delivery/calculate.py": "2cf1a17bd06933c210eb7c9424ee2b933682f9f21517378001b613b4e7b84f69",
    "docs/reference-v07/concept.toml": "033849bb4db3a0b28adb5a345a39601330f5160cd8c100a4dd4b790123485a18",
    "docs/reference-v07/cost/README.md": "f7d799e4f954d4bec341ed63b457e2c6918e07546a875349569cc1aefae9a75d",
    "docs/reference-v07/digital/production/handoff.json": "c8f89fd421e9413ddbe6ef4b934c153469b0a87f1ed54d8761a1d57c77512a4c",
    "docs/reference-v07/integration/timetable.py": "955867f78178e7eaabcd5bba5b1092268bb3893a6fb6c324cd1c7f32656bf671"
  },
  "status": "capacity and quotation study",
  "studies": {
    "core": {
      "civil": {
        "beams": 6000,
        "civil_yard_day_posts": 36,
        "erection_day_posts": 16,
        "erection_fronts": 2,
        "minimum_pre_erection_stock_per_yard": 440,
        "off_yard_slots_needed_per_yard": 260,
        "yards": 2
      },
      "opex": {
        "baseline_usd_m_year": 30.495,
        "eligible_envelopes_usd_m_year": {
          "Civil, station and overhead maintenance": 6,
          "Control and operations staff": 4,
          "Fleet maintenance": 10,
          "Insurance and administration": 3
        },
        "embedded_payroll_usd_m_year": null,
        "operator_pay_rates_usd_per_fte_year": null,
        "other_costs_usd_m_year": 7.495000000000001
      },
      "production_day_posts": 202,
      "roster": {
        "duty_hours_per_year": {
          "OCC control, traction, incidents and information": 35040,
          "civil, track and power response": 35040,
          "depot rolling-stock technicians": 58400,
          "planning, payroll, stores and trainers": 10320,
          "station duty and passenger assistance": 236520,
          "station security and cleaning": 157680,
          "train operators": 156220
        },
        "field_groups": 1,
        "posts_fte": {
          "OCC control, traction, incidents and information": 21,
          "civil, track and power response": 21,
          "depot rolling-stock technicians": 34,
          "planning, payroll, stores and trainers": 6,
          "station duty and passenger assistance": 138,
          "station security and cleaning": 92,
          "train operators": 91
        },
        "total_fte": 403,
        "train_operator_hours_per_day": 428
      },
      "source_diagram_evaluation_id": "66624c217e2ee50fbc6acb9850609d35a3e5632fbd2e02f6bfe33c91e1e6366b",
      "source_evaluation_id": "63dbda54f7498fcd3a2e390fe37571fb6049fa39c02f9640fe39e15d70560dbc",
      "source_physical_id": "osr-v07-joined-civil-518dad57a3af5046f40c8f4f",
      "source_selection_id": "osr-v07-digital-design-20261117",
      "train_hours_day_including_minimum_turns": 413.8,
      "vehicle": {
        "cars": 306,
        "cars_capacity": 380,
        "cars_per_line_in_window": 76,
        "direct_content_hours": 220320,
        "direct_content_job_years_at_1720_hours": 128.1,
        "direct_posts_all_lines": 130,
        "direct_posts_by_stage": {
          "HVAC and auxiliaries": 3,
          "body": 9,
          "bogies and drive": 4,
          "doors and interior": 3,
          "marriage and test": 3,
          "wiring, collection and cooling": 4
        },
        "direct_posts_per_line": 26,
        "effective_line_days": 408,
        "first_car_effective_day": 30,
        "hours_per_car_by_stage": {
          "HVAC and auxiliaries": 80,
          "body": 260,
          "bogies and drive": 120,
          "doors and interior": 80,
          "marriage and test": 80,
          "wiring, collection and cooling": 100
        },
        "lines": 5,
        "scheduled_workdays": 480,
        "support_posts_all_lines": 20,
        "takt_effective_days": 5
      },
      "workforce_scenarios": {
        "assisted": {
          "duty_hours_per_year": {
            "OCC control, traction, incidents and information": 35040,
            "civil, track and power response": 35040,
            "depot rolling-stock technicians": 58400,
            "onboard passenger assistants": 37760,
            "planning, payroll, stores and trainers": 10320,
            "station duty and passenger assistance": 236520,
            "station security and cleaning": 157680
          },
          "name": "Onboard passenger assistance",
          "onboard_duty_fraction": 0.25,
          "onboard_role": "onboard passenger assistants",
          "posts_fte": {
            "OCC control, traction, incidents and information": 21,
            "civil, track and power response": 21,
            "depot rolling-stock technicians": 34,
            "onboard passenger assistants": 22,
            "planning, payroll, stores and trainers": 6,
            "station duty and passenger assistance": 138,
            "station security and cleaning": 92
          },
          "total_fte": 334,
          "train_duty_basis": "576 daily train workings account for 385.0 passenger train-hours and 28.8 minimum turnback hours. Each onboard duty still needs crew relief, stabling moves and handover."
        },
        "goa4": {
          "duty_hours_per_year": {
            "OCC control, traction, incidents and information": 35040,
            "civil, track and power response": 35040,
            "depot rolling-stock technicians": 58400,
            "planning, payroll, stores and trainers": 10320,
            "scheduled onboard staff": 0,
            "station duty and passenger assistance": 236520,
            "station security and cleaning": 157680
          },
          "name": "Unattended GoA4",
          "onboard_duty_fraction": 0,
          "onboard_role": "scheduled onboard staff",
          "posts_fte": {
            "OCC control, traction, incidents and information": 21,
            "civil, track and power response": 21,
            "depot rolling-stock technicians": 34,
            "planning, payroll, stores and trainers": 6,
            "scheduled onboard staff": 0,
            "station duty and passenger assistance": 138,
            "station security and cleaning": 92
          },
          "total_fte": 312,
          "train_duty_basis": "576 daily train workings account for 385.0 passenger train-hours and 28.8 minimum turnback hours. Each onboard duty still needs crew relief, stabling moves and handover."
        },
        "supervised": {
          "duty_hours_per_year": {
            "OCC control, traction, incidents and information": 35040,
            "civil, track and power response": 35040,
            "depot rolling-stock technicians": 58400,
            "onboard commissioning supervisors": 151037,
            "planning, payroll, stores and trainers": 10320,
            "station duty and passenger assistance": 236520,
            "station security and cleaning": 157680
          },
          "name": "Supervised commissioning",
          "onboard_duty_fraction": 1,
          "onboard_role": "onboard commissioning supervisors",
          "posts_fte": {
            "OCC control, traction, incidents and information": 21,
            "civil, track and power response": 21,
            "depot rolling-stock technicians": 34,
            "onboard commissioning supervisors": 88,
            "planning, payroll, stores and trainers": 6,
            "station duty and passenger assistance": 138,
            "station security and cleaning": 92
          },
          "total_fte": 400,
          "train_duty_basis": "576 daily train workings account for 385.0 passenger train-hours and 28.8 minimum turnback hours. Each onboard duty still needs crew relief, stabling moves and handover."
        }
      }
    },
    "first": {
      "civil": {
        "beams": 29640,
        "civil_yard_day_posts": 108,
        "erection_day_posts": 48,
        "erection_fronts": 6,
        "peak_month_end_total_inventory": 983,
        "slots_per_yard_if_balanced": 164,
        "slots_per_yard_offered": 180,
        "yards": 6
      },
      "opex": {
        "baseline_usd_m_year": 196.9782648382638,
        "eligible_envelopes_usd_m_year": {
          "Non-energy train operations": 64.13266080000001,
          "Power maintenance": 5.928,
          "Station operations": 64
        },
        "embedded_payroll_usd_m_year": null,
        "operator_pay_rates_usd_per_fte_year": null,
        "other_costs_usd_m_year": 62.91760403826379
      },
      "production_day_posts": 624,
      "roster": {
        "duty_hours_per_year": {
          "OCC control, traction, incidents and information": 70080,
          "civil, track and power response": 175200,
          "depot rolling-stock technicians": 233600,
          "planning, payroll, stores and trainers": 41280,
          "station duty and passenger assistance": 1261440,
          "station security and cleaning": 840960,
          "train operators": 729270
        },
        "field_groups": 5,
        "posts_fte": {
          "OCC control, traction, incidents and information": 41,
          "civil, track and power response": 102,
          "depot rolling-stock technicians": 136,
          "planning, payroll, stores and trainers": 24,
          "station duty and passenger assistance": 734,
          "station security and cleaning": 489,
          "train operators": 424
        },
        "total_fte": 1950,
        "train_operator_hours_per_day": 1998
      },
      "source_diagram_evaluation_id": "5ee1a40e7375cf32c7c97b3a0aeed48a046f07482856d183d8c09d73645d4741",
      "source_evaluation_id": "12d4630a9c69a023b7c538c6b9a7413b38622697b7c127db6839d89d93170054",
      "source_physical_id": "f6844cd4d9f5d9320fa421b37eb074b9911d3cd695d350fdc464cc3597184a72",
      "vehicle": {
        "cars": 1452,
        "cars_capacity": 1464,
        "cars_per_line_in_window": 122,
        "direct_content_hours": 1452000,
        "direct_content_job_years_at_1720_hours": 844.2,
        "direct_posts_all_lines": 420,
        "direct_posts_by_stage": {
          "HVAC and auxiliaries": 3,
          "body": 9,
          "bogies and drive": 4,
          "doors and interior": 9,
          "marriage and test": 3,
          "wiring, collection and cooling": 7
        },
        "direct_posts_per_line": 35,
        "effective_line_days": 637,
        "first_car_effective_day": 30,
        "hours_per_car_by_stage": {
          "HVAC and auxiliaries": 80,
          "body": 260,
          "bogies and drive": 120,
          "doors and interior": 260,
          "marriage and test": 80,
          "wiring, collection and cooling": 200
        },
        "lines": 12,
        "scheduled_workdays": 750,
        "support_posts_all_lines": 48,
        "takt_effective_days": 5
      },
      "workforce_scenarios": {
        "assisted": {
          "duty_hours_per_year": {
            "OCC control, traction, incidents and information": 70080,
            "civil, track and power response": 175200,
            "depot rolling-stock technicians": 233600,
            "onboard passenger assistants": 176878,
            "planning, payroll, stores and trainers": 41280,
            "station duty and passenger assistance": 1261440,
            "station security and cleaning": 840960
          },
          "name": "Onboard passenger assistance",
          "onboard_duty_fraction": 0.25,
          "onboard_role": "onboard passenger assistants",
          "posts_fte": {
            "OCC control, traction, incidents and information": 41,
            "civil, track and power response": 102,
            "depot rolling-stock technicians": 136,
            "onboard passenger assistants": 103,
            "planning, payroll, stores and trainers": 24,
            "station duty and passenger assistance": 734,
            "station security and cleaning": 489
          },
          "total_fte": 1629,
          "train_duty_basis": "1,938.4 diagrammed train-hours/day including minimum turnbacks."
        },
        "goa4": {
          "duty_hours_per_year": {
            "OCC control, traction, incidents and information": 70080,
            "civil, track and power response": 175200,
            "depot rolling-stock technicians": 233600,
            "planning, payroll, stores and trainers": 41280,
            "scheduled onboard staff": 0,
            "station duty and passenger assistance": 1261440,
            "station security and cleaning": 840960
          },
          "name": "Unattended GoA4",
          "onboard_duty_fraction": 0,
          "onboard_role": "scheduled onboard staff",
          "posts_fte": {
            "OCC control, traction, incidents and information": 41,
            "civil, track and power response": 102,
            "depot rolling-stock technicians": 136,
            "planning, payroll, stores and trainers": 24,
            "scheduled onboard staff": 0,
            "station duty and passenger assistance": 734,
            "station security and cleaning": 489
          },
          "total_fte": 1526,
          "train_duty_basis": "1,938.4 diagrammed train-hours/day including minimum turnbacks."
        },
        "supervised": {
          "duty_hours_per_year": {
            "OCC control, traction, incidents and information": 70080,
            "civil, track and power response": 175200,
            "depot rolling-stock technicians": 233600,
            "onboard commissioning supervisors": 707509,
            "planning, payroll, stores and trainers": 41280,
            "station duty and passenger assistance": 1261440,
            "station security and cleaning": 840960
          },
          "name": "Supervised commissioning",
          "onboard_duty_fraction": 1,
          "onboard_role": "onboard commissioning supervisors",
          "posts_fte": {
            "OCC control, traction, incidents and information": 41,
            "civil, track and power response": 102,
            "depot rolling-stock technicians": 136,
            "onboard commissioning supervisors": 412,
            "planning, payroll, stores and trainers": 24,
            "station duty and passenger assistance": 734,
            "station security and cleaning": 489
          },
          "total_fte": 1938,
          "train_duty_basis": "1,938.4 diagrammed train-hours/day including minimum turnbacks."
        }
      }
    },
    "metropolitan": {
      "civil": {
        "beams": 121156,
        "civil_yard_day_posts": 180,
        "erection_day_posts": 80,
        "erection_fronts": 10,
        "peak_month_end_total_inventory": 1638,
        "slots_per_yard_if_balanced": 164,
        "slots_per_yard_offered": 180,
        "yards": 10
      },
      "opex": {
        "baseline_usd_m_year": 780.4954502209043,
        "eligible_envelopes_usd_m_year": {
          "Non-energy train operations": 240.4121078274824,
          "Power maintenance": 24.226080000000003,
          "Station operations": 280
        },
        "embedded_payroll_usd_m_year": null,
        "operator_pay_rates_usd_per_fte_year": null,
        "other_costs_usd_m_year": 235.85726239342193
      },
      "production_day_posts": 1040,
      "roster": {
        "duty_hours_per_year": {
          "OCC control, traction, incidents and information": 140160,
          "civil, track and power response": 735840,
          "depot rolling-stock technicians": 700800,
          "planning, payroll, stores and trainers": 123840,
          "station duty and passenger assistance": 5518800,
          "station security and cleaning": 3679200,
          "train operators": 2815610
        },
        "field_groups": 21,
        "posts_fte": {
          "OCC control, traction, incidents and information": 82,
          "civil, track and power response": 428,
          "depot rolling-stock technicians": 408,
          "planning, payroll, stores and trainers": 72,
          "station duty and passenger assistance": 3209,
          "station security and cleaning": 2140,
          "train operators": 1637
        },
        "total_fte": 7976,
        "train_operator_hours_per_day": 7714
      },
      "source_diagram_evaluation_id": "5ee1a40e7375cf32c7c97b3a0aeed48a046f07482856d183d8c09d73645d4741",
      "source_evaluation_id": "54c45fc9feb942bd0f63b2d9aaf4688cb794409801793967f047050e61586db3",
      "source_physical_id": "28d1d23756788171634dbf3ac50dbbae0254f4ca9cd5b732821ae9a88635408c",
      "vehicle": {
        "cars": 5604,
        "cars_capacity": 5840,
        "cars_per_line_in_window": 292,
        "direct_content_hours": 5604000,
        "direct_content_job_years_at_1720_hours": 3258.1,
        "direct_posts_all_lines": 700,
        "direct_posts_by_stage": {
          "HVAC and auxiliaries": 3,
          "body": 9,
          "bogies and drive": 4,
          "doors and interior": 9,
          "marriage and test": 3,
          "wiring, collection and cooling": 7
        },
        "direct_posts_per_line": 35,
        "effective_line_days": 1487,
        "first_car_effective_day": 30,
        "hours_per_car_by_stage": {
          "HVAC and auxiliaries": 80,
          "body": 260,
          "bogies and drive": 120,
          "doors and interior": 260,
          "marriage and test": 80,
          "wiring, collection and cooling": 200
        },
        "lines": 20,
        "scheduled_workdays": 1750,
        "support_posts_all_lines": 80,
        "takt_effective_days": 5
      },
      "workforce_scenarios": {
        "assisted": {
          "duty_hours_per_year": {
            "OCC control, traction, incidents and information": 140160,
            "civil, track and power response": 735840,
            "depot rolling-stock technicians": 700800,
            "onboard passenger assistants": 639794,
            "planning, payroll, stores and trainers": 123840,
            "station duty and passenger assistance": 5518800,
            "station security and cleaning": 3679200
          },
          "name": "Onboard passenger assistance",
          "onboard_duty_fraction": 0.25,
          "onboard_role": "onboard passenger assistants",
          "posts_fte": {
            "OCC control, traction, incidents and information": 82,
            "civil, track and power response": 428,
            "depot rolling-stock technicians": 408,
            "onboard passenger assistants": 372,
            "planning, payroll, stores and trainers": 72,
            "station duty and passenger assistance": 3209,
            "station security and cleaning": 2140
          },
          "total_fte": 6711,
          "train_duty_basis": "3,975.4 diagrammed train-hours/day including minimum turnbacks. Add 3,036 train-hours/day estimated from peak fleet and hourly frequency for unresolved groups M01, M02, M04, M09."
        },
        "goa4": {
          "duty_hours_per_year": {
            "OCC control, traction, incidents and information": 140160,
            "civil, track and power response": 735840,
            "depot rolling-stock technicians": 700800,
            "planning, payroll, stores and trainers": 123840,
            "scheduled onboard staff": 0,
            "station duty and passenger assistance": 5518800,
            "station security and cleaning": 3679200
          },
          "name": "Unattended GoA4",
          "onboard_duty_fraction": 0,
          "onboard_role": "scheduled onboard staff",
          "posts_fte": {
            "OCC control, traction, incidents and information": 82,
            "civil, track and power response": 428,
            "depot rolling-stock technicians": 408,
            "planning, payroll, stores and trainers": 72,
            "scheduled onboard staff": 0,
            "station duty and passenger assistance": 3209,
            "station security and cleaning": 2140
          },
          "total_fte": 6339,
          "train_duty_basis": "3,975.4 diagrammed train-hours/day including minimum turnbacks. Add 3,036 train-hours/day estimated from peak fleet and hourly frequency for unresolved groups M01, M02, M04, M09."
        },
        "supervised": {
          "duty_hours_per_year": {
            "OCC control, traction, incidents and information": 140160,
            "civil, track and power response": 735840,
            "depot rolling-stock technicians": 700800,
            "onboard commissioning supervisors": 2559174,
            "planning, payroll, stores and trainers": 123840,
            "station duty and passenger assistance": 5518800,
            "station security and cleaning": 3679200
          },
          "name": "Supervised commissioning",
          "onboard_duty_fraction": 1,
          "onboard_role": "onboard commissioning supervisors",
          "posts_fte": {
            "OCC control, traction, incidents and information": 82,
            "civil, track and power response": 428,
            "depot rolling-stock technicians": 408,
            "onboard commissioning supervisors": 1488,
            "planning, payroll, stores and trainers": 72,
            "station duty and passenger assistance": 3209,
            "station security and cleaning": 2140
          },
          "total_fte": 7827,
          "train_duty_basis": "3,975.4 diagrammed train-hours/day including minimum turnbacks. Add 3,036 train-hours/day estimated from peak fleet and hourly frequency for unresolved groups M01, M02, M04, M09."
        }
      }
    }
  },
  "study_evaluation_sha256": "2cbd05b0dc6f3ef97cc2fcb67d38e9506f0257bb28536d6b4a3aaa413ef5be73"
};
