# Parent joined prototype interface record

**17 November 2026.** This is the nine-strand parent interface record for the
[selected thirteen-strand v0.7 digital railway](../digital/selected.toml). The
[candidate record](https://github.com/modernecotech/OpenSourceRail/blob/main/docs/reference-v07/integration/candidate.toml), [interface register](interfaces.csv),
[quantity handoff](https://github.com/modernecotech/OpenSourceRail/blob/main/docs/reference-v07/integration/quantity-handoff.csv) and [arrangement drawing](https://github.com/modernecotech/OpenSourceRail/blob/main/docs/reference-v07/integration/arrangement.svg)
remain source-bound ancestry. The selected child retains the car, station and
power arrangement while changing the beam mass, prestress and central price.
The v0.6 passive-wheel reference remains a separate configuration.

| Identity | Value | Meaning |
| --- | --- | --- |
| Joined physical candidate | `osr-v07-joined-prototype-20261117` | Powered six-car train, independent bogie rail brakes, two conventional rail tracks on one-piece 10 m beams, island stations and 1.5 kV DC overhead |
| Joined interface evaluation | `osr-v07-interface-reconciliation-20261117` | Arithmetic and nominal interface reconciliation in this package; **no joined native CAD, FEA, braking or site evaluation** |
| Release-purpose selection | `osr-v07-prototype-quotation-20261117` | One controlled basis for manufacturer, contractor and supplier quotation and prototype test planning |
| Source epoch | `e4e73bfdda720c608816aa76a78148855ab8443b` | Immutable commit whose listed input byte hashes are recorded in `candidate.toml` |

The powered vehicle research candidate `ac550fe8ff23f20cb1ae5b142f4ef6160afc9de6efe7850754bac96a7789327d` and the joint-free civil candidate `bc62448096e5e5e4bc12190fbe4c2f8c5008093d7a2eedfdd022a4d04d01c19e` are *ancestry*, not interchangeable evaluations of the joined geometry. The [vehicle](../vehicle/README.md), [independent brake](https://github.com/modernecotech/OpenSourceRail/blob/main/docs/design-engine/v07-independent-brake/README.md), [civil](https://github.com/modernecotech/OpenSourceRail/blob/main/docs/reference-v07/civil/README.md) and [cost](../cost/README.md) packages retain their own evidence and limitations. No installed mass, foundation, electrical clearance, safety stop, fabrication approval or passenger operation is inferred from joining them.

The civil source packet named in `candidate.toml` is immutable ancestry. The current-source span packet retains the same physical candidate and numerical fields with its own evaluation identity. This joined interface evaluation still does not replace a native assessment of the installed car, span and station together.

## Configuration and operating case

| System | Quotation control |
| --- | --- |
| Service | Synthetic 30 km double-track, 12 stations, 120 s nominal peak headway, 44 active plus seven reserve sets; 276 normal places/train and 8,280 offered places/hour/direction |
| Demonstrator | Straight elevated 2 km, two-track design envelope with two 125 m endpoint island stations and one six-car test train. This is **not a surveyed site**. |
| Vehicle | Six 17 m cars; 104.5 m full train; 2.65 m body width; 1,435 mm gauge; 44 seats plus two wheelchair places/car, no planned standing; two 1.4 m clear doors per car facing the island |
| Motion | Continuous grid-fed drive on 24 axles, six 1C4M groups, 72 km/h cap, 0.4 m/s² acceleration demand. No traction battery, supercapacitor or station launcher in this candidate. |
| Power | 1.5 kV DC protected rigid overhead, one roof collector/car, at least 3.037 MW train DC input procurement rating for the 2.727 km +2% sizing leg. Collector sharing and actual grid draw need tests. |
| Braking | 12 independent two-shoe bogie rail-brake modules, sized with one module unavailable. At normal analytical load on a 2% downgrade, each remaining module needs 10.89 kN and 3.63 MJ ideal rail-interface duty. Protected brake energy and power-free parking still require supplier selection and tests. |
| Civil | One joint-free 10 m × 2 m × 1.4 m precast beam per track per bay; independent track support lines. Four bearing units/beam are provisional. Station platforms have independent frames/foundations. |
| Station | 125 m × 8 m central island; straight approach and approximately level platform. Tracks flank the island and both trains present their one-sided doors to it. |

The 2 km straight-line count is 400 standard running beams, 402 independent support positions, 1,600 provisional bearings and 8,000 m of rail. Two station frames and their foundations are additional. Where station approaches, switches or utilities require special spans, replace the standard units and remeasure. The active [30 km estimate](../cost/README.md) uses 6,000 thirteen-strand beams, 6,002 supports, 24,000 bearings, 60 track-km, 12 stations and a 51-set fleet; it prices the selected digital child at **US$1,025.2272 million installed capital** in 2026 dollars, with a **43-month** programme. The 2 km construction module is allowed **12 months** after route definition and approvals. These are planning figures, not contractor bids.

## Mating datums and load handoff

Set rail-head running surface as `z=0`, each track centre as `y=0`, and car centre as `x=0`. On a straight station, 8.0 m island width plus 1.4 m from each platform edge to adjacent track centre yields **10.8 m nominal track-centre spacing**. A 2.65 m wide static body on that datum leaves **75 mm nominal body-to-edge gap**. This is only a straight, stationary arithmetic gap. The accessible boarding gap needs the complete curve, cant, rail/wheel wear, suspension, roll, sway, loading, stopping and platform edge stack before edge fabrication. Car floor top is nominal 1.000 m above rail head. The 125 m platform gives 10.25 m nominal end margin for a centred 104.5 m train; actual stopping tolerance and full-tail protection require a train-control assessment.

The [interface register](interfaces.csv) states each nominal, its release hold and the test or survey needed to turn it into a controlled fabrication tolerance. Rail gauge, rail section, wheel profile, platform edge and roof electrical clearances must be coordinated in supplier interface drawings using the applicable approved standards. Do not infer a permitted dynamic gap from the static 75 mm. The two single-sided door openings at car `x=±4.5 m` and the bogies at `x=±6.4 m` are fixed for quotation; motor envelope, brake shoes, collector and power cabinets require full swept and maintenance-access checks. Station architecture must supply two independent egress paths and accessible vertical access; demand and site fire analysis size those paths.

Use **25.072 t/car** as the normal analytical load and **33.622 t/car** as the separate 160-person crowd structural control. Thus normal six-car load is **150.432 t** and crowd six-car control is **201.732 t**. Assuming four equally loaded axles per car yields mean static values of about **61.49 kN** and **82.46 kN** per axle respectively; these are *not maximum design axle reactions*. The conditional upper tare allowance is **21.617 t/car**, and **10.090 t/car** of the inherited installed account has no approved placement. Weigh a complete car, locate equipment and determine CG, axle distribution and dynamic/longitudinal loads before final beam, bearing, foundation, rail-seat or brake design. The civil packet's 636 kN gravity-only interior support reaction excludes pier/foundation self-weight, lateral/braking combinations and actual axle concentration.

The civil section's bare beam is **29.884 t**, while the provisional hook allowance is **37.356 t** with rigging. Crane capacity must be checked at the actual radius and ground bearing pressure. The 2.5 m square footing and 1 m square pier in `candidate.toml` are *quantity modules*, not chosen foundation sizes. Soil bearing, settlement, flood/scour, seismic and temporary stability must determine the actual support family. The station platform, overhead mounts, protected walkway, drainage, utilities and return/earth path are separate installed assemblies; none can borrow an unanalysed beam capacity.

## Quotation and prototype build sequence

1. **Survey and supplier interface freeze.** Obtain a 2 km candidate alignment with topography, utilities, geotechnical logs, flood data and haul/crane access. Issue a common rail-head/track-centre/vehicle coordinate drawing. Suppliers return CAD envelopes, fastening patterns, mass, CG, current, force, heat, wear, maintenance access and delivery lead times. Reject a quote that leaves required parts as zero.
2. **Vehicle trial assembly.** Build one 17 m car with two powered bogies, both rail-brake modules, roof collector/protection, inverter/cooling racks, doors, HVAC, interior, service battery and protected auxiliary circuits. Count couplings, mounts, bolts, earth/HV loops, hoses, guards and removal clearances as in `quantity-handoff.csv`; add vendor internals, cable supports, sensors, coolant, independent brake energy and parking equipment to the ordered BOM. Fit and weigh the actual assembly, record each axle reaction, then replicate the accepted arrangement across six cars.
3. **Civil trial assembly.** Qualify one 10 m beam, bearings, support and rail/overhead fixing family; approve reinforcement, tendon/anchor, shear/torsion/fatigue, bearing seat and rail seat details. Cast/proof-load a representative beam; lift it at a demonstrated radius; survey line, level, twist and settlement. Build the station as a separate support and passenger-protection package.
4. **Integrated trial.** Test collector contact and protection at section gaps; wheel-drive force/current/thermal duty on the +2% sizing leg; independent braking with one module isolated, wet/debris/hot rail and power loss; turnout/rail damage; power-free parking; rescue; door/platform gap at loaded and empty conditions; full stopping and egress envelope. Apply a separate crowd-load structural/brake check. Only measured results and independent reviews may close these holds.
5. **Production and maintenance handoff.** Release serial/lot-tracked engineering BOM, manufacturing BOM, routing, tooling, QA witness points, installation record and replaceable-unit instructions. A first-car **720 direct assembly-hour** and 2 km **12-month** schedule are planning allowances to replace with measured shop and contractor programmes. The [manufacturing package](../manufacturing/README.md) owns the downstream route and ERPNext transaction records.

### Quotation schedule and release boundary

Ask each bidder to price and identify its material origin, local fabrication hours, bought components, tooling, transport, lifting, installation, tests, spares and maintenance replacement separately. Require a complete installed mass ledger with joints, fasteners, cooling, wiring, protection and maintenance envelopes. Unknown supplier item counts, mass, duty, price and origin remain **open**, never zero. The 14-scope [cost ledger](../cost/README.md) is the single concept price basis; substitute measured quotations by changing the appropriate row and its dependent contingency/whole-life calculation, not by adding a second competing total.

This package meets an **interface and quotation handoff** only. It is not a fabrication drawing set, measured physical qualification or authority to carry passengers. The independent brake, installed CG and axle loads, beam/seat/foundation structure, overhead electrical clearance, accessible gap, fire/egress, controls and site ground are mandatory qualification holds. Their completion requires supplier drawings, physical tests, approved limits and independent review through the existing qualification workflow.

## Scheduled service and disruption

The [30 km reference timetable](TIMETABLE.md) assigns the priced peak and off-peak service to 44 daily train duties and screens terminal space during turnbacks, a set failure and a platform closure. Its stop-call and terminal-occupation export identifies each departure and its train.
