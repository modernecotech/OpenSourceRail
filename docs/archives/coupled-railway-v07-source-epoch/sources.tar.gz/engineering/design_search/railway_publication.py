"""Portable comparison of one coordinated railway experiment and its holds."""
from pathlib import Path,PurePosixPath
from copy import deepcopy
from hashlib import sha256
from math import isfinite
from contextlib import contextmanager
import gzip,json,shutil,tarfile,io,os,subprocess,stat
from engineering.station_rail import ROOT
from engineering.station_rail.common import encoded,identity,digest
from engineering.performance import disk_reservation
from . import aggregate_store,canonical_stream,railway_campaign as engine,design_grammar,railway_bundle,grammar_shell,transient_lim,railway_delivery
from .generative_publication import archive
from .native_archive_stream import write_archive

PRODUCER='engineering/design_search/railway_publication.py'
OUTPUT='docs/design-engine/coupled-railway-v07'
FLAGS=engine.FLAGS
COMPARISON_SCHEMA='osr-coupled-comparison-rows/2'
MAX_REFINEMENT_PREFLIGHT_REQUESTS=64
MAX_REFINEMENT_PREFLIGHT_BYTES=256*1024
REFINEMENT_REQUEST_SCHEMAS=frozenset((
    'osr-current-source-railway-refinement-request/1',
    'osr-current-source-fine-refinement-request/1',
    'osr-current-source-ultrafine-refinement-request/1',
    'osr-railway-numerical-refinement-request/1',
    'osr-railway-fine-refinement-request/1',
    'osr-railway-fine-refinement-resource-request/1',
))
COMPARISON_SOURCES=(
    'crates/osr-design-search/src/bin/osr-campaign-columnar.rs',
    'crates/osr-design-search/src/publication_columnar.rs',
)


def _comparison_codec(root):
    explicit=os.environ.get('OSR_COMPARISON_CODEC')
    paths=([Path(explicit)] if explicit else [Path(root)/'target'/profile/'osr-campaign-columnar'
           for profile in ('release','debug')])
    for path in paths:
        try: info=path.stat(follow_symlinks=False)
        except OSError: continue
        if stat.S_ISREG(info.st_mode) and info.st_mode & stat.S_IXUSR:
            return path
    raise ValueError('Build the Rust osr-campaign-columnar binary with the columnar feature')


def _write_comparison(root,path,rows):
    """Send one canonical row at a time; never allocate a second aggregate JSON array."""
    with disk_reservation(root,path,'railway-comparison-arrow',1024**3):
        command=[str(_comparison_codec(root)),'write-comparison',str(path)]
        process=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        try:
            for row in rows: process.stdin.write(encoded(row))
            process.stdin.close()
            output=process.stdout.read(4096)
            error=process.stderr.read(4096)
            if process.wait(timeout=180)!=0: raise ValueError('Rust comparison writer failed: '+error.decode(errors='replace'))
            receipt=json.loads(output)
            if receipt.get('schema')!=COMPARISON_SCHEMA or receipt.get('row_count')!=len(rows):
                raise ValueError('Rust comparison writer count/schema differs')
            return receipt
        except BaseException:
            if process.poll() is None:process.kill()
            process.wait()
            path.unlink(missing_ok=True)
            raise


def _comparison_rows(root,out,manifest):
    """Yield authenticated current rows from a bounded Rust Arrow scanner."""
    receipt=manifest.get('comparison')
    if (manifest.get('schema')!='osr-coupled-railway-publication/2'
            or not isinstance(receipt,dict) or receipt.get('schema')!=COMPARISON_SCHEMA
            or not isinstance(receipt.get('row_count'),int)
            or not isinstance(receipt.get('canonical_sha256'),str)):
        raise ValueError('Current comparison schema or inventory receipt differs')
    command=[str(_comparison_codec(root)),'scan-comparison',str(out/'comparison.parquet'),receipt['canonical_sha256']]
    process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    count=0
    try:
        for line in process.stdout:
            count+=1
            if count>receipt['row_count']:raise ValueError('Comparison row count exceeded receipt')
            yield json.loads(line)
        error=process.stderr.read(4096)
        if process.wait(timeout=180)!=0:raise ValueError('Rust comparison scanner failed: '+error.decode(errors='replace'))
        if count!=receipt['row_count']:raise ValueError('Comparison row count differs')
    finally:
        if process.poll() is None:process.kill()
        process.wait()


def _reader_provenance(value,root,*,executed):
    """Report local codec bytes only in an unsealed command response."""
    try:
        binary=engine.case_node_store.codec_identity(root)['osr-campaign-case-nodes']
    except ValueError:
        binary=None
    return dict(value,aggregate_reader_executable_sha256=binary,aggregate_reader_executed=executed)


def compact_native_archive(folder,target):
    """Stream solver decks/logs; index duplicate large node/body metadata."""
    write_archive(folder,target,
        omit=lambda p:(p.suffix.lower() in ('.dat','.frd','.12d','.step','.fcstd','.fcstd1')
            or p.name in ('candidate.json','definition.json','worker-result.json') and p.stat().st_size>1_000_000),
        storage='Exact FEM decks/results/logs retained; large fields and duplicate node/body metadata remain local or regenerate from exact source/body/request. Full raw-payload hashes preserved.')


def _retain_previous_publication(root,out):
    """Retain a prior packet once; tolerate its identical retry after interruption."""
    out=Path(out)
    root=Path(root)
    if not out.exists():return None
    def tree_hashes(folder):
        return {p.relative_to(folder).as_posix():digest(p)
            for p in folder.rglob('*') if p.is_file()}
    manifest=out/'manifest.json'
    key=digest(manifest) if manifest.is_file() else 'incomplete-'+identity(tree_hashes(out))
    retained=root/'build/coupled-railway/replaced-publications'/key
    retained.parent.mkdir(parents=True,exist_ok=True)
    if retained.exists():
        if tree_hashes(out)!=tree_hashes(retained):
            raise ValueError('Previous coordinated publication already retained')
        shutil.rmtree(out)
        return retained
    shutil.move(out,retained)
    return retained


@contextmanager
def current_context(root=ROOT):
    """Use one verified, bounded temporary parent for current-source readers."""
    root=Path(root);epoch=engine.source_epoch(root);spec=engine.specification(root);contract=engine.contract_identity(spec,epoch,root=root)
    folder=root/'build/coupled-railway'/contract
    if json.loads((folder/'source-contract.json').read_bytes())!=engine.state_source_contract(contract,epoch,root=root):
        raise ValueError('Source-matched v2 coordinated state required')
    snapshot,pointer=engine.current_aggregate(folder,contract)
    temporary=folder/'.aggregate-parent-result.json'
    with disk_reservation(root,temporary,'railway-aggregate-parent',2*1024*1024*1024):
        if temporary.exists() or temporary.is_symlink():
            if (temporary.is_symlink() or not temporary.is_file()
                    or temporary.stat().st_size>aggregate_store.MAX_AGGREGATE_BYTES
                    or digest(temporary)!=pointer['aggregate_sha256']):
                raise ValueError('Interrupted aggregate parent differs; retain it for review')
            manifest=aggregate_store.read(snapshot,folder/'cases',engine._Discard(),root=root)
        else:
            manifest=aggregate_store.materialize(snapshot,folder/'cases',temporary,root=root)
        if (manifest['manifest_id']!=pointer['manifest_id']
                or manifest['aggregate_sha256']!=pointer['aggregate_sha256']
                or manifest['run_id']!=pointer['run_id']):
            raise ValueError('Active aggregate pointer and verified parent differ')
        try:
            value=json.loads(temporary.read_bytes(),object_pairs_hook=engine.case_node_store._unique_pairs)
            if value['contract_id']!=contract or value['source_sha256']!=epoch or value['campaign_id']!=engine.semantic_id(value):raise ValueError('Source-matched coordinated execution required')
            if value['run_id']!=identity({k:v for k,v in value.items() if k!='run_id'}):raise ValueError('Invocation receipt differs')
            if len(value['rows'])!=len(value['bundles']):raise ValueError('Finish the pending bundle evaluation queue before publishing the complete comparison')
            yield folder,value,temporary
        finally:
            temporary.unlink()


def current(root=ROOT):
    with current_context(root) as (folder,value,_):
        return folder,value


class _VerifiedRows:
    """Reopen one source-bound case at a time after aggregate authentication."""
    def __init__(self,root,cases,refs):
        self.root=Path(root);self.cases=Path(cases);self.refs=tuple(refs)

    def __len__(self):return len(self.refs)

    def __iter__(self):
        for ordinal,ref in enumerate(self.refs):
            context=ref['case_context_id'];path=engine.case_node_store.path_for(self.cases,context)
            if (ref['ordinal']!=ordinal or ref['parquet_name']!=path.name
                    or aggregate_store._hash_file(path)!=ref['parquet_sha256']):
                raise ValueError('Aggregate case shard order or bytes changed')
            _,row,raw=aggregate_store._case_bytes(self.cases,context,root=self.root)
            if (len(raw)!=ref['case_bytes'] or sha256(raw).hexdigest()!=ref['case_sha256']
                    or row.get('row_id')!=ref['row_id']):
                raise ValueError('Aggregate case identity or canonical bytes changed')
            yield row


class _SemanticRows:
    """Hash semantic rows as they arrive without retaining the complete result."""
    def __init__(self,core):
        canonical=b''.join(canonical_stream.iter_canonical_bytes(core,semantic=True))
        marker=b'"rows":[]'
        if canonical.count(marker)!=1:raise ValueError('Canonical semantic rows placeholder differs')
        before,self.after=canonical.split(marker)
        self.digest=sha256();self.digest.update(before);self.digest.update(b'"rows":[')
        self.count=0

    def add(self,row):
        if self.count:self.digest.update(b',')
        last=None
        for chunk in canonical_stream.iter_canonical_bytes(row,semantic=True):
            if last is not None:self.digest.update(last)
            last=chunk
        if last is None or not last.endswith(b'\n'):raise ValueError('Semantic row terminator differs')
        self.digest.update(last[:-1]);self.count+=1

    def finish(self):
        self.digest.update(b']');self.digest.update(self.after)
        return self.digest.hexdigest()


def _streaming_semantic_id(core,rows,visit=None):
    """Compute the campaign identity without making a second aggregate object."""
    semantic=_SemanticRows(core)
    for row in rows:
        if visit is not None:visit(row)
        semantic.add(row)
    return semantic.finish()


class _SemanticProjectionSink:
    """Consume only the exact row framing emitted by the verified aggregate reader."""
    def __init__(self,core,value,refs):
        self.refs=tuple(refs);self.semantic=_SemanticRows(value)
        self.projection=_new_row_projection();self.row_index=0;self.tail_index=0
        offset=aggregate_store._core_offset(core)
        self.prefix=core[:offset+1]
        tail=core[offset+1:]
        marker=b',"run_id":"'+value['run_id'].encode('ascii')+b'"'
        if tail.count(marker)!=1:raise ValueError('Aggregate projection tail differs')
        before,after=tail.split(marker,1)
        self.tail_frames=tuple(part for part in (before,marker,after) if part)
        self.state='prefix'

    def write(self,data):
        size=len(data)
        if self.state=='prefix':
            if data!=self.prefix:raise ValueError('Aggregate projection prefix differs')
            self.state='row' if self.refs else 'tail'
        elif self.state=='comma':
            if data!=b',':raise ValueError('Aggregate projection row delimiter differs')
            self.state='row'
        elif self.state=='row':
            ref=self.refs[self.row_index]
            if size!=ref['case_bytes']-1:raise ValueError('Aggregate projection row length differs')
            row=json.loads(bytes(data),object_pairs_hook=engine.case_node_store._unique_pairs)
            if row.get('row_id')!=ref['row_id']:raise ValueError('Aggregate projection row identity differs')
            self.semantic.add(row);_add_row_projection(self.projection,row)
            self.row_index+=1
            self.state='comma' if self.row_index<len(self.refs) else 'tail'
        elif self.state=='tail':
            if (self.tail_index>=len(self.tail_frames)
                    or data!=self.tail_frames[self.tail_index]):
                raise ValueError('Aggregate projection tail framing differs')
            self.tail_index+=1
            if self.tail_index==len(self.tail_frames):self.state='done'
        else:raise ValueError('Aggregate projection has extra bytes')
        return size

    def finish(self):
        if (self.state!='done' or self.row_index!=len(self.refs)
                or self.tail_index!=len(self.tail_frames)):
            raise ValueError('Aggregate projection is incomplete')
        return self.semantic.finish(),_finalize_row_projection(self.projection)


@contextmanager
def streaming_publication_context(root=ROOT):
    """Authenticate the active aggregate, then expose bounded repeatable rows."""
    root=Path(root);epoch=engine.source_epoch(root);spec=engine.specification(root)
    contract=engine.contract_identity(spec,epoch,root=root)
    folder=root/'build/coupled-railway'/contract
    if json.loads((folder/'source-contract.json').read_bytes())!=engine.state_source_contract(contract,epoch,root=root):
        raise ValueError('Source-matched v2 coordinated state required')
    snapshot,pointer=engine.current_aggregate(folder,contract)
    _,core,refs=aggregate_store._load_store(snapshot,root=root)
    value=aggregate_store._core_value(core)
    sink=_SemanticProjectionSink(core,value,refs)
    manifest=aggregate_store.read(snapshot,folder/'cases',sink,root=root)
    if (manifest['manifest_id']!=pointer['manifest_id']
            or manifest['aggregate_sha256']!=pointer['aggregate_sha256']
            or manifest['run_id']!=pointer['run_id']):
        raise ValueError('Active aggregate pointer and verified parent differ')
    semantic_id,projection=sink.finish()
    rows=_VerifiedRows(root,folder/'cases',refs)
    if (value['contract_id']!=contract or value['source_sha256']!=epoch
            or value['specification']!=spec or len(rows)!=len(value['bundles'])
            or value['campaign_id']!=semantic_id):
        raise ValueError('Source-matched coordinated execution or complete comparison required')
    value['rows']=rows
    projection['aggregate_sha256']=pointer['aggregate_sha256']
    yield folder,value,projection


def _potential_current_refinement(root,folder,value,projection):
    """Skip full-parent readers only when every bounded request excludes this parent.

    This is a presence preflight, never refinement verification or admission.
    An unsafe or unrecognized receipt remains an explicit hold.
    """
    from . import railway_refinement_current as producer
    root=Path(root).resolve();folder=Path(folder)
    _,pointer=engine.current_aggregate(folder,value['contract_id'])
    if (pointer['aggregate_sha256']!=projection.get('aggregate_sha256')
            or pointer['run_id']!=value['run_id']):
        raise ValueError('Active aggregate changed after streamed authentication')
    candidate_root=root/'build/coupled-railway/refinements'/producer.CANDIDATE_ID
    for ancestor in (candidate_root,*candidate_root.parents):
        if ancestor==root:break
        if ancestor.is_symlink():raise ValueError('Refinement preflight path is a symlink')
    if not candidate_root.exists():
        _,after_pointer=engine.current_aggregate(folder,value['contract_id'])
        if after_pointer!=pointer:raise ValueError('Active aggregate changed during refinement preflight')
        return False
    if not stat.S_ISDIR(candidate_root.stat(follow_symlinks=False).st_mode):
        raise ValueError('Refinement preflight candidate root is not an ordinary directory')
    def hex_id(item):
        return isinstance(item,str) and len(item)==64 and all(c in '0123456789abcdef' for c in item)
    def ordinary_source(name):
        if not isinstance(name,str) or not name or '\\' in name:return False
        path=PurePosixPath(name)
        return not path.is_absolute() and '..' not in path.parts and path.as_posix()==name
    matching=False;inspected=[]
    for count,directory in enumerate(sorted(candidate_root.iterdir()),1):
        if count>MAX_REFINEMENT_PREFLIGHT_REQUESTS:
            raise ValueError('Refinement preflight request budget exceeded')
        if not stat.S_ISDIR(directory.stat(follow_symlinks=False).st_mode):
            raise ValueError('Refinement preflight entry is not an ordinary directory')
        request_path=directory/'request.json'
        try:info=request_path.stat(follow_symlinks=False)
        except OSError as error:raise ValueError('Refinement preflight request is missing') from error
        if (not stat.S_ISREG(info.st_mode) or info.st_nlink!=1
                or info.st_size>MAX_REFINEMENT_PREFLIGHT_BYTES):
            raise ValueError('Refinement preflight request is unsafe or exceeds budget')
        raw=request_path.read_bytes()
        after=request_path.stat(follow_symlinks=False)
        if (len(raw)!=info.st_size or any(getattr(info,key)!=getattr(after,key)
                for key in ('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns'))):
            raise ValueError('Refinement preflight request changed while reading')
        inspected.append((directory.name,request_path,after))
        try:request=json.loads(raw,object_pairs_hook=engine.case_node_store._unique_pairs)
        except (ValueError,UnicodeError) as error:raise ValueError('Refinement preflight request is malformed') from error
        if (not isinstance(request,dict) or encoded(request)!=raw
                or request.get('schema') not in REFINEMENT_REQUEST_SCHEMAS
                or not hex_id(directory.name) or identity(request)!=directory.name
                or request.get('body_candidate_id')!=producer.CANDIDATE_ID
                or any(not hex_id(request.get(key)) for key in
                    ('parent_result_sha256','parent_contract_id','parent_campaign_id','parent_run_id'))
                or not isinstance(request.get('source_sha256'),dict)
                or not request['source_sha256']
                or any(not ordinary_source(name) or not hex_id(h)
                    for name,h in request['source_sha256'].items())):
            raise ValueError('Refinement preflight receipt identity or domain differs')
        matching|=request['parent_result_sha256']==pointer['aggregate_sha256']
    if sorted(path.name for path in candidate_root.iterdir())!=sorted(name for name,_,_ in inspected):
        raise ValueError('Refinement preflight inventory changed while reading')
    for _,path,before in inspected:
        after=path.stat(follow_symlinks=False)
        if any(getattr(before,key)!=getattr(after,key)
                for key in ('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns')):
            raise ValueError('Refinement preflight request changed after reading')
    _,after_pointer=engine.current_aggregate(folder,value['contract_id'])
    if after_pointer!=pointer:raise ValueError('Active aggregate changed during refinement preflight')
    return matching


def _body_response(native,body_id):
    cases=[r for r in native['body_results'] if r['body_candidate_id']==body_id]
    normal=next((r['raw'] for r in cases if r['case']=='normal'),{})
    fine=next((r['raw'] for r in cases if r['case']=='normal-fine'),{})
    refined=next((r['raw'] for r in cases if r['case']=='normal-refined'),{})
    a=normal.get('maximum_displacements',{}).get('vertical_m');b=fine.get('maximum_displacements',{}).get('vertical_m');extra=refined.get('maximum_displacements',{}).get('vertical_m')
    before,last=(b,extra) if extra is not None else (a,b)
    change=None if before is None or last is None else abs(before-last)/max(abs(last),1e-30)
    valid=all(r['raw'].get('numerical_validity')=='equilibrium_energy_confirmed_only' for r in cases) and len(cases)>=3
    hold=native['body_admission'].get(body_id,{}).get('computational_hold')
    return dict(native_cases=len(cases),normal_vertical_m=a,fine_vertical_m=b,extra_refined_vertical_m=extra,relative_vertical_refinement_change=change,
        mesh_levels=[dict(case=r['case'],mesh_m=r['mesh_m'],evaluation_id=r['evaluation_id'],maximum_displacements=r['raw'].get('maximum_displacements')) for r in cases],
        numerical_status='equilibrium/energy checked; maxima refinement reported' if valid else 'unconfirmed' if cases else 'computational resource hold' if hold else 'full-body model not admitted',
        engineering_screen='unknown',full_body_qualified=False)


def _cost_simulation_completion(row):
    """Audit the declared cost simulation without promoting physical evidence."""
    estimate=row.get('economics',{}).get('model_cost',{})
    candidate_id=row['candidate_id']
    required=set(engine.model_cost.SCOPES)
    totals=estimate.get('scope_totals_iqd',{})
    lines=estimate.get('cost_line_items',[])
    assumptions_id=estimate.get('assumption_id')
    complete=(estimate.get('candidate_id')==candidate_id
        and estimate.get('model_cost_complete_for_declared_case') is True
        and estimate.get('model_cost_missing_scopes')==[]
        and set(estimate.get('required_cost_scopes',[]))==required
        and set(totals)==required
        and all(isinstance(totals.get(scope),list) and len(totals[scope])==3
                and all(isinstance(x,(int,float)) and isfinite(x) and x>=0 for x in totals[scope])
                and totals[scope][0]<=totals[scope][1]<=totals[scope][2] and totals[scope][1]>0
                for scope in required)
        and bool(assumptions_id) and bool(estimate.get('source_sha256'))
        and bool(lines) and all(line.get('candidate_id')==candidate_id
            and line.get('scope') in required and line.get('source_ids')
            and isinstance(line.get('calculation_basis'),str) and line['calculation_basis'].strip()
            and set(line.get('scenario_iqd',{}))=={'low','base','high'}
            and all(isinstance(x,(int,float)) and isfinite(x) and x>=0
                    for x in line.get('scenario_iqd',{}).values())
            for line in lines)
        and {line.get('scope') for line in lines}==required)
    return dict(candidate_id=candidate_id,
        simulation_complete=complete,
        simulation_scope='Candidate-bound Class C manufacturing, delivery, civil and lifecycle cost scenario; 14 declared cost scopes.',
        simulation_input_basis='Source-linked quantities and explicitly identified Class C assumptions; supplier quotations are not required for this provisional calculation.',
        assumption_id=assumptions_id,
        integrated_force_driven_journey_complete=row.get('physical_journey_completed') is True,
        engineering_validated=False,
        engineering_validation_state='open',
        engineering_validation_basis='Cost estimates and numerical screens do not supply independently reviewed physical qualification evidence.',
        approved_for_manufacture_or_operation=False,
        approval_state='not-approved',
        approval_basis='Requires completed engineering and safety evidence plus independent release approval.')


def completion_summary(rows):
    records=[_cost_simulation_completion(row) for row in rows]
    return completion_summary_from_records(records)


def completion_summary_from_records(records):
    return dict(candidate_count=len(records),
        simulation_scope='The simulation-complete flag applies to the declared 14-scope Class C cost scenario only. Integrated force-driven journey simulation is reported separately.',
        simulation_complete=sum(r['simulation_complete'] for r in records),
        integrated_force_driven_journey_complete=sum(r['integrated_force_driven_journey_complete'] for r in records),
        engineering_validated=sum(r['engineering_validated'] for r in records),
        approved_for_manufacture_or_operation=sum(r['approved_for_manufacture_or_operation'] for r in records),
        candidate_states=records)


def _retain_exact_prior_body_cases(root,value,out,native_index):
    """Carry forward prior solves only when their exact physical request matches."""
    root=Path(root);out=Path(out)
    body_by_id={b['candidate_id']:b for b in value['bodies']}
    bundle_by_id={b['candidate_id']:b for b in value['bundles']}
    spec=value['specification'];cases=dict(zip(spec['body_cases'],spec['body_mesh_m']))
    expected={
        'normal':('normal',cases['normal']),
        'normal-fine':('normal',cases['normal-fine']),
        'crowd':('crowd',cases['crowd']),
        'normal-refined':('normal',cases['normal-fine']*spec['numerical_refinement']['factor']),
    }
    seen={r['raw_result']['evaluation_id'] for r in native_index if r.get('kind') in ('body','body-refinement','body-exact-cache-reuse')}
    reused=[];rejections=[]
    previous_root=root/'build/coupled-railway/replaced-publications'
    for publication in sorted(previous_root.glob('*/native-index.json')):
        folder=publication.parent
        try:
            receipt=json.loads((folder/'manifest.json').read_bytes())
            if receipt['manifest_id']!=identity({k:v for k,v in receipt.items() if k!='manifest_id'}):
                raise ValueError('prior publication receipt identity differs')
            indexed=json.loads(publication.read_bytes())
            if receipt['files_sha256'].get('native-index.json')!=digest(publication):
                raise ValueError('prior native index hash differs')
        except (OSError,KeyError,ValueError) as error:
            rejections.append(dict(publication=folder.name,reason=str(error)));continue
        for item in indexed:
            if item.get('kind') not in ('body','body-refinement'):
                continue
            raw_result=item.get('raw_result',{});evaluation_id=raw_result.get('evaluation_id')
            if evaluation_id in seen:
                continue
            try:
                archive_path=folder/item['archive']
                if receipt['files_sha256'].get(item['archive'])!=digest(archive_path):
                    raise ValueError('prior native archive hash differs')
                with tarfile.open(archive_path) as tar:
                    names=set(tar.getnames())
                    if not {'archive-index.json','manifest.json','result.json'}<=names:
                        raise ValueError('prior native archive is incomplete')
                    archive_index=json.loads(tar.extractfile('archive-index.json').read())
                    manifest=json.loads(tar.extractfile('manifest.json').read())
                    result=json.loads(tar.extractfile('result.json').read())
                    if manifest!=item['raw_manifest'] or result!=raw_result:
                        raise ValueError('prior index and archived native records differ')
                    if manifest['manifest_id']!=identity({k:v for k,v in manifest.items() if k!='manifest_id'}):
                        raise ValueError('prior native receipt identity differs')
                    if result.get('evaluation_id')!=identity({k:v for k,v in result.items() if k!='evaluation_id'}):
                        raise ValueError('prior native result identity differs')
                    archived_hashes={**archive_index['retained_sha256'],**archive_index['omitted_sha256']}
                    if manifest['files_sha256']!={k:v for k,v in archived_hashes.items() if k!='manifest.json'}:
                        raise ValueError('prior native archive index differs from its receipt')
                    for name,expected_hash in archive_index['retained_sha256'].items():
                        if sha256(tar.extractfile(name).read()).hexdigest()!=expected_hash:
                            raise ValueError('prior archived native payload differs: '+name)
                if manifest.get('source_sha256')!=result.get('source_sha256'):
                    raise ValueError('prior native source receipt differs')
                if any(digest(root/name)!=h for name,h in result['source_sha256'].items()):
                    raise ValueError('prior native physics source is no longer exact')
                tool=result['tool']
                if digest(tool['ccx_path'])!=tool['ccx_sha256']:
                    raise ValueError('prior native solver executable differs')
                if (tool.get('requested_memory_mb')!=spec['maximum_native_memory_mb']
                        or tool.get('timeout_s')!=spec['body_timeout_s']):
                    raise ValueError('prior native resource request differs')
                body_id=result['candidate_id'];body=body_by_id.get(body_id)
                mesh_summary=result['mesh_summary'];basis=mesh_summary['load_basis']
                bundle=bundle_by_id.get(basis.get('bundle_id'))
                if body is None or bundle is None or bundle['body_candidate_id']!=body_id:
                    raise ValueError('prior native physical candidate is not in this campaign')
                if basis.get('bundle_definition_id')!=bundle['definition_id'] or mesh_summary.get('candidate_id')!=body_id:
                    raise ValueError('prior native body/bundle identity differs')
                if basis.get('scope')!=bundle['mass_scope']:
                    raise ValueError('prior native mass scope differs')
                load_case=mesh_summary['load_case'];mesh=float(mesh_summary['mesh_m'])
                if load_case=='crowd':case='crowd'
                elif abs(mesh-cases['normal'])<1e-10:case='normal'
                elif abs(mesh-cases['normal-fine'])<1e-10:case='normal-fine'
                elif abs(mesh-cases['normal-fine']*spec['numerical_refinement']['factor'])<1e-10:case='normal-refined'
                else:raise ValueError('prior native load/mesh pair is outside the current request set')
                if expected[case]!=(load_case,mesh):
                    raise ValueError('prior native case label and requested mesh differ')
                expected_mass=(bundle['crowd_sprung_mass_hypothesis_kg'] if case=='crowd'
                               else bundle['normal_sprung_mass_hypothesis_kg'])
                if abs(mesh_summary['load_mass_kg']-expected_mass)>1e-7:
                    raise ValueError('prior native load mass differs from this exact bundle')
                target=out/item['archive'].replace('native/','native/reused-',1)
                target.parent.mkdir(parents=True,exist_ok=True)
                if target.exists() and digest(target)!=digest(archive_path):
                    raise ValueError('reused native archive target already has different bytes')
                if not target.exists():shutil.copyfile(archive_path,target)
                native_index.append(dict(kind='body-exact-cache-reuse',job_id=item.get('job_id'),archive=target.relative_to(out).as_posix(),
                    source_publication=folder.relative_to(root).as_posix(),source_manifest_id=receipt['manifest_id'],
                    raw_manifest=manifest,raw_result=result,
                    reuse_basis='Exact body candidate, physical definition, bundle/load basis, mesh, solver executable, resource request and native physics source hashes match; no new solve was dispatched.'))
                reused.append(dict(body_candidate_id=body_id,bundle_id=bundle['candidate_id'],case=case,mesh_m=mesh,
                    evaluation_id=evaluation_id,raw=result,exact_prior_reuse=dict(source_manifest_id=receipt['manifest_id'],
                        source_archive=item['archive'],native_job_id=item.get('job_id'))))
                seen.add(evaluation_id)
            except (OSError,KeyError,ValueError,TypeError) as error:
                rejections.append(dict(publication=folder.name,evaluation_id=evaluation_id,reason=str(error)))
    return reused,rejections


def _current_refinement(root, value, parent_result=None):
    """Load the exact current-source continuation when its sealed package exists."""
    from . import railway_refinement_current, railway_refinement_current_verifier
    requested = _requested_refinement_frontier(
        value, railway_refinement_current.CANDIDATE_ID,
        railway_refinement_current.NEXT_MESH_M)
    if requested is None:
        return None
    parent = (Path(root) / 'build/coupled-railway' / value['contract_id'] / 'result.json'
              if parent_result is None else Path(parent_result))
    context = railway_refinement_current._context(
        root, parent_result=parent, candidate_id=railway_refinement_current.CANDIDATE_ID)
    if context[5] != requested:
        raise ValueError('Current refinement context differs from the active publication frontier')
    request = railway_refinement_current._request(context[0], context[2], context[3], context[4],
        context[5], context[6], context[7])
    folder = railway_refinement_current._package(root, request)
    if not folder.exists():
        return None
    verified = railway_refinement_current_verifier.verify(
        root, parent_result=parent, candidate_id=railway_refinement_current.CANDIDATE_ID)
    return dict(folder=folder, request=json.loads((folder/'request.json').read_bytes()),
        result=json.loads((folder/'native/result.json').read_bytes()),
        report=json.loads((folder/'report.json').read_bytes()),
        manifest=json.loads((folder/'manifest.json').read_bytes()), verified=verified)


def _current_fine_refinement(root, value, parent_result=None):
    from . import railway_refinement_current_fine_reconcile as reconciler
    from . import railway_refinement_current as current_refinement
    from . import railway_refinement_current_fine as fine_producer
    requested = _requested_refinement_frontier(
        value, reconciler.CANDIDATE_ID, current_refinement.NEXT_MESH_M)
    if requested is None:
        return None
    parent=(Path(root)/'build/coupled-railway'/value['contract_id']/'result.json'
            if parent_result is None else Path(parent_result))
    try:
        verification=fine_producer.verify(root,parent_result=parent,candidate_id=reconciler.CANDIDATE_ID)
    except ValueError as error:
        if 'Current-source fine refinement package is missing' not in str(error):
            raise
    else:
        direct_request_id=verification['request_id']
        direct_folder=Path(root)/'build/coupled-railway/refinements'/reconciler.CANDIDATE_ID/direct_request_id
        direct_request=json.loads((direct_folder/'request.json').read_bytes())
        result=json.loads((direct_folder/'native/result.json').read_bytes())
        report=json.loads((direct_folder/'report.json').read_bytes())
        manifest=json.loads((direct_folder/'manifest.json').read_bytes())
        if (identity(direct_request)!=direct_request_id
                or verification.get('manifest_id')!=manifest.get('manifest_id')):
            raise ValueError('Direct fine-refinement verification differs from its exact request')
        return dict(folder=direct_folder,raw_folder=direct_folder,request=direct_request,
            result=result,report=report,manifest=manifest,verification=verification,
            package_kind='direct-native')
    base=Path(root)/'build/coupled-railway/reconciliations'/reconciler.CANDIDATE_ID
    receipts=sorted(p for p in base.glob('*/manifest.json') if p.is_file())
    if not receipts:return None
    parent_sha=digest(parent)
    matching=[]
    for receipt in receipts:
        folder=receipt.parent
        try:
            request=json.loads((folder/'request.json').read_bytes())
        except (OSError,ValueError,TypeError):
            # Keep unrelated or incomplete receipts in build state as provenance.
            continue
        if (identity(request)==folder.name
                and request.get('schema')=='osr-current-source-fine-refinement-request/1'
                and request.get('body_candidate_id')==reconciler.CANDIDATE_ID
                and request.get('mesh_m')==reconciler.MESH_M
                and request.get('parent_result_sha256')==parent_sha
                and request.get('parent_contract_id')==value.get('contract_id')
                and request.get('parent_campaign_id')==value.get('campaign_id')
                and request.get('parent_run_id')==value.get('run_id')
                and request.get('parent_frontier_item')==requested):
            matching.append((folder,request))
    if not matching:return None
    if len(matching)!=1:raise ValueError('Expected one exact current-source fine-refinement reconciliation for this parent request')
    folder,request=matching[0]
    verification=reconciler.verify(root,parent_result=parent,candidate_id=reconciler.CANDIDATE_ID,
        request_id=identity(request))
    request_id=identity(request)
    return dict(folder=folder,raw_folder=root/'build/coupled-railway/refinements'/reconciler.CANDIDATE_ID/request_id,
        request=request,result=json.loads((folder/'result.json').read_bytes()),
        report=json.loads((folder/'report.json').read_bytes()),
        manifest=json.loads((folder/'manifest.json').read_bytes()),verification=verification,
        package_kind='reconciled-native')


def _current_ultrafine_refinement(root, value, refinement, fine_refinement, parent_result=None):
    """Load the exact current-source 0.053125 m continuation when published."""
    from . import railway_refinement_current_ultrafine as producer
    requested = next((row for row in _published_frontier(value, refinement, fine_refinement)
        if row.get('kind') == 'unresolved-numerical-refinement'
        and row.get('body_candidate_id') == producer.CANDIDATE_ID
        and row.get('proposed_next_mesh_m') == producer.MESH_M), None)
    if requested is None:
        return None
    parent = (Path(root) / 'build/coupled-railway' / value['contract_id'] / 'result.json'
              if parent_result is None else Path(parent_result))
    if not parent.is_file():
        return None
    parent_sha = digest(parent)
    candidate_root = Path(root) / 'build/coupled-railway/refinements' / producer.CANDIDATE_ID
    matching = []
    for request_path in candidate_root.glob('*/request.json'):
        try:
            stored = json.loads(request_path.read_bytes())
        except (OSError, ValueError, TypeError):
            continue
        if (stored.get('schema') == 'osr-current-source-ultrafine-refinement-request/1'
                and stored.get('mesh_m') == producer.MESH_M
                and stored.get('parent_contract_id') == value.get('contract_id')
                and stored.get('parent_result_sha256') == parent_sha
                and stored.get('source_sha256',{}).get(producer.PRODUCER)==digest(root/producer.PRODUCER)
                and all((Path(root)/name).is_file() and digest(Path(root)/name)==source_hash
                        for name,source_hash in stored.get('source_sha256',{}).items())
                and request_path.parent.name == identity(stored)):
            matching.append(request_path.parent)
    if not matching:
        return None
    if len(matching) != 1:
        raise ValueError('Expected one exact ultrafine package for the current parent result')
    verification = producer.verify(root, parent_result=parent, candidate_id=producer.CANDIDATE_ID)
    folder = matching[0]
    request = json.loads((folder/'request.json').read_bytes())
    if verification.get('request_id') != identity(request):
        raise ValueError('Stored ultrafine package identity differs from the verified current request')
    result = json.loads((folder/'native/result.json').read_bytes())
    report = json.loads((folder/'report.json').read_bytes())
    manifest = json.loads((folder/'manifest.json').read_bytes())
    return dict(folder=folder, raw_folder=folder, request=request,
        result=result, report=report, manifest=manifest,
        verification=verification, package_kind='direct-native')


def _requested_refinement_frontier(value, candidate_id, mesh_m):
    """Return the exact bounded continuation request, if this parent asks for it."""
    return next((task for task in value.get('frontier', [])
        if task.get('kind')=='unresolved-numerical-refinement'
        and task.get('body_candidate_id')==candidate_id
        and task.get('proposed_next_mesh_m')==mesh_m),None)


def _published_frontier(value, refinement, fine_refinement=None, ultrafine_refinement=None):
    tasks=deepcopy(value['frontier'])
    next_run=(ultrafine_refinement if ultrafine_refinement is not None else
        fine_refinement if fine_refinement is not None else refinement)
    if next_run is None:
        return tasks
    execution=next_run['result'].get('execution')
    if execution!='completed':
        if execution=='solver_allocation_failed':
            body_id=next_run['report']['body_candidate_id']
            for task in tasks:
                if task.get('kind')=='unresolved-numerical-refinement' and task.get('body_candidate_id')==body_id:
                    task['state']='bounded-solver-allocation-failed; refinement-unresolved'
                    task['failed_evaluation_id']=next_run['result'].get('evaluation_id')
                    task['proposed_next_mesh_m']=next_run['request'].get('mesh_m')
                    task['computational_cell_estimate']=next_run['request'].get('computational_cell_estimate')
                    memory_gib=next_run['request'].get('memory_mb',0)/1024
                    task['resource_failure']=f"CalculiX allocator failure under the recorded {memory_gib:g} GiB address-space cap; no numerical result produced"
                    task['physical_failure_inferred']=False
                    task['required']=[
                        'Preserve this single failed native attempt and its exact source/deck/logs',
                        'Assess a more memory-efficient solver or a separately available resource envelope before any new invocation',
                        'Keep structural strength, joint, fatigue, buckling, clearance and physical validation as separate gates']
        return tasks
    report=next_run['report'];body_id=report['body_candidate_id']
    # Keep the original task if the run did not establish numerical validity.
    if next_run['result'].get('numerical_validity')!='equilibrium_energy_confirmed_only':
        for task in tasks:
            if task.get('kind')=='unresolved-numerical-refinement' and task.get('body_candidate_id')==body_id:
                task['state']='completed-run-invalid-or-unconfirmed; diagnosis-required'
                task['completed_evaluation_id']=next_run['result']['evaluation_id']
        return tasks
    tasks=[task for task in tasks if not (task.get('kind')=='unresolved-numerical-refinement' and task.get('body_candidate_id')==body_id)]
    comparison_mesh=(0.10625 if ultrafine_refinement is not None else
        0.2125 if fine_refinement is not None else 0.425)
    comparison=next((x for x in report['matched_point_displacement_comparisons']
                     if x.get('from_mesh_m')==comparison_mesh and x.get('status')=='compared'),None)
    changes={} if comparison is None else {k:v['maximum_relative_to_fine_component']
        for k,v in comparison.get('components',{}).items()}
    threshold=value['specification']['numerical_refinement']['trigger_relative_change']
    if changes and max(changes.values())>threshold:
        body=next(b for b in value['bodies'] if b['candidate_id']==body_id)
        next_mesh=(0.0265625 if ultrafine_refinement is not None else
            0.053125 if fine_refinement is not None else 0.10625)
        from . import railway_native
        estimate=railway_native.cell_estimate(body,next_mesh)
        tasks.append(dict(kind='unresolved-numerical-refinement',body_candidate_id=body_id,state='explicit-resource-revision-required',
            evidence_ids=[x['evaluation_id'] for x in report['mesh_and_residual_trend'] if x['mesh_m'] in (comparison_mesh,report['generated_mesh']['mesh_m'])],
            component_relative_changes=changes,trigger_relative_change=threshold,proposed_next_mesh_m=next_mesh,
            computational_cell_estimate=estimate,previous_mesh_budget_cells=next_run['request']['computational_cell_budget'],
            next_mesh_exceeds_previous_cell_budget=estimate['solid_cells']>next_run['request']['computational_cell_budget'],
            numerical_run_id=next_run['result']['evaluation_id'],physical_failure_inferred=False,
            required=[f"Assess a separately bounded {next_mesh:.6g} m resource request ({estimate['solid_cells']} estimated cells; previous allowance {next_run['request']['computational_cell_budget']})",
                      'Compare matched-point displacement and residual trends with this exact current-source result',
                      'Keep stress, joint strength, fatigue, buckling, clearance and physical validation as separate gates']))
    return tasks


def _published_refinements_match(out, refinement, fine_refinement, ultrafine_refinement=None):
    """Do the published continuation receipts match the current build inputs?"""
    expected = (
        ('current-refinement.json.gz', refinement),
        ('fine-refinement.json.gz', fine_refinement),
        ('ultrafine-refinement.json.gz', ultrafine_refinement),
    )
    for filename, package in expected:
        path = Path(out) / filename
        if not path.is_file():
            return False
        try:
            published = json.loads(gzip.decompress(path.read_bytes()))
        except (OSError, EOFError, gzip.BadGzipFile, json.JSONDecodeError):
            return False
        published_id = None if published is None else published.get('manifest', {}).get('manifest_id')
        expected_id = None if package is None else package.get('manifest', {}).get('manifest_id')
        if published_id != expected_id:
            return False
    return True


def _retain_prior_historical_packets(root, out, value, native, epochs):
    """Carry exact historical evidence forward when local build caches are absent."""
    root=Path(root);out=Path(out);seen={x.get('raw_result',{}).get('evaluation_id') or x.get('raw_result',{}).get('candidate_id') for x in native}
    candidates=[]
    for folder in sorted((root/'build/coupled-railway/replaced-publications').glob('*/')):
        manifest_path=folder/'manifest.json';summary_path=folder/'summary.json'
        if not manifest_path.is_file() or not summary_path.is_file():continue
        try:
            manifest=json.loads(manifest_path.read_bytes());s=json.loads(summary_path.read_bytes())
            actual={p.relative_to(folder).as_posix():digest(p) for p in folder.rglob('*') if p.is_file() and p!=manifest_path}
            if (s.get('campaign_id')==value['campaign_id']
                    and manifest.get('manifest_id')==identity({k:v for k,v in manifest.items() if k!='manifest_id'})
                    and manifest.get('files_sha256')==actual):
                candidates.append((folder,s,manifest))
        except (OSError,KeyError,ValueError,TypeError):
            continue
    if not candidates:return
    # Older source-bound packets are immutable; only unique historical evidence
    # absent from the current build cache is copied into the new receipt.
    for folder,_summary,_manifest in candidates:
        old_epochs=json.loads((folder/'source-epochs.json').read_bytes())
        for item in json.loads((folder/'native-index.json').read_bytes()):
            if item.get('kind') not in ('historical-CAD','historical-resource-or-numerical-failure','transient-method'):
                continue
            result=item.get('raw_result',{});evaluation_id=result.get('evaluation_id') or result.get('candidate_id')
            if evaluation_id in seen:continue
            for name,h in result.get('source_sha256',item.get('raw_manifest',{}).get('source_sha256',{})).items():
                path=root/name
                if (path.is_file() and digest(path)==h) or h in epochs:continue
                source=old_epochs.get(h)
                if source is None:raise ValueError('Prior historical packet lacks its exact source bytes')
                raw=folder/source['artifact']
                if digest(raw)!=h:raise ValueError('Prior historical source archive differs')
                (out/'historical-sources').mkdir(exist_ok=True);target='historical-sources/'+h
                if not (out/target).exists():shutil.copyfile(raw,out/target)
                epochs[h]=dict(repository_path=source.get('repository_path',name),artifact=target)
            suffix=(evaluation_id or identity(item))[:12]
            target=f"native/retained-{item['kind']}-{suffix}.tar.gz"
            if not (out/target).exists():shutil.copyfile(folder/item['archive'],out/target)
            native.append(dict(item,archive=target))
            seen.add(evaluation_id)


def _prior_magnetic_summary(root,value):
    root=Path(root)
    for folder in sorted((root/'build/coupled-railway/replaced-publications').glob('*/')):
        manifest_path=folder/'manifest.json';summary_path=folder/'summary.json';payload=folder/'magnetic-method.json.gz'
        if not (manifest_path.is_file() and summary_path.is_file() and payload.is_file()):continue
        try:
            manifest=json.loads(manifest_path.read_bytes());summary_value=json.loads(summary_path.read_bytes())
            actual={p.relative_to(folder).as_posix():digest(p) for p in folder.rglob('*') if p.is_file() and p!=manifest_path}
            if (summary_value.get('campaign_id')!=value['campaign_id']
                    or manifest.get('manifest_id')!=identity({k:v for k,v in manifest.items() if k!='manifest_id'})
                    or manifest.get('files_sha256')!=actual):continue
            cases=json.loads(gzip.decompress(payload.read_bytes()))
            if cases:return cases
        except (OSError,KeyError,ValueError,TypeError):
            continue
    return []


def _new_row_projection():
    return dict(body={},p1={},completion=[],cost_count=0,complete_cost_count=0,
        route_complete=0,route_count=0,stages=0)


def _add_row_projection(projection,row):
    body_id=row['body_candidate_id'];entry=projection['body'].setdefault(body_id,dict(count=0,tare=None))
    entry['count']+=1;projection['stages']+=len(row['stages'])
    if row['family_id']=='P1' and body_id not in projection['p1']:
        entry['tare']=row['accounted_mass']['accounted_tare_kg_per_car']
        projection['p1'][body_id]=dict(candidate_id=row['candidate_id'],stages=row['stages'])
    projection['completion'].append(_cost_simulation_completion(row))
    estimate=row.get('economics',{}).get('model_cost')
    if isinstance(estimate,dict):
        projection['cost_count']+=1
        projection['complete_cost_count']+=estimate.get('model_cost_complete_for_declared_case') is True
        plan=estimate.get('provisional_manufacturing_plan',{})
        projection['route_count']+=plan.get('route_count',0)
        projection['route_complete']+=(plan.get('schema')=='osr-v06-provisional-manufacturing-plan/1'
            and plan.get('route_count')==plan.get('coverage',{}).get('located_stock_occurrences')
            and plan.get('route_count')==plan.get('coverage',{}).get('routed_stock_occurrences')
            and not plan.get('coverage',{}).get('unrouted_stock_ids'))


def _finalize_row_projection(projection):
    return dict(projection,completion=completion_summary_from_records(projection['completion']))


def _row_projection(rows):
    """Retain only summary scalars and one P1 inventory stage per body."""
    projection=_new_row_projection()
    for row in rows:_add_row_projection(projection,row)
    return _finalize_row_projection(projection)


def summary(value,magnetic=None,*,reused_body_cases=(),reuse_rejections=(),refinement=None,fine_refinement=None,ultrafine_refinement=None,row_projection=None):
    new_native_body_case_count=len(value['native']['body_results'])
    native=value['native'] if not reused_body_cases else dict(value['native'],body_results=value['native']['body_results']+list(reused_body_cases))
    projection=_row_projection(value['rows']) if row_projection is None else row_projection
    rows=[]
    for b in value['bodies']:
        body_case=projection['body'].get(b['candidate_id'],dict(count=0,tare=None))
        response=_body_response(native,b['candidate_id'])
        rows.append(dict(label=b['label'],body_candidate_id=b['candidate_id'],parent_ids=b['parent_candidate_ids'],
            known_structure_stock_kg=b['known_structure_stock_kg'],accounted_empty_mass_kg=body_case['tare'],
            architecture_cases=body_case['count'],structural_status=response['numerical_status'],response=response,complete_installed_mass_kg=None))
    magnetic=[] if magnetic is None else magnetic
    completion=projection['completion']
    refinement_count=(int(refinement is not None)+int(fine_refinement is not None)
        +int(ultrafine_refinement is not None))
    result=dict(schema='osr-coupled-railway-summary/1',campaign_id=value['campaign_id'],contract_id=value['contract_id'],body_count=len(rows),
        initial_body_count=value['specification']['initial_structural_recipes'],body_rewrite_count=len(value['executed_body_revisions']),
        bundle_count=len(value['bundles']),evaluated_bundle_count=len(value['rows']),downstream_stage_count=projection['stages'],
        body_rows=rows,method_fixture_count=len(value['native']['independent_fixtures']),native_body_case_count=new_native_body_case_count+len(reused_body_cases)+refinement_count,
        CAD_case_count=len(value['native']['CAD_results']),magnetic_method_cases=len(magnetic),magnetic_completed=sum(r['result']['execution']=='completed' for r in magnetic),
        native_new_body_case_count=new_native_body_case_count+refinement_count,
        native_campaign_body_case_count=new_native_body_case_count,
        native_current_source_refinement_count=refinement_count,
        current_source_refinement=None if refinement is None else dict(request_id=refinement['manifest']['request_id'],
            evaluation_id=refinement['result']['evaluation_id'],mesh_m=refinement['report']['generated_mesh']['mesh_m'],
            execution=refinement['result'].get('execution'),numerical_validity=refinement['result'].get('numerical_validity'),
            manifest_id=refinement['manifest']['manifest_id'],physical_and_engineering_acceptance=False),
        current_source_fine_refinement=None if fine_refinement is None else dict(request_id=fine_refinement['manifest']['request_id'],
            evaluation_id=fine_refinement['result']['evaluation_id'],mesh_m=fine_refinement['report']['generated_mesh']['mesh_m'],
            execution=fine_refinement['result'].get('execution'),numerical_validity=fine_refinement['result'].get('numerical_validity'),
            manifest_id=fine_refinement['manifest']['manifest_id'],physical_and_engineering_acceptance=False,
            package_kind=fine_refinement.get('package_kind','reconciled-native')),
        current_source_ultrafine_refinement=None if ultrafine_refinement is None else dict(
            request_id=ultrafine_refinement['manifest']['request_id'],
            evaluation_id=ultrafine_refinement['result']['evaluation_id'],
            mesh_m=ultrafine_refinement['report']['generated_mesh']['mesh_m'],
            execution=ultrafine_refinement['result'].get('execution'),
            numerical_validity=ultrafine_refinement['result'].get('numerical_validity'),
            memory_mb=ultrafine_refinement['request'].get('memory_mb'),
            timeout_s=ultrafine_refinement['request'].get('timeout_s'),
            returncode=ultrafine_refinement['result'].get('returncode'),
            max_rss_kib=ultrafine_refinement['result'].get('max_rss_kib'),
            runtime_s=ultrafine_refinement['result'].get('runtime_s'),
            manifest_id=ultrafine_refinement['manifest']['manifest_id'],
            source_complete=not bool(ultrafine_refinement['result'].get('source_bytes_unavailable')),
            source_bytes_unavailable=ultrafine_refinement['result'].get('source_bytes_unavailable',{}),
            physical_and_engineering_acceptance=False),
        native_reused_body_case_count=len(reused_body_cases),native_prior_reuse_rejections=list(reuse_rejections),
        model_cost_summary=dict(candidate_estimates=projection['cost_count'],complete_for_declared_case=projection['complete_cost_count'],
            currency='IQD',estimate_class='C',required_scope_count=len(engine.model_cost.SCOPES),
            provisional_stock_route_complete_candidates=projection['route_complete'],
            provisional_stock_route_count=projection['route_count'],
            comparison_context_count=len(value.get('model_cost_comparisons',[])),supplier_quotes=0,
            procurement_ready=False,physical_or_safety_accepted=False,integrated_winner=None),
        completion_status=completion,
        actual_force_driven_journeys=0,complete_installed_vehicle_masses=0,complete_lifecycle_costs=0,
        frontier_tasks=len(_published_frontier(value,refinement,fine_refinement,ultrafine_refinement)),dependency_graph=value['dependency_graph'],selection=value['partial_quantity_comparison'],
        integrated_selection=None,selected_reference_changed=False,city_performance_packages_written=0,**FLAGS)
    return result


def readme(s):
    ultrafine=s.get('current_source_ultrafine_refinement')
    ultrafine_source_status=('Exact producer source bytes are included with the recovered report.'
        if ultrafine and ultrafine.get('source_complete') else
        'The report retains a held source-availability gap.')
    lines=['# One coordinated railway experiment','',
        'Architecture, adaptive revision planning and physical body generation now share one coordinator, one explicit railway bundle and one dependency graph. A body edit creates new body/railway identities and automatically reevaluates inventory, interfaces, architecture, motor requirements, independent braking, civil loads, manufacture and economic coverage. Each alternative keeps its own candidate identity and evidence; results are not transferred between candidates. New coordinated work starts with `./osr design railway`.','',
        f"The executed comparison starts with **{s['initial_body_count']} structural recipes**, makes **{s['body_rewrite_count']} physical revisions**, and evaluates **{s['evaluated_bundle_count']} railway bundles through {s['downstream_stage_count']} downstream stage records**. Two primary-iron alternatives share unchanged onboard fin stock. Seven architecture families retain their own changed interfaces and unweighed equipment. **Class C model-cost estimates cover {s['model_cost_summary']['complete_for_declared_case']} of {s['model_cost_summary']['candidate_estimates']} executed bundles across {s['model_cost_summary']['required_scope_count']} cost scopes. Provisional per-stock process routes cover {s['model_cost_summary']['provisional_stock_route_complete_candidates']} candidate bundles and {s['model_cost_summary']['provisional_stock_route_count']} located stock occurrences.** The process hours remain costing proxies. Installed mass, available operating LIM maps, physical journeys, supplier-priced budgets and a qualified whole-life-cost winner remain open.",'',
        '## Completion levels','',
        f"Each candidate reports three separate completion levels. The declared cost scenario is simulation-complete for **{s['completion_status']['simulation_complete']} of {s['completion_status']['candidate_count']} candidates**, using source-linked quantities and explicit Class C assumptions across 14 scopes. This flag covers that cost scenario only; it does not claim an integrated journey simulation. **{s['completion_status']['integrated_force_driven_journey_complete']}** candidates have a completed force-driven journey, **{s['completion_status']['engineering_validated']}** are engineering-validated, and **{s['completion_status']['approved_for_manufacture_or_operation']}** are approved for manufacture or operation. Engineering validation requires independent physical evidence and review; release requires a separate approval record.",'',
        '## Closed-loop physical and system changes','',
        'The existing adaptive planner diagnoses each declared pin-graph mechanism; the grammar produces a braced physical child instead of changing a pass threshold. A separate assembly-completion operator closes quantified frame/floor/roof gaps using counted metal stock and finite shared-face weld hypotheses. It generates an aluminium frame and an aluminium stressed-skin body, preserving passenger openings and required roof/PV/channel/drain functions. Missing composite laws are not replaced by isotropic GFRP.','',
        '| Body / physical revision | Known structure stock | Empty-mass account | 3D evidence | Architecture cases |',
        '|---|---:|---:|---|---:|']
    for r in s['body_rows']:
        mass='Unknown' if r['accounted_empty_mass_kg'] is None else f"{r['accounted_empty_mass_kg']/1000:.3f} t"
        lines.append(f"| {r['label']} | {r['known_structure_stock_kg']:.1f} kg | {mass} | {r['structural_status']} | {r['architecture_cases']} |")
    lines += ['',
        'These are exact generated nominal/net stock quantities plus retained source accounts. They are not complete vehicle tare or certified lower bounds: original gross-stock overlaps/cuts and missing installed hardware have different boundaries. The new welded children count net disjoint metal, retained covers, PV rails/spacers, trays/gutter/hangers and unknown weld/joint realization separately. Whole installed CG, inertia, clearances, hardware and repair access remain open.','',
        '## Three-dimensional structural method','',
        f"Four independent fixtures check bending/shear refinement, intact finite-face transfer and orthotropic axial/shear constitutive patches. The two new metal bodies have **{s['native_body_case_count']} exact native body cases** across normal, normal-fine and crowd loading: {s['native_new_body_case_count']} dispatched in this coordinated run and {s['native_reused_body_case_count']} carried forward from byte-verified prior publications after matching candidate, load, mesh, solver, resources and source hashes. Reuse is provenance-preserving and does not count as a new solve. C3D8I solids resolve the declared actual metal geometry; no invisible gap ties or arbitrary rigid offsets create the load path. Intact autogenous weld/continuous-face transfer is an unqualified numerical hypothesis.",'',
        '| New solid body | Normal 1.7 m target | Finer 0.85 m | Extra 0.425 m | Last-step change |',
        '|---|---:|---:|---:|---:|']
    for r in s['body_rows']:
        a=r['response']
        if not a['native_cases']:continue
        val=lambda x:'Unknown' if x is None else f'{x*1000:.3f} mm'
        change='Unknown' if a['relative_vertical_refinement_change'] is None else f"{a['relative_vertical_refinement_change']*100:.2f}%"
        lines.append(f"| {r['label']} | {val(a['normal_vertical_m'])} | {val(a['fine_vertical_m'])} | {val(a['extra_refined_vertical_m'])} | {change} |")
    lines += ['',
        'The source-bound resource revision uses 1.7/0.85 m global subdivision targets; thin physical-feature cuts dominate the conformal grid. All actual mesh counts, resources, force/moment/work/energy residuals and failures are retained. A displacement trend is not strength or operating acceptance. C3D8I torsion limitations, quadratic confirmation, local/global buckling, material/HAZ/joint strength, fatigue, modes, thermal/fire/crash behaviour and physical calibration remain necessary work. Equipment loads are currently lumped over the floor with actual structural selfweight; real component positions and suspension compliance are not resolved.','',
        'The first baseline metal-frame job produced 152,004 cells and exceeded its 5 GiB allocation while factoring. It yielded no structural verdict. The generator then standardized and aligned floor/roof extrusion profiles, preserving openings, support pads and actual load paths. These are new physical children with different identities, fewer profile families and roughly 71% fewer conformal cells. The original failed execution, source epoch and CAD remain retained. A 60,000-cell dispatch budget is a computational control, not a railway acceptance rule or proof that the baseline body cannot work.','',
        'The frame\'s first refinement changed the three displacement maxima by about 10-12%. The coordinator therefore requested another unchanged-candidate numerical experiment at a 0.425 m target. Its 61,352-cell estimate justified an explicit computational budget revision to 65,000 cells under the same 5 GiB/150 s limits. Exact unchanged prior solves/CAD are reused across coordinator epochs, with new context records. A 5% refinement trigger requests work; it does not qualify a body. Whole-field, stress, torsion and physical convergence remain separate questions.','',
        (f"The current-source continuation ran the same P1 body and normal-load basis at **{s['current_source_refinement']['mesh_m']:.5g} m** under its 90,000-cell budget, followed by the 0.10625 m C3D8I run using 128,382 cells under an 8 GiB/240 s request. Both completed with equilibrium/energy consistency only. The fine result is included as a {s['current_source_fine_refinement']['package_kind']} package. Matched-point displacement changes remain above the 5% refinement trigger; numerical convergence and physical acceptance remain open." if s.get('current_source_fine_refinement') and s['current_source_fine_refinement']['execution']=='completed' else (f"The current-source continuation completed at **{s['current_source_refinement']['mesh_m']:.5g} m** with equilibrium/energy consistency only. A separate 0.10625 m continuation is not yet published; the exact candidate remains in the frontier." if s.get('current_source_refinement') and s['current_source_refinement']['execution']=='completed' else 'The current-source continuation package is not yet available; the exact 0.2125 m request remains in the frontier.')),'',
        (f"The same body/load was meshed at **0.053125 m** (290,660 C3D8I cells), but CalculiX stopped during matrix factorization with an allocation failure under the recorded {ultrafine['memory_mb']/1024:g} GiB/{ultrafine['timeout_s']} s request. Return code {ultrafine.get('returncode')} and peak RSS {ultrafine.get('max_rss_kib')} KiB are recorded. No numerical result was produced, so refinement remains open. {ultrafine_source_status} The solver attempt was reused from the immutable same-parent deck and logs without a second invocation. This computational limit is not a physical failure or qualification." if ultrafine and ultrafine['execution']=='solver_allocation_failed' else (f"The same unchanged body/load also has a bounded **0.053125 m** C3D8I run ({ultrafine['execution']}; 290,660 cells; {ultrafine['memory_mb']/1024:g} GiB/{ultrafine['timeout_s']} s limit). This is numerical refinement only. Material and joint strength, fatigue, buckling, clearance, physical correlation and engineering qualification remain open." if ultrafine else '')),'',
        'Original foam/honeycomb and GFRP bodies remain non-admitted to this whole-body solver until their own complete directional material laws, attachment stock and joint models are provided. Orthotropic method patches demonstrate implementation, not purchased composite properties.','',
        '## Available propulsion and forward motion','',
        'Every changed mass automatically reaches the 2 km required-force calculation, nine independent-brake loading/fault hypotheses and three crowd-loaded precast alternatives. Rotor equivalent mass enters acceleration and braking; it is excluded from static axle gravity. P6/P7 remove the old passive-secondary account and preserve unknown replacement mass. A candidate-bound available-map gate checks actual position/speed/current/temperature samples, electrical work, thermal/current/voltage domains and normal-force interfaces. No linear, generic DC or synthetic map is silently admitted as an operating motor.','',
        f"A new transient A-z/floating-current kernel executed {s['magnetic_method_cases']} bounded method controls ({s['magnetic_completed']} completed). It uses nonlinear reversible H(B), implicit timesteps, actual phase-current excitation, net-secondary-current closure and explicit stored-energy/Joule/mechanical/discrete-time work. Its finite conductor mask stays fixed at a declared frozen velocity. The generic curve, short secondary, incomplete circuit/copper/thermal model, independent steady/mesh/transit confirmation and actual 20 m/s operating domain prevent it supplying an available-force map. Residual closure is reported without relabelling this fixture as the full LIM.",'',
        'The forward-motion method has independent synthetic tests for constant-force energy, finite powered windows, zero entry force, thermal/bus limits and stopping. Actual railway journeys remain not-run because available propulsion and complete installed inputs are missing. The receiving drive receives no safety credit in independent-braking screens.','',
        '## Manufacturing, economics and evidence','',
        'Each shared bundle produces an EBOM of actual stock, retained accounts and unresolved joints; MBOM cuts/blanks and process groups; assembly/inspection dependencies; material, supplier, access, repair and QA tasks; and source-bound price/lead-time coverage. Missing equipment is neither a box invented for an animation nor a zero-mass part. Quotes require the exact bundle/component/quantity/unit/currency context.','',
        f"The campaign now also produces **{s['model_cost_summary']['required_scope_count']} low/base/high IQD model-cost scopes** per executed candidate: rolling stock, guideway, stations/power, factory/tooling, construction, land/utilities/depot, fleet, energy, operations, maintenance, renewals, recovery, reliability and decommissioning. Each model-cost result includes a candidate-bound provisional process route and low/base/high labor-hour estimate for every located nominal gross body-stock occurrence. Those Class C hours support costing and factory scenarios; they are not measured cycle times or released MBOM routings, and unlocated accounts, joints and final assembly remain separate. Dated July 2026 Iraqi CSO materials/wages are used where matched; the remaining rates and missing site/asset quantities are explicit Class C assumptions. Production capacity and civil scheduling use two 8-hour shifts, with second-shift premiums and per-shift construction productivity included. The low/base operations cases cover 16/18 service hours with two shifts; the high case prices 24-hour service with three shifts, including related staffing, energy, maintenance, reliability and renewal effects. See the [model-based cost and delivery plan](../model-based-cost-and-delivery.md). These are design-stage estimates with zero supplier quotations, not procurement-ready prices or accepted city budgets.", '',
        'The two executed new body CADs also compile candidate-bound delivery packages: the same stock IDs feed EBOM/MBOM, disabled research ERPNext Item/BOM drafts, assembly and procurement tasks, and reopened IFC body-stock geometry. Drafts are not posted to ERPNext and cannot release purchasing or manufacture. Unlocated equipment, unknown joint realization and missing commercial/process evidence remain explicit.','',
        'Candidate cost ranges are compared only where currency, rate assumptions, corridor length, trackways, station count, headway and offered capacity match. Overlapping low/base/high whole-life scenarios remain incomparable; cost dominance does not select a candidate or change the v0.6 reference. Cost inputs include declared energy, staffing, maintenance, replacement, recovery, reliability and end-of-life scenarios. City alignment/site surveys, tariffs, staffing rules, failures, supplier quotes, tax/finance and physical performance are not established. Civil results count axle envelopes, section/tendon quantities and preliminary foundation/erection hypotheses; geotechnical, torsional and construction qualification remain open.','',
        'Immutable stage requests include candidate and upstream evidence IDs. Native cache admission checks source/executable/payload plus exact body, load, mesh, method and resource request. New structural evidence invalidates dependent case evaluations even if geometry is unchanged. Stable experiment identity is separate from invocation cache counters; interrupted/pending work remains in the frontier. Native/CAD packets retain their original receipts.','',
        '```bash','./osr design railway plan','./osr design railway run --max-bundles 2 --native-jobs 1','./osr design railway run --native-jobs 12','./osr design railway publish','./osr design railway verify','```','',
        '[Summary](summary.json) · [Body definitions](bodies.json.gz) · [Canonical bundles](bundles.json.gz) · [Coupled evaluations](comparison.parquet) · [Inventory/manufacturing records](inventories.json.gz) · [Delivery/IFC/ERP drafts](delivery-index.json) · [Native/CAD index](native-index.json) · [Current refinements](current-refinement.json.gz) · [Fine refinement](fine-refinement.json.gz) · [Ultrafine refinement](ultrafine-refinement.json.gz) · [Transient method controls](magnetic-method.json.gz) · [Pending work](frontier.json.gz) · [Source epochs](source-epochs.json) · [Source/payload manifest](manifest.json)','',
        'Large fields and CAD solids stay local or regenerate with exact sources and indexed inputs; no remote artifact object or complete manufacturing/operating release is claimed. The selected reference and all 266 city performance packages remain unchanged.','']
    return '\n'.join(lines)


def build(root=ROOT,output=None):
    root=Path(root);out=root/OUTPUT if output is None else Path(output)
    with streaming_publication_context(root) as (folder,value,row_projection):
        potential_refinement=_potential_current_refinement(root,folder,value,row_projection)
    if potential_refinement:
        with current_context(root) as (refinement_folder,parent_value,parent):
            if (refinement_folder!=folder or parent_value['run_id']!=value['run_id']
                    or parent_value['campaign_id']!=value['campaign_id']):
                raise ValueError('Active aggregate changed before refinement verification')
            refinement=_current_refinement(root,parent_value,parent)
            # Matching packages still pass their existing source-bound verifiers.
            fine_refinement=_current_fine_refinement(root,parent_value,parent) if refinement is not None else None
            ultrafine_refinement=(_current_ultrafine_refinement(root,parent_value,refinement,fine_refinement,parent)
                if fine_refinement is not None else None)
        del parent_value
        _,pointer=engine.current_aggregate(folder,value['contract_id'])
        if (pointer['aggregate_sha256']!=row_projection['aggregate_sha256']
                or pointer['run_id']!=value['run_id']):
            raise ValueError('Active aggregate changed after refinement verification')
    else:
        refinement=fine_refinement=ultrafine_refinement=None
    if (out/'manifest.json').is_file():
        m=json.loads((out/'manifest.json').read_bytes())
        if all(digest(root/n)==h for n,h in m['source_sha256'].items()):
            execution=json.loads((out/'execution.json').read_bytes())
            if (execution.get('contract_id')==value['contract_id']
                    and execution.get('run_id')==value['run_id']
                    and execution.get('campaign_id')==value['campaign_id']
                    and _published_refinements_match(out,refinement,fine_refinement,ultrafine_refinement)):
                return _reader_provenance(verify(root,out),root,executed=True)
    if out.exists():
        _retain_previous_publication(root,out)
    out.mkdir(parents=True);(out/'native').mkdir();native=[];epochs={}
    for i,r in enumerate(value['native']['packet_index']):
        p=folder/'native'/r['raw_path'];target='native/'+str(i)+'.tar.gz';compact_native_archive(p,out/target)
        native.append(dict(kind=r['kind'],job_id=r['job_id'],archive=target,raw_manifest=json.loads((p/'manifest.json').read_bytes()),raw_result=json.loads((p/'result.json').read_bytes())))
    for r in value['native']['CAD_results']:
        p=folder/'native/CAD'/r['candidate_id'];target='native/CAD-'+r['candidate_id'][:12]+'.tar.gz';archive(p,out/target)
        native.append(dict(kind='CAD',archive=target,raw_manifest=json.loads((p/'manifest.json').read_bytes()),raw_result=r))
    cad_ids={r['candidate_id'] for r in value['native']['CAD_results']}
    body_ids={b['candidate_id'] for b in value['bodies']}
    for p in sorted((root/'build/coupled-railway').glob('*/native/CAD/*/manifest.json')):
        r=json.loads((p.parent/'result.json').read_bytes())
        if r['candidate_id'] in cad_ids or r['candidate_id'] not in body_ids:continue
        target='native/historical-CAD-'+r['candidate_id'][:12]+'.tar.gz';archive(p.parent,out/target);cad_ids.add(r['candidate_id'])
        native.append(dict(kind='historical-CAD',archive=target,raw_manifest=json.loads(p.read_bytes()),raw_result=r))
    magnetic_path=root/'build/coupled-railway/transient-method-r1/summary.json'
    magnetic=[] if not magnetic_path.is_file() else json.loads(magnetic_path.read_bytes())
    for i,r in enumerate(magnetic):
        p=root/r['path'];transient_lim.verify(p,root=root);target='native/magnetic-'+str(i)+'.tar.gz';archive(p,out/target)
        native.append(dict(kind='transient-method',archive=target,raw_manifest=json.loads((p/'manifest.json').read_bytes()),raw_result=r['result']))
    seen={r['raw_result'].get('evaluation_id') for r in native}
    for p in sorted((root/'build/coupled-railway').glob('*/native/jobs/*/raw/result.json')):
        r=json.loads(p.read_bytes())
        if r.get('evaluation_id') in seen or r.get('execution')=='completed':continue
        target='native/historical-failed-'+r['evaluation_id'][:12]+'.tar.gz';compact_native_archive(p.parent,out/target);seen.add(r['evaluation_id'])
        native.append(dict(kind='historical-resource-or-numerical-failure',archive=target,raw_manifest=json.loads((p.parent/'manifest.json').read_bytes()),raw_result=r))
    reused_body_cases,reuse_rejections=_retain_exact_prior_body_cases(root,value,out,native)
    if refinement is not None:
        target='native/current-source-refinement.tar.gz';archive(refinement['folder'],out/target)
        native.append(dict(kind='body-current-source-refinement',archive=target,
            raw_manifest=refinement['manifest'],raw_result=refinement['result']))
    if fine_refinement is not None:
        target='native/current-source-fine-refinement.tar.gz';archive(fine_refinement['raw_folder'],out/target)
        native_kind=('body-current-source-fine-refinement' if fine_refinement.get('package_kind')=='direct-native'
            else 'body-current-source-fine-refinement-reconciliation')
        native.append(dict(kind=native_kind,archive=target,
            raw_manifest=fine_refinement['manifest'],raw_result=fine_refinement['result']))
    if ultrafine_refinement is not None:
        target='native/current-source-ultrafine-refinement.tar.gz'
        archive(ultrafine_refinement['raw_folder'],out/target)
        native.append(dict(kind='body-current-source-ultrafine-refinement',archive=target,
            raw_manifest=ultrafine_refinement['manifest'],raw_result=ultrafine_refinement['result']))
    _retain_prior_historical_packets(root,out,value,native,epochs)
    for r in native:
        result=r['raw_result'];manifest=r['raw_manifest']
        for name,h in result.get('source_sha256',manifest.get('source_sha256',{})).items():
            source=root/name
            if source.is_file() and digest(source)==h:continue
            if h in epochs:continue
            if result.get('source_bytes_unavailable',{}).get(name)==h:
                epochs[h]=dict(repository_path=name,artifact=None,availability='unavailable',
                    reason='The exact source bytes were not retained by the failed runner; only the requested digest is known.')
                continue
            original=root/'build/coupled-railway/source-epochs'/h
            if not original.is_file() or digest(original)!=h:raise ValueError('Historical native producer bytes are unavailable')
            (out/'historical-sources').mkdir(exist_ok=True);target='historical-sources/'+h;(out/target).write_bytes(original.read_bytes());epochs[h]=dict(repository_path=name,artifact=target)
    if not magnetic:magnetic=_prior_magnetic_summary(root,value)
    inventories=[];deliveries=[]
    for b in value['bodies']:
        row=row_projection['p1'][b['candidate_id']]
        stage=next(r for r in row['stages'] if r['stage']=='installed_inventory')
        record=engine._read_cached_stage(engine.case_node_store.path_for(folder/'stages',identity(stage['request'])),root=root)
        if record['record_id']!=stage['record_id']:raise ValueError('Inventory stage changed')
        inventories.append(record['output'])
        CAD=next((r for r in value['native']['CAD_results'] if r['candidate_id']==b['candidate_id']),None)
        if CAD is not None:
            bundle=next(x for x in value['bundles'] if x['candidate_id']==row['candidate_id'])
            context=railway_delivery.cache_context(bundle,b,record['output'],CAD)
            target=folder/'delivery-v2'/bundle['candidate_id']/context['cache_context_id']
            if target.exists():
                manifest=json.loads((target/'manifest.json').read_bytes())
                if manifest.get('cache_context')!=context or manifest.get('manifest_id')!=identity({k:v for k,v in manifest.items() if k!='manifest_id'}):raise ValueError('Delivery cache context changed')
                if manifest['files_sha256']!={p.name:digest(p) for p in target.iterdir() if p.is_file() and p.name!='manifest.json'}:raise ValueError('Delivery cache changed')
                if json.loads((target/'bim.json').read_bytes()).get('ifcopenshell_version')!=context['IFC_tool']['version']:raise ValueError('Delivery native IFC version changed')
            else:manifest=railway_delivery.write(target,bundle,b,record['output'],CAD=CAD,context=context)
            prefix='delivery/'+bundle['candidate_id'][:12];(out/prefix).mkdir(parents=True)
            for name in ('delivery.json.gz','ERPNext-draft.json.gz','bim.json','body-stock.ifc.gz'):
                if (target/name).is_file():shutil.copyfile(target/name,out/prefix/name)
            deliveries.append(dict(candidate_id=bundle['candidate_id'],body_candidate_id=b['candidate_id'],prefix=prefix,raw_manifest=manifest))
    s=summary(value,magnetic,reused_body_cases=reused_body_cases,reuse_rejections=reuse_rejections,
        refinement=refinement,fine_refinement=fine_refinement,ultrafine_refinement=ultrafine_refinement,row_projection=row_projection)
    frontier=_published_frontier(value,refinement,fine_refinement,ultrafine_refinement)
    files={'summary.json':encoded(s),'bodies.json.gz':gzip.compress(encoded(value['bodies']),mtime=0),'bundles.json.gz':gzip.compress(encoded(value['bundles']),mtime=0),
        'inventories.json.gz':gzip.compress(encoded(inventories),mtime=0),
        'frontier.json.gz':gzip.compress(encoded(frontier),mtime=0),'magnetic-method.json.gz':gzip.compress(encoded(magnetic),mtime=0),
        'current-refinement.json.gz':gzip.compress(encoded(None if refinement is None else dict(request=refinement['request'],result=refinement['result'],
            report=refinement['report'],manifest=refinement['manifest'],verification=refinement['verified'])),mtime=0),
        'fine-refinement.json.gz':gzip.compress(encoded(None if fine_refinement is None else dict(request=fine_refinement['request'],result=fine_refinement['result'],
            report=fine_refinement['report'],manifest=fine_refinement['manifest'],verification=fine_refinement['verification'],
            package_kind=fine_refinement.get('package_kind','reconciled-native'))),mtime=0),
        'ultrafine-refinement.json.gz':gzip.compress(encoded(None if ultrafine_refinement is None else dict(
            request=ultrafine_refinement['request'],result=ultrafine_refinement['result'],
            report=ultrafine_refinement['report'],manifest=ultrafine_refinement['manifest'],
            verification=ultrafine_refinement['verification'],package_kind='direct-native')),mtime=0),
        'native-index.json':encoded(native),'source-epochs.json':encoded(epochs),'delivery-index.json':encoded(deliveries),'execution.json':encoded(dict(campaign_id=value['campaign_id'],run_id=value['run_id'],contract_id=value['contract_id'],
            new_bundles=value['new_bundles'],reused_bundles=value['reused_bundles'],native=value['native'],
            exact_prior_body_case_reuse=[dict(evaluation_id=r['evaluation_id'],body_candidate_id=r['body_candidate_id'],case=r['case'],source=r['exact_prior_reuse']) for r in reused_body_cases],
            executed_body_revisions=value['executed_body_revisions'])),
        'README.md':readme(s).encode()}
    for name,raw in files.items():(out/name).write_bytes(raw)
    comparison=_write_comparison(root,out/'comparison.parquet',value['rows'])
    m=dict(schema='osr-coupled-railway-publication/2',comparison=comparison,source_sha256={**value['source_sha256'],PRODUCER:digest(root/PRODUCER),
        **{name:digest(root/name) for name in COMPARISON_SOURCES},
        railway_delivery.PRODUCER:digest(root/railway_delivery.PRODUCER),'engineering/design_search/wheel_twin.py':digest(root/'engineering/design_search/wheel_twin.py'),
        'engineering/design_search/generative_publication.py':digest(root/'engineering/design_search/generative_publication.py'),
        'engineering/design_search/native_archive_stream.py':digest(root/'engineering/design_search/native_archive_stream.py'),
        'engineering/design_search/railway_refinement_current.py':digest(root/'engineering/design_search/railway_refinement_current.py'),
        'engineering/design_search/railway_refinement_current_verifier.py':digest(root/'engineering/design_search/railway_refinement_current_verifier.py'),
        'engineering/design_search/railway_refinement_current_fine.py':digest(root/'engineering/design_search/railway_refinement_current_fine.py'),
        'engineering/design_search/railway_refinement_current_ultrafine.py':digest(root/'engineering/design_search/railway_refinement_current_ultrafine.py'),
        'engineering/design_search/railway_native_execution.py':digest(root/'engineering/design_search/railway_native_execution.py'),
        'engineering/design_search/railway_refinement_current_fine_reconcile.py':digest(root/'engineering/design_search/railway_refinement_current_fine_reconcile.py')},
        files_sha256={p.relative_to(out).as_posix():digest(p) for p in out.rglob('*') if p.is_file()},**FLAGS)
    m['manifest_id']=identity(m);(out/'manifest.json').write_bytes(encoded(m))
    return _reader_provenance(verify(root,out),root,executed=True)


def verify(root=ROOT,output=None):
    root=Path(root);out=root/OUTPUT if output is None else Path(output);m=json.loads((out/'manifest.json').read_bytes())
    if m['manifest_id']!=identity({k:v for k,v in m.items() if k!='manifest_id'}):raise ValueError('Coordinated publication receipt differs')
    if any(digest(root/p)!=h for p,h in m['source_sha256'].items()):raise ValueError('Coordinated source epoch changed')
    if m['files_sha256']!={p.relative_to(out).as_posix():digest(p) for p in out.rglob('*') if p.is_file() and p!=out/'manifest.json'}:raise ValueError('Coordinated payload changed')
    s=json.loads((out/'summary.json').read_bytes());bodies=json.loads(gzip.decompress((out/'bodies.json.gz').read_bytes()));bundles=json.loads(gzip.decompress((out/'bundles.json.gz').read_bytes()))
    for b in bodies:design_grammar.validate(b)
    for b in bundles:railway_bundle.validate(b)
    if len({b['candidate_id'] for b in bundles})!=len(bundles):raise ValueError('Mixed bundle identities')
    index={b['candidate_id']:b for b in bundles}
    verified_route_candidates=0;verified_route_count=0;row_count=0;row_ids=set();expected_cost_count=0;completion_records=[]
    for row in _comparison_rows(root,out,m):
        row_count+=1;row_ids.add(row['candidate_id'])
        completion_records.append(_cost_simulation_completion(row))
        expected_cost_count+=isinstance(row.get('economics',{}).get('model_cost'),dict)
        if row['row_id']!=identity({k:v for k,v in row.items() if k!='row_id'}) or row['bundle_definition_id']!=index[row['candidate_id']]['definition_id']:raise ValueError('Coupled case identity differs')
        if row['body_candidate_id']!=index[row['candidate_id']]['body_candidate_id'] or row['accounted_mass']!=index[row['candidate_id']]['mass']:raise ValueError('Coupled body/mass mismatch')
        if row['motion']['forward_motion']['execution']!='not-run' or row['physical_journey_completed'] is not False:raise ValueError('Required motion cannot become an available physical journey')
        estimate=row.get('economics',{}).get('model_cost',{})
        if (estimate.get('candidate_id')!=row['candidate_id']
                or estimate.get('evaluation_id')!=identity({k:v for k,v in estimate.items() if k!='evaluation_id'})
                or estimate.get('model_cost_complete_for_declared_case') is not True
                or estimate.get('model_cost_missing_scopes')
                or estimate.get('procurement_ready') is not False
                or estimate.get('physical_or_safety_accepted') is not False):
            raise ValueError('Candidate model-cost receipt incomplete, mixed or improperly accepted')
        plan=estimate.get('provisional_manufacturing_plan',{})
        routes=plan.get('routes',[])
        lines={line.get('line_id'):line for line in estimate.get('cost_line_items',[])}
        stock_lines={line.get('line_key','').removeprefix('vehicle-stock/'):line
            for line in estimate.get('cost_line_items',[]) if line.get('line_key','').startswith('vehicle-stock/')}
        route_ids=[route.get('stock_id') for route in routes]
        if (plan.get('schema')!='osr-v06-provisional-manufacturing-plan/1'
                or plan.get('candidate_id')!=row['candidate_id']
                or plan.get('plan_id')!=identity({k:v for k,v in plan.items() if k!='plan_id'})
                or plan.get('route_count')!=len(routes)
                or len(route_ids)!=len(set(route_ids))
                or set(route_ids)!=set(stock_lines)
                or plan.get('coverage',{}).get('located_stock_occurrences')!=len(routes)
                or plan.get('coverage',{}).get('routed_stock_occurrences')!=len(routes)
                or plan.get('coverage',{}).get('unrouted_stock_ids')!=[]):
            raise ValueError('Candidate provisional manufacturing route coverage differs')
        for route in routes:
            if (route.get('candidate_id')!=row['candidate_id']
                    or route.get('route_id')!=identity({k:v for k,v in route.items() if k!='route_id'})
                    or route.get('cost_line_id') not in lines
                    or lines[route['cost_line_id']].get('line_key')!='vehicle-stock/'+route['stock_id']
                    or route.get('estimate_class')!='C'
                    or route.get('process_qualified') is not False
                    or route.get('measured_labor') is not False
                    or route.get('manufacturing_release') is not False
                    or route.get('operating_release') is not False):
                raise ValueError('Candidate provisional manufacturing route identity or release gate differs')
        verified_route_candidates+=1;verified_route_count+=len(routes)
    if row_count!=len(bundles) or row_ids!=set(index):raise ValueError('Mixed or incomplete bundle results')
    cost_summary=s['model_cost_summary']
    if (cost_summary.get('candidate_estimates')!=expected_cost_count
            or cost_summary.get('complete_for_declared_case')!=expected_cost_count
            or cost_summary.get('provisional_stock_route_complete_candidates')!=verified_route_candidates
            or cost_summary.get('provisional_stock_route_count')!=verified_route_count
            or cost_summary.get('integrated_winner') is not None):
        raise ValueError('Published model-cost summary differs from candidate estimates')
    if s.get('completion_status')!=completion_summary_from_records(completion_records):
        raise ValueError('Published candidate completion levels differ from their calculation evidence')
    continuation=json.loads(gzip.decompress((out/'current-refinement.json.gz').read_bytes()))
    if continuation is None:
        if s.get('current_source_refinement') is not None:
            raise ValueError('Current refinement summary has no retained package')
    else:
        request=continuation['request'];result=continuation['result'];report=continuation['report'];manifest=continuation['manifest']
        if (manifest.get('manifest_id')!=identity({k:v for k,v in manifest.items() if k!='manifest_id'})
                or manifest.get('request_id')!=identity(request)
                or request.get('parent_contract_id')!=s['contract_id']
                or request.get('body_candidate_id')!=report.get('body_candidate_id')
                or result.get('evaluation_id')!=report.get('evaluation_id')
                or result.get('evaluation_id')!=identity({k:v for k,v in result.items() if k!='evaluation_id'})
                or result.get('source_sha256')!=request.get('source_sha256')
                or manifest.get('parent_result_sha256')!=request.get('parent_result_sha256')
                or report.get('physical_and_engineering_acceptance') is not False
                or any(result.get(k) is not False for k in ('physical_accepted','engineering_accepted','manufacturing_release','operating_release'))
                or continuation['verification'].get('verified') is not True
                or s.get('current_source_refinement',{}).get('manifest_id')!=manifest.get('manifest_id')):
            raise ValueError('Current-source refinement packet is mixed, changed or improperly accepted')
        indexed=next((x for x in json.loads((out/'native-index.json').read_bytes())
                      if x.get('kind')=='body-current-source-refinement'),None)
        if indexed is None or indexed.get('raw_manifest')!=manifest or indexed.get('raw_result')!=result:
            raise ValueError('Current refinement is absent or differs from native index')
        with tarfile.open(out/indexed['archive']) as tar:
            if (json.loads(tar.extractfile('request.json').read())!=request
                    or json.loads(tar.extractfile('report.json').read())!=report
                    or json.loads(tar.extractfile('manifest.json').read())!=manifest):
                raise ValueError('Archived current refinement differs from its published packet')
    fine=json.loads(gzip.decompress((out/'fine-refinement.json.gz').read_bytes()))
    if fine is None:
        if s.get('current_source_fine_refinement') is not None:
            raise ValueError('Fine-refinement summary has no reconciled package')
    else:
        request=fine['request'];result=fine['result'];report=fine['report'];manifest=fine['manifest']
        package_kind=fine.get('package_kind','reconciled-native')
        direct=package_kind=='direct-native'
        if (manifest.get('manifest_id')!=identity({k:v for k,v in manifest.items() if k!='manifest_id'})
                or manifest.get('request_id')!=identity(request)
                or request.get('parent_contract_id')!=s['contract_id']
                or request.get('body_candidate_id')!=report.get('body_candidate_id',request.get('body_candidate_id'))
                or result.get('evaluation_id')!=report.get('evaluation_id')
                or result.get('evaluation_id')!=identity({k:v for k,v in result.items() if k!='evaluation_id'})
                or result.get('source_sha256')!=request.get('source_sha256')
                or manifest.get('parent_result_sha256')!=request.get('parent_result_sha256')
                or s.get('current_source_fine_refinement',{}).get('package_kind')!=package_kind
                or (not direct and report.get('raw_package_files_sha256')!=manifest.get('raw_payload_sha256'))
                or (direct and (manifest.get('schema')!='osr-current-source-fine-refinement-manifest/1'
                    or manifest.get('files_sha256') is None
                    or report.get('physical_and_engineering_acceptance') is not False))
                or fine.get('verification',{}).get('verified') is not True
                or s.get('current_source_fine_refinement',{}).get('manifest_id')!=manifest.get('manifest_id')
                or report.get('physical_and_engineering_acceptance') is not False
                or any(result.get(k) is not False for k in ('physical_accepted','engineering_accepted','manufacturing_release','operating_release'))):
            raise ValueError('Fine-refinement package is mixed, changed or improperly accepted')
        expected_kind=('body-current-source-fine-refinement' if direct
            else 'body-current-source-fine-refinement-reconciliation')
        indexed=next((x for x in json.loads((out/'native-index.json').read_bytes())
                      if x.get('kind')==expected_kind),None)
        if indexed is None or indexed.get('raw_manifest')!=manifest or indexed.get('raw_result')!=result:
            raise ValueError('Fine refinement is absent from the native index')
        with tarfile.open(out/indexed['archive']) as tar:
            result_name='native/result.json' if direct else 'result.json'
            if (json.loads(tar.extractfile('request.json').read())!=request
                    or json.loads(tar.extractfile(result_name).read())!=result
                    or json.loads(tar.extractfile('report.json').read())!=report
                    or json.loads(tar.extractfile('manifest.json').read())!=manifest):
                raise ValueError('Archived fine-refinement package differs from its published packet')
            archive_index=json.loads(tar.extractfile('archive-index.json').read())
            archived_files={**archive_index['retained_sha256'],**archive_index['omitted_sha256']}
            declared=(manifest.get('files_sha256') if direct else
                {**json.loads(tar.extractfile('raw-payload.json').read())})
            if {k:v for k,v in archived_files.items() if k!='manifest.json'}!={
                    k:v for k,v in declared.items() if k!='manifest.json'}:
                raise ValueError('Fine-refinement archive does not cover its exact source payload')
            if not direct:
                raw_payload=json.loads(tar.extractfile('raw-payload.json').read())
                source=tar.extractfile('fine-producer-source.py').read()
                if (raw_payload!=report.get('raw_package_files_sha256')
                        or sha256(source).hexdigest()!=request.get('source_sha256',{}).get('engineering/design_search/railway_refinement_current_fine.py')):
                    raise ValueError('Reconciled fine-refinement raw-file index or producer snapshot differs')
                with tarfile.open(fileobj=io.BytesIO(tar.extractfile('raw-run.tar.gz').read())) as raw_tar:
                    raw_index=json.loads(raw_tar.extractfile('archive-index.json').read())
                    if {**raw_index['retained_sha256'],**raw_index['omitted_sha256']}!=raw_payload:
                        raise ValueError('Archived native snapshot does not cover every preserved raw file')
    ultrafine=json.loads(gzip.decompress((out/'ultrafine-refinement.json.gz').read_bytes()))
    if ultrafine is None:
        if s.get('current_source_ultrafine_refinement') is not None:
            raise ValueError('Ultrafine-refinement summary has no retained package')
    else:
        request=ultrafine['request'];result=ultrafine['result'];report=ultrafine['report'];manifest=ultrafine['manifest']
        if (manifest.get('manifest_id')!=identity({k:v for k,v in manifest.items() if k!='manifest_id'})
                or manifest.get('request_id')!=identity(request)
                or request.get('parent_contract_id')!=s['contract_id']
                or request.get('mesh_m')!=0.053125
                or request.get('computational_cell_estimate',{}).get('solid_cells')!=290660
                or request.get('body_candidate_id')!=report.get('body_candidate_id')
                or result.get('evaluation_id')!=report.get('evaluation_id')
                or result.get('evaluation_id')!=identity({k:v for k,v in result.items() if k!='evaluation_id'})
                or result.get('source_sha256')!=request.get('source_sha256')
                or manifest.get('parent_result_sha256')!=request.get('parent_result_sha256')
                or result.get('mesh_summary',{}).get('mesh_m')!=0.053125
                or result.get('mesh_summary',{}).get('solid_elements')!=290660
                or result.get('mesh_summary',{}).get('node_count')!=513844
                or ultrafine.get('verification',{}).get('verified') is not True
                or s.get('current_source_ultrafine_refinement',{}).get('manifest_id')!=manifest.get('manifest_id')
                or report.get('physical_and_engineering_acceptance') is not False
                or any(result.get(k) is not False for k in ('physical_accepted','engineering_accepted','manufacturing_release','operating_release'))):
            raise ValueError('Ultrafine-refinement package is mixed, changed or improperly accepted')
        indexed=next((x for x in json.loads((out/'native-index.json').read_bytes())
            if x.get('kind')=='body-current-source-ultrafine-refinement'),None)
        if indexed is None or indexed.get('raw_manifest')!=manifest or indexed.get('raw_result')!=result:
            raise ValueError('Ultrafine refinement is absent or differs from native index')
        with tarfile.open(out/indexed['archive']) as tar:
            if (json.loads(tar.extractfile('request.json').read())!=request
                    or json.loads(tar.extractfile('native/result.json').read())!=result
                    or json.loads(tar.extractfile('report.json').read())!=report
                    or json.loads(tar.extractfile('manifest.json').read())!=manifest):
                raise ValueError('Archived ultrafine-refinement package differs from its published packet')
            archive_index=json.loads(tar.extractfile('archive-index.json').read())
            archived_files={**archive_index['retained_sha256'],**archive_index['omitted_sha256']}
            if {k:v for k,v in archived_files.items() if k!='manifest.json'}!={
                    k:v for k,v in manifest.get('files_sha256',{}).items() if k!='manifest.json'}:
                raise ValueError('Ultrafine archive does not cover its exact source payload')
    if any(s.get(k) is not False for k in FLAGS) or s['integrated_selection'] is not None:raise ValueError('Research comparison cannot release a railway')
    native_index=json.loads((out/'native-index.json').read_bytes())
    native_body_count=sum(item.get('kind') in ('body','body-refinement','body-exact-cache-reuse','body-current-source-refinement','body-current-source-fine-refinement','body-current-source-fine-refinement-reconciliation','body-current-source-ultrafine-refinement') for item in native_index)
    reused_body_count=sum(item.get('kind')=='body-exact-cache-reuse' for item in native_index)
    if (native_body_count!=s.get('native_body_case_count')
            or s.get('native_body_case_count')!=s.get('native_new_body_case_count',0)+s.get('native_reused_body_case_count',0)
            or reused_body_count!=s.get('native_reused_body_case_count')):
        raise ValueError('Native body summary differs from its indexed cases')
    epochs=json.loads((out/'source-epochs.json').read_bytes())
    unavailable_source_hashes={h for item in native_index
        for h in item.get('raw_result',{}).get('source_bytes_unavailable',{}).values()}
    for h,r in epochs.items():
        if r.get('artifact') is None:
            if r.get('availability')!='unavailable' or h not in unavailable_source_hashes:
                raise ValueError('Unresolved source epoch is not declared by a held failure record')
        elif digest(out/r['artifact'])!=h:
            raise ValueError('Historical producer bytes differ')
    for item in native_index:
        with tarfile.open(out/item['archive']) as tar:
            ai=json.loads(tar.extractfile('archive-index.json').read());manifest=json.loads(tar.extractfile('manifest.json').read())
            result_name='native/result.json' if item.get('kind') in ('body-current-source-refinement','body-current-source-fine-refinement','body-current-source-ultrafine-refinement') else 'result.json'
            result=json.loads(tar.extractfile(result_name).read())
            if manifest!=item['raw_manifest'] or result!=item['raw_result']:raise ValueError('Native index differs from raw receipt')
            if manifest.get('manifest_id')!=identity({k:v for k,v in manifest.items() if k!='manifest_id'}):raise ValueError('Nested native manifest identity differs')
            if 'evaluation_id' in result and result['evaluation_id']!=identity({k:v for k,v in result.items() if k!='evaluation_id'}):raise ValueError('Nested native evaluation identity differs')
            if manifest['files_sha256']!={k:v for k,v in {**ai['retained_sha256'],**ai['omitted_sha256']}.items() if k!='manifest.json'}:raise ValueError('Native archive does not cover original payload')
            for name,h in ai['retained_sha256'].items():
                if sha256(tar.extractfile(name).read()).hexdigest()!=h:raise ValueError('Native payload changed')
            for name,h in result.get('source_sha256',manifest.get('source_sha256',{})).items():
                if digest(root/name)!=h and h not in epochs:raise ValueError('Native source changed')
    for r in json.loads((out/'delivery-index.json').read_bytes()):
        prefix=out/r['prefix'];manifest=r['raw_manifest'];value=json.loads(gzip.decompress((prefix/'delivery.json.gz').read_bytes()))
        context=manifest.get('cache_context')
        if context is None or context.get('cache_context_id')!=identity({k:v for k,v in context.items() if k!='cache_context_id'}):raise ValueError('Delivery cache context identity differs')
        if manifest.get('manifest_id')!=identity({k:v for k,v in manifest.items() if k!='manifest_id'}):raise ValueError('Delivery manifest identity differs')
        if context['candidate_id']!=r['candidate_id'] or context['body_candidate_id']!=r['body_candidate_id'] or context['inventory_evaluation_id']!=value['inventory_evaluation_id']:raise ValueError('Delivery cache inputs differ')
        if context['source_sha256']!=value['source_sha256'] or context['IFC_tool']['version']!=json.loads((prefix/'bim.json').read_bytes()).get('ifcopenshell_version'):raise ValueError('Delivery cache tool or source differs')
        if value['candidate_id']!=r['candidate_id'] or value['body_candidate_id']!=r['body_candidate_id'] or value['delivery_id']!=identity({k:v for k,v in value.items() if k!='delivery_id'}):raise ValueError('Mixed delivery identity')
        for p in prefix.iterdir():
            if digest(p)!=manifest['files_sha256'][p.name]:raise ValueError('Delivery bytes differ')
        if (prefix/'body-stock.ifc.gz').is_file() and sha256(gzip.decompress((prefix/'body-stock.ifc.gz').read_bytes())).hexdigest()!=manifest['files_sha256']['wheel-stock.ifc']:raise ValueError('Compressed IFC differs from native delivery')
    return _reader_provenance(dict(verified=True,manifest_id=m['manifest_id'],campaign_id=s['campaign_id'],body_count=len(bodies),evaluated_bundle_count=row_count,
        native_body_case_count=s['native_body_case_count'],physical_journeys=0,complete_installed_masses=0,**FLAGS),root,executed=False)
