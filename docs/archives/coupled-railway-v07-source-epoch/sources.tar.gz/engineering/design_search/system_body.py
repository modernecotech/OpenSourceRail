"""Counted complete metallic load-path children of generated body proposals.

Net disjoint stock uses intact, finite-face autogenous weld hypotheses. Weld
strength/HAZ/fatigue, panel retention, installed services and qualification stay
unknown. Two real physical alternatives precede any numerical comparison.
"""
from copy import deepcopy
from math import prod,ceil,isfinite
from pathlib import Path
from engineering.station_rail import ROOT,FLAGS
from engineering.station_rail.common import identity,digest
from engineering.design_search import design_grammar
PRODUCER='engineering/design_search/system_body.py'


def _subtract(box,cut):
    lo=[max(box[i],cut[i]) for i in (0,2,4)];hi=[min(box[i+1],cut[i+1]) for i in (0,2,4)]
    if min(b-a for a,b in zip(lo,hi))<=1e-10:return [box]
    x0,x1,y0,y1,z0,z1=box;a,c,e=lo;b,d,f=hi
    return [p for p in ((x0,a,y0,y1,z0,z1),(b,x1,y0,y1,z0,z1),(a,b,y0,c,z0,z1),(a,b,d,y1,z0,z1),(a,b,c,d,z0,e),(a,b,c,d,f,z1)) if min(p[1]-p[0],p[3]-p[2],p[5]-p[4])>1e-10]


def _finite_box(box):
    """Allow the fast disjoint check only for ordinary, finite coordinates."""
    try:
        return len(box)==6 and all(type(v) in (float,int) and isfinite(v) for v in box)
    except (TypeError,ValueError,OverflowError):
        return False


def _disjoint_finite(box,cut):
    """Conservatively reject zero-overlap finite boxes; overlaps use _subtract."""
    return (box[1]<=cut[0] or cut[1]<=box[0] or
            box[3]<=cut[2] or cut[3]<=box[2] or
            box[5]<=cut[4] or cut[5]<=box[4])


def _interfaces(parts):
    planes={};contacts={}
    for p in parts:
        if p.get('structural_role')=='nonstructural-cover':continue
        for d in range(3):
            u,w=[i for i in range(3) if i!=d];rect=[p['at_m'][u],p['at_m'][u]+p['size_m'][u],p['at_m'][w],p['at_m'][w]+p['size_m'][w]]
            for side in (0,1):planes.setdefault((d,round(p['at_m'][d]+side*p['size_m'][d],10)),{0:[],1:[]})[side].append((p['manufacturing_occurrence_id'],rect,p['id']))
    for group in planes.values():
        for a,r,aid in group[0]:
            for b,s,bid in group[1]:
                if a==b:continue
                area=max(0.,min(r[1],s[1])-max(r[0],s[0]))*max(0.,min(r[3],s[3])-max(r[2],s[2]))
                if area>1e-12:
                    pair=tuple(sorted((a,b)));entry=contacts.setdefault(pair,dict(area=0.,part_ids=set()));entry['area']+=area;entry['part_ids'].update((aid,bid))
    return [dict(id='weld-interface/'+identity(pair)[:14],occurrences=list(pair),part_ids=sorted(record['part_ids']),contact_area_m2=record['area'],method='Proposed welded cut-face interface; weld strength/HAZ/fatigue not qualified',net_hardware_mass_kg=None) for pair,record in sorted(contacts.items())]


def build(parent,topology='aluminium_frame',root=ROOT,*,profile_policy='baseline',revision_parent_id=None):
    design_grammar.validate(parent)
    if topology not in ('aluminium_frame','aluminium_stressed_skin'):raise ValueError('Explicit supported physical child topology required')
    if profile_policy not in ('baseline','aligned'):raise ValueError('Explicit baseline/aligned profile policy required')
    if revision_parent_id is not None and (profile_policy!='aligned' or not isinstance(revision_parent_id,str) or len(revision_parent_id)!=64 or any(c not in '0123456789abcdef' for c in revision_parent_id)):raise ValueError('Explicit baseline physical parent ID is allowed for an aligned revision only')
    L=parent['physical']['architecture']['car_length_m'];W=parent['physical']['architecture']['width_m'];H=3.7;apertures=deepcopy(parent['physical']['apertures']);raw=[]
    if abs(L-17.)>1e-8 or abs(W-2.65)>1e-8:raise ValueError('Current connected-body generator domain is17×2.65m; new sizes need explicit support/assembly geometry, not a new project requirement')
    def add(name,at,size,role='frame',occurrence=None):
        if min(size)<=0:raise ValueError('Positive stock required')
        raw.append(dict(id=name,at_m=list(at),size_m=list(size),role=role,occurrence=occurrence or name))
    def tube(name,at,length,width,height,wall,axis):
        sizes=[(length,wall,height),(length,wall,height),(length,width-2*wall,wall),(length,width-2*wall,wall)];offsets=[(0,0,0),(0,width-wall,0),(0,wall,0),(0,wall,height-wall)]
        for i,(s,o) in enumerate(zip(sizes,offsets)):
            if axis==1:s=(s[1],s[0],s[2]);o=(o[1],o[0],o[2])
            if axis==2:s=(s[1],s[2],s[0]);o=(o[1],o[2],o[0])
            add(name+'/'+str(i),[a+b for a,b in zip(at,o)],s,occurrence=name)
    # Plates first: net members are trimmed around finite welded interfaces.
    add('floor/structural',(-L/2,-W/2+.002,.997),(L,W-.004,.003),'floor')
    add('roof/structural',(-L/2,-W/2+.002,3.697),(L,W-.004,.003),'roof')
    for x,name in ((-L/2,'left'),(L/2-.003,'right')):add('end/diaphragm/'+name,(x,-W/2+.002,1.),(.003,W-.004,2.697),'diaphragm')
    for side in (-1,1):
        y=side*1.1-.07;tube('underframe/rail/'+str(side),(-L/2,y,.55),L,.14,.35,.008,0)
        for x in (-6.4,6.4):add(f'bogie-pad/{side}/{x}',(x-.1,side*1.1-.09,.53),(.2,.18,.02),'support-pad')
    stations=sorted({-L/2+.04,L/2-.04,*[-L/2+L*i/ceil(L/1.7) for i in range(1,ceil(L/1.7))],-6.4,6.4})
    for i,x in enumerate(stations):
        if profile_policy=='aligned':tube('floor/rib/'+str(i),(x-.03,-W/2+.002,.9),W-.004,.06,.097,.004,1)
        else:tube('floor/rib/'+str(i),(x-.04,-W/2+.002,.847),W-.004,.08,.15,.006,1)
    # Counted close-pitch floor/roof ribs avoid crediting a flat3mm sheet with
    # the unsupported bending span of the complete frame bay.
    if profile_policy=='aligned':
        for i in range(7):
            y=-(W/2-.032)+(W-.064)*i/6
            tube('floor/longitudinal/'+str(i),(-L/2,y-.03,.9),L,.06,.097,.004,0)
            tube('roof/longitudinal/'+str(i),(-L/2,y-.03,3.637),L,.06,.06,.004,0)
    else:
        for i in range(11):
            y=-W/2+.08+(W-.16)*i/10;tube('floor/longitudinal/'+str(i),(-L/2,y-.02,.927),L,.04,.07,.003,0)
        for i in range(7):
            y=-W/2+.08+(W-.16)*i/6;tube('roof/longitudinal/'+str(i),(-L/2,y-.02,3.657),L,.04,.04,.003,0)
    for side in (-1,1):
        y=-W/2+.002 if side<0 else W/2-.062
        for z,name in ((.997,'lower'),(3.637,'roof')):tube(f'side/frame/{side}/{name}',(-L/2,y,z),L,.06,.06,.004,0)
        for i,x in enumerate(stations):
            if topology=='aluminium_frame' or i in (0,len(stations)-1):tube(f'side/post/{side}/{i}',(x-.03,y,.997),2.7,.06,.06,.004,2)
        if topology=='aluminium_frame':
            for z in (1.59,2.85,3.1):tube(f'side/stringer/{side}/{z}',(-L/2,y,z),L,.06,.06,.004,0)
        for a in apertures:
            if a['side']!=side:continue
            x0,x1,z0,z1=a['xz_m'];name='side/aperture/'+a['id']
            for x,label in ((x0-.06,'a'),(x1,'b')):tube(name+'/'+label,(x,y,z0-.06),z1-z0+.12,.06,.06,.004,2)
            for z,label in ((z0-.06,'lower'),(z1,'upper')):tube(name+'/'+label,(x0-.06,y,z),x1-x0+.12,.06,.06,.004,0)
        if topology=='aluminium_stressed_skin':add('side/structural/'+str(side),(-L/2,-W/2+.002 if side<0 else W/2-.005,1.),(L,.003,2.697),'side-shear')
    for i,x in enumerate(stations):tube('roof/rib/'+str(i),(x-.03,-W/2+.002,3.637),W-.004,.06,.06,.004,1)
    # Cut every side member around the actual passenger apertures.
    clipped=[]
    for p in raw:
        b=tuple(v for a,s in zip(p['at_m'],p['size_m']) for v in (a,a+s));pieces=[b]
        if p['id'].startswith('side/'):
            side=-1 if p['at_m'][1]<0 else 1
            for a in apertures:
                if a['side']==side:
                    x0,x1,z0,z1=a['xz_m'];pieces=[q for old in pieces for q in _subtract(old,(x0,x1,-W,W,z0,z1))]
        for q in pieces:clipped.append((p,q))
    parts=[];bounds=[];bounds_finite=True;gross=sum(prod(p['size_m']) for p in raw)
    for origin,b in clipped:
        remaining=[b];b_finite=_finite_box(b)
        for existing in bounds:
            if b_finite and bounds_finite and _disjoint_finite(b,existing):continue
            remaining=[q for old in remaining for q in _subtract(old,existing)]
        for i,q in enumerate(remaining):
            at=[q[0],q[2],q[4]];size=[q[1]-q[0],q[3]-q[2],q[5]-q[4]];volume=prod(size);uid=origin['id']+'/net/'+str(i)+'-'+identity(q)[:8]
            functions=['support-loads']+(['support-passengers'] if origin['role']=='floor' else ['roof-structure'] if origin['role']=='roof' else ['enclosure'] if origin['role'] in ('diaphragm','side-shear') else [])
            parts.append(dict(id=uid,kind='box',at_m=at,size_m=size,material_id='aluminium_reference',volume_m3=volume,mass_kg=volume*2710.,functions=functions,load_roles=['primary'],form='net-trimmed-metal-stock',process='cut-fit-autogenous-weld',manufacturing_occurrence_id=origin['occurrence'],removable=False,access='not-designed',structural_role=origin['role']));bounds.append(q)
            if bounds_finite and not _finite_box(q):bounds_finite=False
    # Keep only the parent outer side covers as nonstructural, counted stock.
    for old in parent['parts']:
        if old['id'].startswith('side/') and '/outer/' in old['id']:
            q=deepcopy(old);q['id']='retained-cover/'+old['id'];q['load_roles']=['non-primary'];q['structural_role']='nonstructural-cover';parts.append(q)
    # Explicit nonstructural service geometry; performance/retention, sealing,
    # drainage fall/outlet, cable segregation and installation remain unknown.
    def ancillary(name,at,size,functions,occurrence=None):
        volume=prod(size);parts.append(dict(id=name,kind='box',at_m=list(at),size_m=list(size),material_id='aluminium_reference',volume_m3=volume,mass_kg=volume*2710.,functions=list(functions),load_roles=['non-primary'],form='counted-service-attachment-stock',process='cut-fit-and-retain-unqualified',manufacturing_occurrence_id=occurrence or name,removable=True,access='not-designed',structural_role='nonstructural-ancillary',performance_evidence='unknown'))
    for side in (-1,1):
        y=side*.8-.02;name='ancillary/PV-rail/'+str(side)
        for i,(at,size) in enumerate([((-L/2,y,3.705),(L,.002,.02)),((-L/2,y+.038,3.705),(L,.002,.02)),((-L/2,y+.002,3.705),(L,.036,.002)),((-L/2,y+.002,3.723),(L,.036,.002))]):ancillary(name+'/'+str(i),at,size,['solar-mount'],name)
        for i,x in enumerate(stations):ancillary(f'ancillary/PV-standoff/{side}/{i}',(x-.02,side*.8-.02,3.7),(.04,.04,.005),['solar-mount'])
    for label,y,width,functions in [('cable',-.04,.08,['cable-route']),('gutter',.23,.04,['drainage'])]:
        name='ancillary/'+label
        for i,(at,size) in enumerate([((-L/2+.003,y,3.58),(L-.006,width,.002)),((-L/2+.003,y,3.582),(L-.006,.002,.018)),((-L/2+.003,y+width-.002,3.582),(L-.006,.002,.018))]):ancillary(name+'/'+str(i),at,size,functions,name)
        for i,x in enumerate(stations):
            for edge in (y,y+width-.003):ancillary(f'{name}/hanger/{i}/{edge:g}',(x-.01,edge,3.6),(.02,.003,.037),functions)
    gross+=sum(p['volume_m3'] for p in parts if p.get('structural_role')=='nonstructural-ancillary')
    mats=deepcopy(parent['materials']);mats['aluminium_reference'].update(nu=.33,constitutive_kind='isotropic',source_basis='Retained declared E69GPa/nu.33 research law from body_solid_frame; no supplier/HAZ/fatigue qualification',source_ref=dict(path='engineering/station_rail/body_solid_frame.py',sha256=digest(Path(root)/'engineering/station_rail/body_solid_frame.py')))
    known=sum(p['mass_kg'] for p in parts);retained=deepcopy(parent['retained_equipment_accounts']);other=sum(r['mass_kg'] for r in retained if r['system']!='bogies');people=parent['structure']['load_basis']['normal_people'];load_cases={name:dict(sprung_mass_hypothesis_kg=known+other+n*75.,people=n,person_mass_kg=75.,complete_installed_mass=False) for name,n in [('empty',0),('normal',people),('crowd',160)]}
    geometry=[{k:v for k,v in p.items() if k not in ('mass_kg','access','process','joint_end_detail')} for p in parts]
    joins=_interfaces(parts);physical=dict(schema='osr-generative-body-physical/1',architecture=deepcopy(parent['physical']['architecture']),envelope={**parent['physical']['envelope'],'nominal_external_roof_top_z_m':3.725},apertures=apertures,nodes=[],members=[],geometry=geometry,joins=joins,required_functions=parent['required_functions'],retained_equipment=deepcopy(parent['physical']['retained_equipment']),topology=topology)
    cid=identity(physical);law_source='engineering/station_rail/body_solid_frame.py';sources={**parent['sources'],PRODUCER:digest(__file__),law_source:digest(Path(root)/law_source)}
    result=dict(schema='osr-generative-body-candidate/1',candidate_id=cid,physical=physical,parameters={**parent['parameters'],'family':topology},label=topology,parent_candidate_ids=[parent['candidate_id']],revision_reason='Counted gap-free finite-face metallic frame and structural panel alternatives',requirement_revision=parent['requirement_revision'],parts=parts,materials=mats,retained_equipment_accounts=retained,known_structure_stock_kg=known,complete_installed_mass_kg=None,complete_cost_USD=None,required_functions=parent['required_functions'],components=[],connections=[],assembly=[],joins=physical['joins'],sources=sources,structure=dict(schema='osr-solid-body-structure/1',candidate_id=cid,nodes=[],members=[]),load_cases=load_cases,
        retained_reference_candidate_id=parent['retained_reference_candidate_id'],
        shell_model=dict(structural_part_ids=[p['id'] for p in parts if 'primary' in p.get('load_roles',[])],joint_assumption='Coincident finite faces are intact autogenous weld/continuous material; no hidden gap ties or rigid offsets',support_z_m=.53,support_x_m=[-6.4,6.4],support_y_m=[-1.1,1.1],gross_raw_metal_stock_m3=gross,net_metal_stock_m3=sum(p['volume_m3'] for p in parts if p['material_id']=='aluminium_reference'),cut_loss_procurement_allowance_kg=None),**FLAGS)
    result['components']=[dict(occurrence_id=p['id'],part_id=p['id'],component_definition_id=identity(geometry[i]),functions=p['functions'],ports=[],mass_kg=p['mass_kg'],stock={'mass_kg':p['mass_kg']},inventory_status='located',manufacturing_occurrence_id=p['manufacturing_occurrence_id']) for i,p in enumerate(parts)]
    retained_ids={r['id'] for r in retained};result['components'] += [deepcopy(c) for c in parent['components'] if c['occurrence_id'] in retained_ids]
    result['components'] += [dict(occurrence_id=j['id'],part_id=j['id'],component_definition_id=identity(j),functions=['transfer-loads'],ports=[],mass_kg=None,stock={'mass_kg':None},inventory_status='unknown',performance_evidence='unknown') for j in joins]
    result['assembly']=[dict(id='cut-and-fit',occurrences=[p['id'] for p in parts],requires=[]),dict(id='weld-and-inspect',occurrences=[j['id'] for j in joins],requires=['cut-and-fit'],qualification='Weld procedure, access, inspection and strength release remain unknown')]
    if profile_policy=='aligned':
        specification=dict(policy='aligned',floor_longitudinals=7,roof_longitudinals=7,y_centres_m=[-(W/2-.032)+(W-.064)*i/6 for i in range(7)],floor_profile_m=[.06,.097,.004],roof_profile_m=[.06,.06,.004],floor_z_m=[.9,.997],roof_z_m=[3.637,3.697],purpose='Resource/manufacturing architecture experiment; no strength or safety criterion is inferred')
        physical['profile_specification']=specification;result['candidate_id']=identity(physical);result['structure']['candidate_id']=result['candidate_id'];result['parent_candidate_ids']=[revision_parent_id or parent['candidate_id']];result['revision_reason']='Align counted floor/roof profile families and cut planes after observed native memory refusal; strength, buckling and response remain unevaluated';result['profile_specification']=specification
    result['definition_id']=identity(result);return result


def preflight(candidate,mesh_m=1.7,computational_cell_cap=60000):
    """Exact conformal occupancy/vertex count without any solver invocation.

    The cap is a declared computational dispatch budget, never an engineering
    constraint. Native results and qualification remain unknown either way.
    """
    design_grammar.validate(candidate)
    if not .4<=mesh_m<=2.:raise ValueError('Current whole-body mesh budget domain .4..2m required')
    ids=set(candidate['shell_model']['structural_part_ids']);parts=[p for p in candidate['parts'] if p['id'] in ids];axes=[]
    for d in range(3):
        values={round(p['at_m'][d]+s*p['size_m'][d],10) for p in parts for s in (0,1)};lo=min(values);hi=max(values);values.update(round(lo+(hi-lo)*i/ceil((hi-lo)/mesh_m),10) for i in range(ceil((hi-lo)/mesh_m)+1));axes.append(sorted(values))
    maps=[{v:i for i,v in enumerate(a)} for a in axes];cells=set()
    for p in parts:
        r=[range(maps[d][round(p['at_m'][d],10)],maps[d][round(p['at_m'][d]+p['size_m'][d],10)]) for d in range(3)]
        for i in r[0]:
            for j in r[1]:
                for k in r[2]:
                    if (i,j,k) in cells:raise ValueError('Positive-volume structural stock overlap')
                    cells.add((i,j,k))
    vertices={(i+a,j+b,k+c) for i,j,k in cells for a in (0,1) for b in (0,1) for c in (0,1)};remaining=set(cells);components=0
    while remaining:
        components+=1;stack=[remaining.pop()]
        while stack:
            key=stack.pop()
            for d in range(3):
                for step in (-1,1):
                    n=list(key);n[d]+=step;n=tuple(n)
                    if n in remaining:remaining.remove(n);stack.append(n)
    value=dict(candidate_id=candidate['candidate_id'],mesh_m=mesh_m,element_kind='C3D8I',solid_elements=len(cells),actual_vertex_nodes=len(vertices),axis_cut_counts=[len(a) for a in axes],finite_face_components=components,computational_cell_cap=computational_cell_cap,dispatch_within_cell_budget=len(cells)<=computational_cell_cap,engineering_screen='unknown',native_jobs_used=0,scope='Exact occupied Cartesian cells/corner nodes for the current conformal mesher; computational budget only, not structural feasibility or acceptance',**FLAGS);value['preflight_id']=identity(value);return value
